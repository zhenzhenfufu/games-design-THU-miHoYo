#include "MirrorCourt.h"
#include "Academy.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/TextRenderComponent.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Engine/GameViewportClient.h"
#include "EngineUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Sound/SoundBase.h"
#include "UObject/ConstructorHelpers.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

namespace Rain {
 const FLinearColor Stone(.34f,.43f,.49f),Pale(.65f,.74f,.76f),Dark(.04f,.065f,.10f),Wood(.20f,.24f,.27f),Jade(.12f,.70f,.65f),Gold(.95f,.57f,.20f),Paper(.84f,.77f,.57f);
}
AMirrorCourt::AMirrorCourt(){
 PrimaryActorTick.bCanEverTick=true;
 Root=CreateDefaultSubobject<USceneComponent>(TEXT("RainMirrorCourt"));SetRootComponent(Root);
 PaperStairs=Group(TEXT("UniqueStairPainting"));WaterNames=Group(TEXT("NamesOnlyInWater"));StairDrawing=Group(TEXT("OldGalleryStairMemory"));
 MirrorSeal=Group(TEXT("ViewFixingTalisman"));StairSeal=Group(TEXT("StairTalisman"));
 static ConstructorHelpers::FObjectFinder<UStaticMesh> C(TEXT("/Engine/BasicShapes/Cube.Cube")),Y(TEXT("/Engine/BasicShapes/Cylinder.Cylinder")),S(TEXT("/Engine/BasicShapes/Sphere.Sphere")),P(TEXT("/Engine/BasicShapes/Plane.Plane"));
 static ConstructorHelpers::FObjectFinder<UMaterialInterface> M(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
 Cube=C.Object;Cylinder=Y.Object;Sphere=S.Object;BaseMaterial=M.Object;
 using namespace Rain;
 Shape(TEXT("FloatingIsland"),{0,50,-240},{2860,3580,360},Dark);
 Shape(TEXT("SouthTerrace"),{0,-910,-25},{2800,1480,50},Stone);
 Shape(TEXT("NorthTerrace"),{0,1140,-25},{2800,980,50},Stone);
 for(int side:{-1,1}){
  Shape(FString::Printf(TEXT("Walk%d"),side),{side*1020.f,200,-25},{760,900,50},Stone);
  Shape(FString::Printf(TEXT("Boundary%d"),side),{side*1400.f,0,160},{35,3400,320},Pale);
  for(int n=0;n<5;n++){
   float y=-1100+n*500.f;
   Shape(FString::Printf(TEXT("Column%d_%d"),side,n),{side*1240.f,y,230},{32,32,460},Wood,nullptr,true,1);
   Shape(FString::Printf(TEXT("Roof%d_%d"),side,n),{side*1190.f,y,460},{390,530,28},Dark);
   Shape(FString::Printf(TEXT("EaveLantern%d_%d"),side,n),{side*1170.f,y,365},{30,30,54},Paper,nullptr,false,1,1);
  }
 }
 Shape(TEXT("SouthBoundary"),{0,-1650,110},{2800,30,220},Pale);
 Shape(TEXT("PoolBed"),{0,250,-150},{1270,850,50},Dark);
 Shape(TEXT("Water_Real"),{0,250,-40},{1270,850,4},Jade,nullptr,false,0,.18f);
 for(int i=0;i<12;i++){
  const float a=i*PI/6;
  Shape(FString::Printf(TEXT("WaterRing%d"),i),{FMath::Cos(a)*500,250+FMath::Sin(a)*330,-30},{90,4,2},Pale,nullptr,false,0,.5f)->SetRelativeRotation(FRotator(0,i*30+90,0));
 }
 // The vertical water mirror is a live view of other built, traversable spaces.
 for(int side:{-1,1}){
  Shape(FString::Printf(TEXT("MirrorPillar%d"),side),{side*365.f,190,285},{42,65,570},Gold);
  Shape(FString::Printf(TEXT("MirrorFoot%d"),side),{side*365.f,190,-15},{130,160,160},Dark);
 }
 Shape(TEXT("MirrorHead"),{0,190,570},{805,90,45},Wood);
 Shape(TEXT("MirrorSill"),{0,190,25},{770,100,50},Wood);
 Mirror=Shape(TEXT("LiveWaterMirror"),{0,174,296},{700,540,1},Jade,nullptr,false);
 Mirror->SetStaticMesh(P.Object);Mirror->SetRelativeRotation(FRotator(0,0,90));Mirror->SetCastShadow(false);
 Shape(TEXT("MirrorTalismanPaper"),{387,135,310},{34,3,90},Paper,MirrorSeal,false,0,.5f);
 for(int i=0;i<5;i++)Shape(FString::Printf(TEXT("MirrorRune%d"),i),{387,132,280.f+i*14},{20,2,4},Gold,MirrorSeal,false,0,1);
 Label(TEXT("MirrorTitle"),TEXT("ONE MIRROR / TWO LOST NIGHTS"),{0,138,610},27);
 // West ground mark and east raised mark teach horizontal and vertical viewpoints.
 Shape(TEXT("WestViewMark"),{-720,-540,2},{230,230,4},Jade,nullptr,false,1,.3f);
 Label(TEXT("WestViewSign"),TEXT("I  /  OLD GALLERY"),{-820,-350,130},24);
 Shape(TEXT("ViewBalcony"),{850,-450,280},{340,430,40},Pale);
 for(int side:{-1,1}){
  Shape(FString::Printf(TEXT("BalconyLeg%d"),side),{850+side*132.f,-450,135},{24,340,270},Wood);
  Shape(FString::Printf(TEXT("BalconyRail%d"),side),{850+side*168.f,-440,342},{12,380,84},Wood);
 }
 Shape(TEXT("BalconyRearRail"),{850,-250,342},{340,12,84},Wood);
 Shape(TEXT("HighViewMark"),{850,-450,303},{180,180,4},Gold,nullptr,false,1,.5f);
 Label(TEXT("HighViewTitle"),TEXT("II  /  ROLL CALL"),{850,-265,400},23);
 Shape(TEXT("StairSocket"),{850,-1300,2},{295,140,4},Gold,nullptr,false,0,.3f);
 Label(TEXT("StairSocketLabel"),TEXT("PAPER STAIR"),{850,-1320,70},21);
 for(int i=0;i<12;i++){
  float h=(i+1)*25.f;
  Shape(FString::Printf(TEXT("PaperStep%d"),i),{850,-1250+i*50.f,h/2},{280,50,h},Paper,PaperStairs);
  Shape(FString::Printf(TEXT("StepEdge%d"),i),{850,-1274+i*50.f,h+1},{280,3,2},Jade,PaperStairs,false,0,.6f);
 }
 Shape(TEXT("StairPaperSeal"),{1001,-1281,70},{4,30,82},Paper,StairSeal,false,0,1);
 // The final facade is traversable only once its erased name is returned.
 for(int side:{-1,1})Shape(FString::Printf(TEXT("SealedFacade%d"),side),{side*850.f,1330,300},{1100,45,600},Pale);
 Shape(TEXT("FacadeHeader"),{0,1330,525},{600,45,150},Dark);
 Gate=Shape(TEXT("NamelessGate"),{0,1330,225},{600,45,450},Stone);
 Shape(TEXT("BlankNamePlaque"),{0,1295,540},{360,18,75},Paper);
 Label(TEXT("FacadeLabel"),TEXT("[ THE NAME WAS REMOVED ]"),{0,1280,570},22);
 Shape(TEXT("EndDesk"),{0,1550,80},{230,100,160},Wood);
 Shape(TEXT("OriginalOrder"),{0,1550,166},{130,75,8},Paper,nullptr,false);
 Label(TEXT("EndLabel"),TEXT("ORDER 17"),{0,1530,205},21);
 // A matching central outline makes the absent reality and intact old gallery comparable.
 for(int side:{-1,1}){
  Shape(FString::Printf(TEXT("BrokenColumn%d"),side),{side*310.f,800,72},{60,60,144},Pale);
  Shape(FString::Printf(TEXT("Rubble%d"),side),{side*270.f,700,35},{160,80,70},Stone)->SetRelativeRotation(FRotator(0,side*23.f,0));
 }
 Label(TEXT("EntryTitle"),TEXT("RAIN COURT / THE LOST SEVENTEENTH"),{0,-1500,280},28);
 Shape(TEXT("ClueStone"),{-430,-1190,68},{200,90,136},Dark);
 Label(TEXT("ClueStoneLabel"),TEXT("CHANGE YOUR VIEW"),{-430,-1240,130},18);
 // Each echo is separate physical geometry; walking into a fixed mirror changes realm.
 for(int realm=1;realm<=2;realm++){
  FVector O=RealmOffset(realm);FLinearColor Accent=realm==1?Gold:Jade;
  Shape(FString::Printf(TEXT("EchoFloor%d"),realm),O+FVector(0,100,-25),{2400,2900,50},realm==1?Pale:Stone);
  Shape(FString::Printf(TEXT("EchoBack%d"),realm),O+FVector(0,1530,340),{2450,40,680},Dark);
  for(int side:{-1,1}){
   Shape(FString::Printf(TEXT("EchoWall%d_%d"),realm,side),O+FVector(side*1220.f,100,320),{30,2900,640},Dark);
   for(int n=0;n<5;n++){
    FVector V=O+FVector(side*480.f,-530+n*400.f,235);
    Shape(FString::Printf(TEXT("EchoCol%d_%d_%d"),realm,side,n),V,{32,32,470},Accent,nullptr,true,1,.1f);
    Shape(FString::Printf(TEXT("EchoBeam%d_%d_%d"),realm,side,n),V+FVector(0,0,240),{100,420,24},Wood);
   }
   Shape(FString::Printf(TEXT("ReturnPost%d_%d"),realm,side),O+FVector(side*180.f,-1000,190),{20,25,380},Jade,nullptr,true,0,1);
  }
  Shape(FString::Printf(TEXT("ReturnTop%d"),realm),O+FVector(0,-1000,380),{380,25,20},Jade,nullptr,false,0,1);
  Label(FString::Printf(TEXT("ReturnText%d"),realm),TEXT("E / RETURN TO THE WATER SURFACE"),O+FVector(0,-995,400),23);
  Shape(FString::Printf(TEXT("EchoRoof%d"),realm),O+FVector(0,800,640),{2200,1100,32},Dark);
  Label(FString::Printf(TEXT("RealmTitle%d"),realm),realm==1?TEXT("BEFORE ERASURE / THE GALLERY"):TEXT("THE NIGHT OF THE ROLL CALL"),O+FVector(0,1480,540),34);
  for(int x:{-1,1}){
   auto* L=CreateDefaultSubobject<UPointLightComponent>(*FString::Printf(TEXT("EchoLight%d_%d"),realm,x));L->SetupAttachment(Root);L->SetRelativeLocation(O+FVector(x*480.f,800,430));L->SetIntensity(5000);L->SetAttenuationRadius(1400);L->SetLightColor(Accent);L->SetCastShadows(false);
  }
 }
 FVector Old=RealmOffset(1),Night=RealmOffset(2);
 Shape(TEXT("GalleryDesk"),Old+FVector(0,700,76),{300,120,152},Wood);
 Shape(TEXT("OldScroll"),Old+FVector(0,690,160),{250,100,5},Paper,StairDrawing,false);
 for(int i=0;i<6;i++)Shape(FString::Printf(TEXT("MiniStair%d"),i),Old+FVector(-95+i*38.f,690,172+i*13.f),{38,70,10},Jade,StairDrawing,false,0,1);
 Label(TEXT("GalleryHint"),TEXT("A STAIR REMEMBERED / E TO RECORD"),Old+FVector(0,710,340),24);
 // Above the water: blank nameplates. On the water: original name and court pairs.
 Shape(TEXT("Water_Night"),Night+FVector(0,840,7),{1120,610,8},Jade,nullptr,false,0,.12f);
 for(int i=0;i<3;i++){
  float x=(i-1)*350.f;
  Shape(FString::Printf(TEXT("BlankTablet%d"),i),Night+FVector(x,1100,250),{130,20,210},Paper);
  Shape(FString::Printf(TEXT("TabletString%d"),i),Night+FVector(x,1100,432),{3,3,155},Gold,nullptr,false);
  Shape(FString::Printf(TEXT("NameReflection%d"),i),Night+FVector(x,785,24),{230,220,8},Dark,WaterNames,false);
  Label(FString::Printf(TEXT("WaterNameText%d"),i),i==1?TEXT("17 / LU HENG / RAIN"):i==0?TEXT("09 / GU LING / CLOUD"):TEXT("23 / LIN SHU / STAR"),Night+FVector(x,810,70),15,WaterNames);
  for(int n=0;n<i+1;n++)Shape(FString::Printf(TEXT("TabletMark%d_%d"),i,n),Night+FVector(x-28+n*26,1086,205),{14,3,7},Gold,nullptr,false,0,.4f);
 }
 Label(TEXT("RollCallHint"),TEXT("ABOVE: EMPTY / BELOW: REMEMBERED"),Night+FVector(0,1450,410),25);
 auto* Moon=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("Moon"));Moon->SetupAttachment(Root);Moon->SetRelativeRotation(FRotator(-55,-35,0));Moon->SetIntensity(2.2f);Moon->SetForwardShadingPriority(1);Moon->SetLightColor(FLinearColor(.65f,.8f,1));
 auto* Fill=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("Fill"));Fill->SetupAttachment(Root);Fill->SetRelativeRotation(FRotator(-65,140,0));Fill->SetIntensity(.9f);Fill->SetCastShadows(false);
 for(int i=0;i<8;i++)Shape(FString::Printf(TEXT("FloatingStone%d"),i),{float((i%2?1:-1)*(2300+i*140)),float(-1700+i*480),float(-450+i*60)},{450,600,470},Dark,nullptr,false,2);
 Capture=CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("DifferentWorldInMirror"));Capture->SetupAttachment(Root);Capture->bCaptureEveryFrame=false;Capture->bCaptureOnMovement=false;Capture->CaptureSource=ESceneCaptureSource::SCS_FinalColorLDR;Capture->FOVAngle=80;
}
USceneComponent* AMirrorCourt::Group(const TCHAR* N){auto* G=CreateDefaultSubobject<USceneComponent>(N);G->SetupAttachment(Root);return G;}
UStaticMeshComponent* AMirrorCourt::Shape(const FString& N,FVector P,FVector Size,FLinearColor Col,USceneComponent* Parent,bool Solid,int32 Form,float Glow){
 auto* C=CreateDefaultSubobject<UStaticMeshComponent>(*N);C->SetupAttachment(Parent?Parent:Root.Get());C->SetStaticMesh(Form==1?Cylinder.Get():Form==2?Sphere.Get():Cube.Get());C->SetRelativeLocation(P);C->SetRelativeScale3D(Size/100);C->SetMaterial(0,BaseMaterial);C->SetMobility(EComponentMobility::Movable);C->SetCollisionProfileName(Solid?TEXT("BlockAll"):TEXT("NoCollision"));C->ComponentTags.Add(FName(*Col.ToString()));C->ComponentTags.Add(FName(*FString::SanitizeFloat(Glow)));if(Solid)C->ComponentTags.Add(TEXT("Solid"));return C;
}
void AMirrorCourt::Label(const FString& N,const FString& Text,FVector P,float Size,USceneComponent* Parent){auto* T=CreateDefaultSubobject<UTextRenderComponent>(*N);T->SetupAttachment(Parent?Parent:Root.Get());T->SetRelativeLocation(P);T->SetRelativeRotation(FRotator(0,-90,0));T->SetText(FText::FromString(Text));T->SetWorldSize(Size);T->SetHorizontalAlignment(EHTA_Center);T->SetTextRenderColor(FColor(185,224,214));}
void AMirrorCourt::Paint(){
 auto* Mat=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_Court.M_Court"));if(!Mat)return;
 TArray<UStaticMeshComponent*> Parts;GetComponents(Parts);for(auto* P:Parts)if(P->ComponentTags.Num()>=2){FLinearColor Col;Col.InitFromString(P->ComponentTags[0].ToString());auto* MID=P->CreateDynamicMaterialInstance(0,Mat);MID->SetVectorParameterValue(TEXT("Tint"),Col);MID->SetScalarParameterValue(TEXT("Glow"),FCString::Atof(*P->ComponentTags[1].ToString()));}
}
void AMirrorCourt::OnConstruction(const FTransform& T){Super::OnConstruction(T);Paint();TArray<UDirectionalLightComponent*> Lights;GetComponents(Lights);for(auto* L:Lights)L->SetForwardShadingPriority(L->GetName().Contains(TEXT("Moon"))?1:0);Refresh();}
void AMirrorCourt::BeginPlay(){
 Super::BeginPlay();Paint();TArray<UDirectionalLightComponent*> Lights;GetComponents(Lights);for(auto* L:Lights)L->SetForwardShadingPriority(L->GetName()==TEXT("Moon")?1:0);MirrorTexture=NewObject<UTextureRenderTarget2D>(this);MirrorTexture->RenderTargetFormat=RTF_RGBA8;MirrorTexture->ClearColor=FLinearColor(.025f,.08f,.10f);MirrorTexture->InitAutoFormat(896,672);MirrorTexture->UpdateResourceImmediate(true);Capture->TextureTarget=MirrorTexture;
 if(auto* Mat=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_LiveMirror.M_LiveMirror"))){auto* MID=Mirror->CreateDynamicMaterialInstance(0,Mat);MID->SetTextureParameterValue(TEXT("MirrorView"),MirrorTexture);}Refresh();
}
void AMirrorCourt::SetGroup(USceneComponent* G,bool Visible,bool Solid){G->SetVisibility(Visible,true);G->SetHiddenInGame(!Visible,true);TArray<USceneComponent*> Parts;G->GetChildrenComponents(true,Parts);for(auto* P:Parts)if(auto* M=Cast<UStaticMeshComponent>(P))M->SetCollisionEnabled(Visible&&Solid&&M->ComponentHasTag(TEXT("Solid"))?ECollisionEnabled::QueryAndPhysics:ECollisionEnabled::NoCollision);}
int32 AMirrorCourt::ViewFrom(FVector Eye)const{
 if(Eye.Y>20||FVector::Dist2D(Eye,MirrorPoint)>1850)return 0;
 const float Angle=FMath::RadiansToDegrees(FMath::Atan2(Eye.X,MirrorPoint.Y-Eye.Y));
 if(Angle<-22)return 1;
 // Height is above the highest possible ground jump, so the paper stair matters.
 if(Angle>28&&Eye.Z>380)return 2;
 return 0;
}
bool AMirrorCourt::OnStairs(FVector P)const{return bStairFixed&&FMath::Abs(P.X-850)<200&&P.Y>-1355&&P.Y<-220&&P.Z>105;}
void AMirrorCourt::Refresh(){
 const float Now=GetWorld()?GetWorld()->GetTimeSeconds():0;
 SetGroup(PaperStairs,bStairFixed||bPreview,bStairFixed);SetGroup(StairSeal,bStairFixed,false);SetGroup(MirrorSeal,FixedView>0,false);
 SetGroup(StairDrawing,!bRecorded,false);SetGroup(WaterNames,Realm==2&&Now<NameUntil,false);
 Gate->SetVisibility(!bGateFixed);Gate->SetHiddenInGame(bGateFixed);Gate->SetCollisionEnabled(bGateFixed?ECollisionEnabled::NoCollision:ECollisionEnabled::QueryAndPhysics);
 TArray<UTextRenderComponent*> Labels;GetComponents(Labels);for(auto* L:Labels)if(L->GetName()==TEXT("FacadeLabel"))L->SetText(FText::FromString(bGateFixed?TEXT("TING YU / RAIN COURT"):TEXT("[ THE NAME WAS REMOVED ]")));
}
void AMirrorCourt::Tick(float Dt){
 Super::Tick(Dt);auto* P=Cast<AMirrorPlayer>(UGameplayStatics::GetPlayerPawn(this,0));if(!P)return;
 ActiveView=FixedView?FixedView:Realm==0&&GetWorld()->GetTimeSeconds()<RevealUntil?ViewFrom(P->Camera->GetComponentLocation()):0;
 CaptureTime+=Dt;if(Realm==0&&CaptureTime>.083f&&MirrorTexture){
  CaptureTime=0;const FVector Eye=P->Camera->GetComponentLocation();
  FVector Pos=ActiveView?RealmOffset(ActiveView)+FVector(FMath::Clamp(-Eye.X*.20f,-240.f,240.f),-750,230):FVector(0,480,280);
  FVector Target=ActiveView?RealmOffset(ActiveView)+FVector(0,800,240):FVector(0,1300,240);
  Capture->SetWorldLocation(Pos);Capture->SetWorldRotation((Target-Pos).Rotation());Capture->CaptureScene();
 }Refresh();
}
FString AMirrorCourt::ViewName()const{return ActiveView==1?TEXT("旧廊 / 阶梯尚在"):ActiveView==2?TEXT("点名之夜 / 水底留名"):TEXT("现世 / 无名废院");}
FString AMirrorCourt::Objective()const{
 if(bComplete)return TEXT("调查完成：听雨院仍在，只是被从可见的世界中抹去。J 查看手记。");
 if(bGateFixed)return TEXT("07 / 穿过恢复名称的院门，阅读院内的封院令。");
 if(bEvidence)return TEXT("06 / 带回原名，回收一张符；到北侧无名院门前按 F 归还院名。");
 if(Realm==2)return TEXT("05 / 木牌一片空白。到池边摇铃，低头寻找第十七名对应的倒影。");
 if(FixedView==2)return TEXT("05 / 点名之夜已固定。下阶梯，走近水镜 E 进入，寻找水中保留的原名。");
 if(bStairFixed)return TEXT("04 / 登上东侧高台，揭下旧镜符，再摇铃观察另一段过去并按 F 固定。");
 if(bCut)return TEXT("03 / 回到现世，在东侧金色缺口 E 取出阶梯、F 自动吸附。");
 if(bRecorded)return TEXT("02 / C 展开画卷，沿亮点裁出旧廊里的阶梯画片。");
 if(Realm==1)return TEXT("02 / 镜中旧廊保存着阶梯。走到尽头的画卷台，E 收录。");
 return TEXT("01 / 到西侧青色圆台，面向水镜摇铃；F 固定旧景，走近水镜按 E 进入。");
}

AMirrorPlayer::AMirrorPlayer(){
 PrimaryActorTick.bCanEverTick=true;GetCapsuleComponent()->InitCapsuleSize(32,88);
 Camera=CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));Camera->SetupAttachment(GetCapsuleComponent());Camera->SetRelativeLocation({0,0,66});Camera->bUsePawnControlRotation=true;Camera->SetFieldOfView(86);
 bUseControllerRotationYaw=true;GetCharacterMovement()->MaxWalkSpeed=390;GetCharacterMovement()->MaxStepHeight=30;GetCharacterMovement()->JumpZVelocity=370;GetCharacterMovement()->AirControl=.15f;
 static ConstructorHelpers::FObjectFinder<UStaticMesh> Rod(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
 auto* Wand=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Wand"));Wand->SetupAttachment(Camera);Wand->SetStaticMesh(Rod.Object);Wand->SetRelativeLocation({47,24,-32});Wand->SetRelativeScale3D({.032f,.032f,.63f});Wand->SetRelativeRotation(FRotator(-25,0,0));Wand->SetCollisionEnabled(ECollisionEnabled::NoCollision);Wand->SetCastShadow(false);
 auto* Bell=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Bell"));Bell->SetupAttachment(Camera);Bell->SetStaticMesh(Rod.Object);Bell->SetRelativeLocation({45,-23,-25});Bell->SetRelativeScale3D({.10f,.10f,.095f});Bell->SetCollisionEnabled(ECollisionEnabled::NoCollision);Bell->SetCastShadow(false);
}
AMirrorGameMode::AMirrorGameMode(){DefaultPawnClass=AMirrorPlayer::StaticClass();HUDClass=AMirrorHUD::StaticClass();}
void AMirrorPlayer::BeginPlay(){Super::BeginPlay();for(TActorIterator<AMirrorCourt> It(GetWorld());It;++It){Puzzle=*It;break;}UE_LOG(LogTemp,Display,TEXT("MIRROR_LEVEL_READY: Pawn=%s Puzzle=%s"),*GetNameSafe(this),*GetNameSafe(Puzzle));Say(TEXT("循着池底的“听雨院·陆衡”，你走到一面水镜前。现实是废院，镜中却有未毁的屋檐。"),12);}
void AMirrorPlayer::SetupPlayerInputComponent(UInputComponent* I){
 Super::SetupPlayerInputComponent(I);I->BindAxis(TEXT("Forward"),this,&AMirrorPlayer::Forward);I->BindAxis(TEXT("Right"),this,&AMirrorPlayer::Right);I->BindAxis(TEXT("Turn"),this,&AMirrorPlayer::Turn);I->BindAxis(TEXT("Look"),this,&AMirrorPlayer::Look);
 I->BindKey(EKeys::SpaceBar,IE_Pressed,this,&AMirrorPlayer::JumpStart);I->BindKey(EKeys::SpaceBar,IE_Released,this,&ACharacter::StopJumping);
 I->BindKey(EKeys::B,IE_Pressed,this,&AMirrorPlayer::Bell);I->BindKey(EKeys::E,IE_Pressed,this,&AMirrorPlayer::Interact);I->BindKey(EKeys::C,IE_Pressed,this,&AMirrorPlayer::Cut);I->BindKey(EKeys::F,IE_Pressed,this,&AMirrorPlayer::Fix);I->BindKey(EKeys::G,IE_Pressed,this,&AMirrorPlayer::Recall);I->BindKey(EKeys::Tab,IE_Pressed,this,&AMirrorPlayer::Cancel);I->BindKey(EKeys::J,IE_Pressed,this,&AMirrorPlayer::Journal);I->BindKey(EKeys::Home,IE_Pressed,this,&AMirrorPlayer::Recover);I->BindKey(EKeys::F5,IE_Pressed,this,&AMirrorPlayer::RestartPuzzle);
}
void AMirrorPlayer::Forward(float V){if(!bCutting&&!bJournal)AddMovementInput(FRotator(0,GetControlRotation().Yaw,0).Vector(),V);}
void AMirrorPlayer::Right(float V){if(!bCutting&&!bJournal)AddMovementInput(FRotationMatrix(FRotator(0,GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::Y),V);}
void AMirrorPlayer::Turn(float V){if(!bCutting&&!bJournal)AddControllerYawInput(V);}
void AMirrorPlayer::Look(float V){if(!bCutting&&!bJournal)AddControllerPitchInput(V);}
void AMirrorPlayer::JumpStart(){if(!bCutting&&!bJournal)Jump();}
void AMirrorPlayer::Say(const FString& T,float D){Notice=T;NoticeUntil=GetWorld()->GetTimeSeconds()+D;}
bool AMirrorPlayer::Near(FVector V,float D,bool Facing)const{return FVector::Dist(Camera->GetComponentLocation(),V)<D&&(!Facing||FVector::DotProduct(GetViewRotation().Vector(),(V-Camera->GetComponentLocation()).GetSafeNormal())>.5f);}
void AMirrorPlayer::Bell(){
 if(!Puzzle||bCutting||bJournal)return;float Now=GetWorld()->GetTimeSeconds();if(Now-LastBell<.8f)return;LastBell=Now;
 if(auto* A=LoadObject<USoundBase>(nullptr,TEXT("/Game/Audio/Bell.Bell")))UGameplayStatics::PlaySoundAtLocation(this,A,Camera->GetComponentLocation(),.6f);
 auto* R=Puzzle.Get();R->bHeard=true;
 if(R->Realm==0){R->RevealUntil=Now+18;Say(R->FixedView?TEXT("符固定了上一次看到的旧景。先 G 揭符，再换站位观察水镜。"):TEXT("水镜回应：低处左侧是旧廊，右侧高处是点名之夜。换站位，观察镜面；F 可留住这一刻。"),9);}
 else if(R->Realm==2){R->NameUntil=Now+20;Say(TEXT("头上的木牌全是空白，水中却留下原名。低头对准倒影，找出与上关“第十七名·陆衡·听雨院”相符的一块。"),10);}
 else Say(TEXT("旧廊残声：“阶梯没有消失，它还留在那幅画里。”到尽头画卷台按 E。"));R->Refresh();
}
void AMirrorPlayer::Travel(int32 Realm){
 auto* R=Puzzle.Get();if(!R)return;Cancel();R->Realm=Realm;GetCharacterMovement()->StopMovementImmediately();SetActorLocation(Realm?R->RealmOffset(Realm)+FVector(0,-750,92):FVector(0,-370,92),false,nullptr,ETeleportType::TeleportPhysics);Controller->SetControlRotation(FRotator(0,Realm?90:-90,0));R->Refresh();
 Say(Realm==1?TEXT("你进入了未被抹除的旧廊。回程的青色门框就在身后。"):Realm==2?TEXT("你进入点名之夜。姓名从木牌上消失，却没有从水中消失。摇铃查看。"):TEXT("已回到现世。画卷与找到的线索可以带出水镜。"));
}
void AMirrorPlayer::Interact(){
 if(!Puzzle||bCutting||bJournal)return;auto* R=Puzzle.Get();FVector O=R->RealmOffset(R->Realm);
 if(R->Realm){
  if(Near(O+FVector(0,-1000,170),450)){Travel(0);return;}
  if(R->Realm==1&&Near(O+FVector(0,700,170),370)){
   if(!R->bRecorded){R->bRecorded=true;R->Refresh();Say(TEXT("阶梯旧景已收进画卷。C 裁画，然后从身后的青色门框返回现世。"));}else Say(TEXT("阶梯已经收录，只有一份画片。C 裁出后可带回现实。"));return;
  }
  if(R->Realm==2){
   for(int i=0;i<3;i++)if(Near(O+FVector((i-1)*350.f,785,55),310)){
    if(GetWorld()->GetTimeSeconds()>=R->NameUntil){Say(TEXT("水面没有可读的名字，按 B 再次显影。"));return;}
    if(i!=1){Say(i==0?TEXT("第九名·顾苓·栖霞院。这不是档案中被删去的第十七名。"):TEXT("第二十三名·林疏·问星院。编号与上一关的证据不符。"));return;}
    R->bEvidence=true;Say(FString::Printf(TEXT("第十七名·%s·%s。原名已拓进画卷。返回现世，将院名归还北侧无名门。"),*R->MissingStudent,*R->MissingCourt),12);return;
   }
  }
 }else{
  if(R->FixedView&&Near(R->MirrorPoint,700)){Travel(R->FixedView);return;}
  if(R->bCut&&!R->bStairFixed&&Near(R->StairBase,400,false)){R->bPreview=!R->bPreview;R->Refresh();Say(TEXT("阶梯画片已放在金色缺口。按 F 自动贴合并固定，不需要手动调整角度。"));return;}
  if(R->bGateFixed&&Near({0,1550,170},330)){R->bComplete=true;Say(TEXT("封院令：第十七院不得被看见，原名转存水中。签署页被撕去——你找到了院落，却还不知道是谁抹去了它。"),15);return;}
  if(Near(R->GatePoint,450)){Say(R->bEvidence?TEXT("原名已有证据。需要一张空闲符纸，按 F 将“听雨院”固定在门上。"):TEXT("门上没有锁，只有被刮去的院名。要找回与第十七名学生对应的原名。"));return;}
 }
 Say(R->Realm?TEXT("对准画卷、青色回程门或铃声显露的水中名字，再按 E。"):TEXT("换站位观察水镜，B 显影、F 固定旧景，靠近水镜 E 进入。"));
}
void AMirrorPlayer::Cut(){
 if(!Puzzle||bJournal)return;if(bCutting){Cancel();return;}if(!Puzzle->bRecorded){Say(TEXT("先从旧廊的画卷台收录阶梯。"));return;}if(Puzzle->bCut){Say(TEXT("阶梯画片已经裁好。现世东侧金色缺口 E 放置、F 固定。"));return;}
 bCutting=true;CutProgress=0;GetCharacterMovement()->StopMovementImmediately();if(auto* PC=Cast<APlayerController>(Controller)){PC->bShowMouseCursor=true;FInputModeGameAndUI Mode;Mode.SetHideCursorDuringCapture(false);Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);PC->SetInputMode(Mode);}
}
void AMirrorPlayer::CutSample(FVector2D V,FVector2D Size,bool Held){if(!bCutting||!Held)return;auto P=AAcademyPlayer::CutPoints(Size);if(P.IsValidIndex(CutProgress)&&FVector2D::Distance(V,P[CutProgress])<FMath::Max(28.f,float(Size.X)*.025f)){CutProgress++;if(CutProgress==P.Num()){Puzzle->bCut=true;Cancel();Say(TEXT("阶梯裁好了。返回现世东侧金色缺口，将旧景拼成通往高台的路。"));}}}
void AMirrorPlayer::Fix(){
 if(!Puzzle||bCutting||bJournal)return;auto* R=Puzzle.Get();if(R->Realm){Say(TEXT("镜中旧景不能在内部揭换。先从青色门框返回现世。"));return;}
 if(R->Symbols()==0){Say(TEXT("两张符都在使用。G 预览回收水镜或阶梯上的符，再按一次确认。"));return;}
 if(R->bPreview&&R->bCut&&!R->bStairFixed&&Near(R->StairBase,500,false)){R->bStairFixed=true;R->bPreview=false;R->Refresh();Say(TEXT("画阶已自动贴合。沿阶梯登上东侧高台，观察水镜的新角度。"));return;}
 if(Near(R->GatePoint,450)){
  if(!R->bEvidence){Say(TEXT("尚未得到原名证据。水镜另一角度隐藏了点名之夜。"));return;}if(R->bGateFixed)return;R->bGateFixed=true;R->Refresh();Say(TEXT("听雨院的名称重新显现，院门已恢复。穿过门，查看封院令。"));return;
 }
 if(!R->FixedView&&Near(R->MirrorPoint,2100)){
  int32 V=R->ViewFrom(Camera->GetComponentLocation());if(GetWorld()->GetTimeSeconds()>=R->RevealUntil||V==0){Say(TEXT("这个角度只有现世。先摇铃，再到西侧低台或东侧高台看水镜。"));return;}
  R->FixedView=V;R->ActiveView=V;R->Refresh();Say(TEXT("这一角度的世界已被符纸固定。可以离开观察台，走近镜面按 E 进入。"));return;
 }
 Say(TEXT("对准显影中的水镜、阶梯预览或无名院门，再贴符。"));
}
void AMirrorPlayer::Recall(){
 if(!Puzzle||bCutting||bJournal)return;auto* R=Puzzle.Get();if(R->Realm){Say(TEXT("你还在镜内，不能撤走唯一出口。先返回现世。"));return;}
 int32 Target=0;
 // Select the target nearest the crosshair, so the large mirror interaction
 // range cannot steal a recall intended for the stair beneath it.
 float Best=.65f;
 auto Consider=[&](int32 Id,FVector Point,float Range,bool Enabled){if(!Enabled||!Near(Point,Range,false))return;float Aim=FVector::DotProduct(GetViewRotation().Vector(),(Point-Camera->GetComponentLocation()).GetSafeNormal());if(Aim>Best){Best=Aim;Target=Id;}};
 Consider(1,R->MirrorPoint,2100,R->FixedView>0);Consider(2,R->StairBase,650,R->bStairFixed);Consider(3,R->GatePoint,470,R->bGateFixed&&GetActorLocation().Y<1260);
 if(!Target){Say(TEXT("对准水镜或回到阶梯底部，可以回收符纸。"));return;}
 if(Target==2&&R->OnStairs(GetActorLocation())){Say(TEXT("先走下阶梯，避免撤走脚下或高台唯一的回程路。"));return;}
 float Now=GetWorld()->GetTimeSeconds();if(RecallTarget!=Target||RecallUntil<Now){RecallTarget=Target;RecallUntil=Now+6;Say(Target==1?TEXT("预告：镜中通道将关闭，符纸退回。再次 G 确认；Tab 取消。"):Target==2?TEXT("预告：整座画阶将收回画卷。再次 G 确认；Tab 取消。"):TEXT("预告：院门将重新封闭。再次 G 确认；Tab 取消。"));return;}
 if(Target==1){R->FixedView=0;R->ActiveView=0;}if(Target==2)R->bStairFixed=false;if(Target==3)R->bGateFixed=false;RecallTarget=0;R->Refresh();Say(TEXT("符纸已回收。已有画片与调查证据保留，可以重新组合。"));
}
void AMirrorPlayer::Cancel(){bCutting=false;bJournal=false;RecallTarget=0;if(Puzzle){Puzzle->bPreview=false;Puzzle->Refresh();}if(auto* PC=Cast<APlayerController>(Controller)){PC->bShowMouseCursor=false;PC->SetInputMode(FInputModeGameOnly());}}
void AMirrorPlayer::Journal(){if(bCutting)return;bJournal=!bJournal;GetCharacterMovement()->StopMovementImmediately();}
void AMirrorPlayer::Recover(){if(!Puzzle)return;Travel(0);SetActorLocation({0,-1390,92},false,nullptr,ETeleportType::TeleportPhysics);Controller->SetControlRotation(FRotator(0,90,0));Say(TEXT("已返回现世入口，保留画片、符纸状态和调查证据。"));}
void AMirrorPlayer::RestartPuzzle(){UGameplayStatics::OpenLevel(this,TEXT("/Game/Maps/RainMirrorCourt"));}
void AMirrorPlayer::Tick(float Dt){
 Super::Tick(Dt);if(!Puzzle)return;if(GetActorLocation().Z<-70)Recover();
 if(bCutting){auto* PC=Cast<APlayerController>(Controller);float X=0,Y=0;int32 W=0,H=0;PC->GetViewportSize(W,H);if(PC->GetMousePosition(X,Y))CutSample({X,Y},{float(W),float(H)},PC->IsInputKeyDown(EKeys::LeftMouseButton));}
 if(RecallTarget&&GetWorld()->GetTimeSeconds()>RecallUntil)RecallTarget=0;
 if(FParse::Param(FCommandLine::Get(),TEXT("MirrorVerify")))Verify(Dt);
}
FString AMirrorPlayer::Prompt()const{
 auto* R=Puzzle.Get();if(!R)return TEXT("");FVector O=R->RealmOffset(R->Realm);
 if(R->Realm){
  if(Near(O+FVector(0,-1000,170),450))return TEXT("E  离开镜中世界 / 返回现世");
  if(R->Realm==1&&Near(O+FVector(0,700,170),400))return R->bRecorded?TEXT("C  裁出阶梯画片"):TEXT("E  收录旧廊里的阶梯");
  if(R->Realm==2&&Near(O+FVector(0,800,40),900,false))return GetWorld()->GetTimeSeconds()<R->NameUntil?TEXT("水中：左 09·栖霞 / 中 17·听雨 / 右 23·问星；走近对应倒影按 E"):TEXT("B  摇铃，观察空白木牌下方的水面");
  return TEXT("回程门在身后，沿回廊向前调查");
 }
 if(R->bGateFixed&&Near({0,1550,170},330))return TEXT("E  阅读封院令 / 完成本关");
 if(Near(R->GatePoint,450))return R->bEvidence?TEXT("F  将原名归还院门；需要一张空闲符纸"):TEXT("E  检查被刮去的院名");
 if(R->bPreview)return TEXT("F  自动贴合阶梯    Tab  收起画片");
 if(R->bCut&&!R->bStairFixed&&Near(R->StairBase,400,false))return TEXT("E  用仙杖取出阶梯画片");
 if(R->FixedView&&Near(R->MirrorPoint,700))return TEXT("E  进入已固定的镜中世界    G  揭符");
 if(Near(R->MirrorPoint,2100))return R->FixedView?TEXT("镜中世界已固定；G 两次揭符，才能换角度"):GetWorld()->GetTimeSeconds()<R->RevealUntil&&R->ViewFrom(Camera->GetComponentLocation())>0?TEXT("这个角度出现了不同的过去！F 固定，走近水镜 E 进入"):TEXT("B 摇铃显影；西侧低台看旧廊，东侧高台看点名之夜");
 return TEXT("B 铃铛显影    J 调查手记");
}

void AMirrorHUD::DrawHUD(){
 Super::DrawHUD();auto* P=Cast<AMirrorPlayer>(GetOwningPawn());if(!Canvas||!P||!P->Puzzle)return;auto* R=P->Puzzle.Get();
 float W=Canvas->SizeX,H=Canvas->SizeY,S=FMath::Min(W/1440.f,H/900.f);const FLinearColor Jade(.4f,.92f,.82f),Gold(1,.76f,.38f),Muted(.68f,.77f,.8f);
 UFont* Font=LoadObject<UFont>(nullptr,TEXT("/Engine/EngineFonts/Roboto.Roboto"));if(!Font)Font=GEngine->GetMediumFont();
 auto Text=[&](const FString& T,float X,float Y,float Size=1.f,FLinearColor Col=FLinearColor::White){DrawText(T,Col,X,Y,Font,Size*S*1.4f,false);};
 auto Panel=[&](float X,float Y,float A,float B){DrawRect(FLinearColor(.018f,.035f,.05f,.94f),X,Y,A,B);};
 Panel(24*S,20*S,W-48*S,110*S);DrawRect(Jade,24*S,20*S,4*S,110*S);
 Text(TEXT("浮空书院  /  听雨院·照影台"),44*S,30*S,1.3f,Jade);Text(R->Objective(),44*S,83*S,.80f);
 Text(FString::Printf(TEXT("符纸 %d / 2"),R->Symbols()),W-174*S,33*S,.92f,Gold);
 Panel(24*S,H-92*S,W-48*S,70*S);Text(TEXT("WASD 移动   鼠标 观察   Space 跳跃   B 显影   E 交互 / 入镜   C 裁画   F 贴符   G 两次揭符"),44*S,H-80*S,.77f,Muted);
 Text(TEXT("J 手记   Tab 收起 / 取消   Home 返回现世（保留进度）   F5 重玩本关"),44*S,H-50*S,.77f,Muted);
 if(!P->bJournal&&!P->bCutting){
  DrawLine(W/2-5,H/2,W/2+5,H/2,Jade,1);DrawLine(W/2,H/2-5,W/2,H/2+5,Jade,1);
  Panel(24*S,148*S,376*S,100*S);Text(R->Realm==0?TEXT("所在 / 现世水上庭院"):R->Realm==1?TEXT("所在 / 镜中旧廊"):TEXT("所在 / 镜中点名之夜"),42*S,160*S,.93f,Gold);
  Text(R->Realm?TEXT("出口仍在身后的青色门框"):TEXT("镜面 / ")+R->ViewName(),42*S,193*S,.83f,Jade);
  if(!R->Realm)Text(R->FixedView?TEXT("已固定 · 换站位也会保持"):GetWorld()->GetTimeSeconds()<R->RevealUntil?FString::Printf(TEXT("显影 %.0f 秒 · 可重复摇铃"),R->RevealUntil-GetWorld()->GetTimeSeconds()):TEXT("未显影 · 按 B 摇铃"),42*S,223*S,.74f,Muted);
  Panel(W*.08f,H*.72f,W*.84f,44*S);Text(P->Prompt(),W*.10f,H*.72f+11*S,.78f,Jade);
  if(GetWorld()->GetTimeSeconds()<P->NoticeUntil){Panel(24*S,H-155*S,W-48*S,50*S);Text(P->Notice,42*S,H-141*S,.72f);}
  if(R->bComplete){Panel(W*.20f,H*.30f,W*.60f,160*S);Text(TEXT("听雨院重新被看见"),W*.24f,H*.30f+20*S,1.5f,Gold);Text(TEXT("原名与封院令相互印证；签署页却被撕去了。"),W*.24f,H*.30f+70*S,.93f);Text(TEXT("你知道了被隐藏的院落所在，原因与幕后者仍待调查。"),W*.24f,H*.30f+110*S,.79f,Jade);}
 }
 if(P->bCutting){
  Panel(W*.14f,H*.20f,W*.72f,H*.57f);Text(TEXT("徒手裁画 / 将旧廊的阶梯带回现世"),W*.21f,H*.23f,1.15f,Gold);
  DrawRect(Rain::Paper,W*.24f,H*.32f,W*.52f,H*.36f);auto Points=AAcademyPlayer::CutPoints({W,H});
  for(int i=0;i<Points.Num()-1;i++)DrawLine(Points[i].X,Points[i].Y,Points[i+1].X,Points[i+1].Y,i<P->CutProgress?Jade:Rain::Dark,3*S);
  for(int i=0;i<6;i++)DrawRect(Rain::Dark,W*(.34f+i*.052f),H*(.59f-i*.027f),W*.05f,H*(.025f+i*.027f));
  if(Points.IsValidIndex(P->CutProgress)){auto V=Points[P->CutProgress];DrawRect(Gold,V.X-10*S,V.Y-10*S,20*S,20*S);}
  Text(TEXT("按住鼠标左键，依次沿金色亮点描过边界；Tab 收起。"),W*.21f,H*.71f,.85f,Jade);
 }
 if(P->bJournal){
  Panel(W*.11f,H*.17f,W*.78f,H*.67f);Text(TEXT("调查手记 / 留住一段视角，而非一面镜子"),W*.15f,H*.20f,1.28f,Gold);
  TArray<FString> Lines={
   FString::Printf(TEXT("上一关证据：档案第十七条与池底原文，对应 %s · %s。"),*R->MissingStudent,*R->MissingCourt),
   TEXT("新规则：铃声让水镜显露旧景；左右站位和高度决定看见哪段过去。"),
   TEXT("西侧青色低台：旧廊。东侧金色高台：点名之夜。"),
   TEXT("F 留住当前镜中世界，离开观察台也不会改变；靠近镜面 E 进入。"),
   R->bRecorded?TEXT("已发现阶梯：C 裁画，回现世东侧 E 放置，再 F 自动吸附。"):TEXT("旧廊尽头的画卷台保存着阶梯。取回它，才能到达现实高台。"),
   TEXT("换镜中世界前，先在现世对准镜面 G 两次回收符。"),
   R->bEvidence?TEXT("点名之夜：空白木牌下的水中保留了第十七名原文，已拓印。"):TEXT("点名之夜：在水边摇铃，对照编号和姓名，E 拓印正确的倒影。"),
   TEXT("只有两张符：门前缺符时，可回收镜符或地面的阶梯符；证据不会丢失。"),
   R->bComplete?TEXT("封院令只命令“不得被看见”；签署页缺失，动机仍然未知。"):TEXT("带原名回北侧院门，F 归还院名，穿门后 E 阅读封院令。")};
  for(int i=0;i<Lines.Num();i++)Text(Lines[i],W*.15f,H*.28f+i*42*S,.83f,i==6&&R->bEvidence?Jade:FLinearColor::White);
  Text(TEXT("J / Tab 关闭。Home 可安全返回现世入口，保留调查状态。"),W*.15f,H*.78f,.77f,Muted);
 }
}

// This opt-in engine test drives the same methods as actual input. Traversal
// steps use CharacterMovement against the real stairs and final gate collision.
void AMirrorPlayer::Verify(float Dt){
 static int Stage=0;static float Time=0;static FString Report;static FVector Start;
 if(Stage<0)return;Time+=Dt;auto* R=Puzzle.Get();
 auto Check=[&](bool Good,const TCHAR* Name){Report+=FString::Printf(TEXT("%s: %s\n"),Good?TEXT("PASS"):TEXT("FAIL"),Name);UE_LOG(LogTemp,Display,TEXT("MIRROR_VERIFY %s: %s"),Good?TEXT("PASS"):TEXT("FAIL"),Name);FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("MirrorVerification.txt")));if(!Good)Stage=-1;return Good;};
 auto Snap=[&](FVector V){GetCharacterMovement()->StopMovementImmediately();SetActorLocation(V,false,nullptr,ETeleportType::TeleportPhysics);};
 auto Face=[&](FVector V){Controller->SetControlRotation((V-Camera->GetComponentLocation()).Rotation());};
 auto Shot=[&](const TCHAR* N){FScreenshotRequest::RequestScreenshot(FPaths::ProjectSavedDir()/TEXT("Screenshots")/N,true,false);};
 if(Stage==1&&FVector::Dist2D(Start,GetActorLocation())<230&&Time<3){Forward(1);return;}
 if(Stage==12&&GetActorLocation().Y<-465&&Time<5){Forward(1);return;}
 if(Stage==25&&GetActorLocation().Y<1470&&Time<4){Forward(1);return;}
 if(Time<(Stage==2?.2f:Stage==0?4.f:.9f))return;
 switch(Stage){
 case 0:if(!Check(Camera->bUsePawnControlRotation&&R->Symbols()==2&&R->Realm==0,TEXT("First-person start in real world with two talismans")))return;
  if(!Check(R->MirrorTexture&&R->Capture->TextureTarget==R->MirrorTexture,TEXT("Mirror displays a live render target of built echo geometry")))return;Face({0,180,270});Start=GetActorLocation();Shot(TEXT("01_RainCourt.png"));break;
 case 1:if(!Check(FVector::Dist2D(Start,GetActorLocation())>180,TEXT("WASD movement changes physical location")))return;Start=GetActorLocation();Jump();break;
 case 2:if(!Check(GetActorLocation().Z>Start.Z+10,TEXT("Space jump works")))return;StopJumping();Snap({0,-540,92});Face(R->MirrorPoint);Bell();Fix();if(!Check(R->FixedView==0&&R->Symbols()==2,TEXT("Front view cannot create an entry or spend a seal")))return;Snap({-720,-540,92});Face(R->MirrorPoint);R->RevealUntil=0;Fix();if(!Check(!R->FixedView,TEXT("Hidden view cannot be fixed before ringing bell")))return;LastBell=-10;Bell();break;
 case 3:if(!Check(R->ActiveView==1,TEXT("West physical viewpoint reveals the intact old gallery")))return;Fix();if(!Check(R->FixedView==1&&R->Symbols()==1,TEXT("Talisman fixes the observed world")))return;Shot(TEXT("02_WestMirror.png"));break;
 case 4:Snap({750,-500,92});Face(R->MirrorPoint);if(!Check(R->ActiveView==1,TEXT("Fixed mirror persists after walking to a different angle")))return;Snap({0,-360,92});Face(R->MirrorPoint);Interact();if(!Check(R->Realm==1&&GetActorLocation().X>11000,TEXT("Enter a separate physically built mirror world")))return;Recall();if(!Check(R->FixedView==1,TEXT("Cannot remove only return path while inside mirror")))return;Shot(TEXT("03_InsideGallery.png"));break;
 case 5:Snap(R->RealmOffset(1)+FVector(0,410,92));Face(R->RealmOffset(1)+FVector(0,700,170));Interact();if(!Check(R->bRecorded&&!R->bCut,TEXT("Record the unique stair memory from old gallery")))return;Cut();Shot(TEXT("04_CutStair.png"));break;
 case 6:if(!Check(bCutting,TEXT("Mouse tracing canvas opens for the stair painting")))return;CutSample({0,0},{1440,900},true);if(!Check(CutProgress==0,TEXT("Tracing outside border does not complete cutting")))return;for(auto V:AAcademyPlayer::CutPoints({1440,900}))CutSample(V,{1440,900},true);if(!Check(R->bCut&&!bCutting,TEXT("Tracing the boundary yields one usable stair painting")))return;break;
 case 7:Snap(R->RealmOffset(1)+FVector(0,-740,92));Face(R->RealmOffset(1)+FVector(0,-1000,170));Interact();if(!Check(R->Realm==0&&R->bCut,TEXT("Exit mirror while retaining collected painting")))return;Snap({850,-1500,92});Face(R->StairBase);Interact();break;
 case 8:if(!Check(R->bPreview&&!R->bStairFixed,TEXT("Stair preview does not yet create collision")))return;Fix();if(!Check(R->bStairFixed&&R->Symbols()==0,TEXT("Default stair placement auto-snaps and consumes second seal")))return;Fix();if(!Check(R->Symbols()==0,TEXT("Repeated fix cannot duplicate stair or overspend seals")))return;Face({850,-580,200});Shot(TEXT("05_RealStair.png"));break;
 case 9:Face(R->MirrorPoint);Recall();if(!Check(RecallTarget==1&&R->FixedView==1,TEXT("Recall previews removal before changing the route")))return;Cancel();if(!Check(R->FixedView==1&&RecallTarget==0,TEXT("Recall cancellation preserves mirror")))return;Recall();Recall();if(!Check(!R->FixedView&&R->Symbols()==1,TEXT("Old view released and seal refunded")))return;break;
 case 10:if(!Check(R->ViewFrom({850,-500,250})==0,TEXT("Ground height cannot unlock high roll-call viewpoint")))return;Snap({850,-1460,92});Controller->SetControlRotation(FRotator(0,90,0));break;
 case 11:Start=GetActorLocation();break;
 case 12:UE_LOG(LogTemp,Display,TEXT("MIRROR_STAIR End=%s"),*GetActorLocation().ToString());if(!Check(GetActorLocation().Y>-520&&GetActorLocation().Z>360,TEXT("Character physically climbs twelve steps onto raised viewpoint")))return;Face(R->MirrorPoint);LastBell=-10;Bell();break;
 case 13:if(!Check(R->ActiveView==2,TEXT("East elevated viewpoint reveals different roll-call world")))return;Shot(TEXT("06_HighMirror.png"));Fix();if(!Check(R->FixedView==2&&R->Symbols()==0,TEXT("Second time-layer fixed with the recovered seal")))return;break;
 case 14:Snap({850,-980,270});Face(R->StairBase);Recall();if(!Check(R->bStairFixed,TEXT("Cannot withdraw stair under the player's feet")))return;Snap({0,-360,92});Face(R->MirrorPoint);Interact();if(!Check(R->Realm==2,TEXT("Same water mirror now enters the selected second world")))return;Snap(R->RealmOffset(2)+FVector(0,540,92));Face(R->RealmOffset(2)+FVector(0,785,55));Interact();if(!Check(!R->bEvidence,TEXT("Names cannot be collected without revealing the water")))return;LastBell=-10;Bell();break;
 case 15:Shot(TEXT("07_RollCall.png"));Snap(R->RealmOffset(2)+FVector(-350,550,92));Face(R->RealmOffset(2)+FVector(-350,785,55));Interact();if(!Check(!R->bEvidence,TEXT("Wrong student's reflection is rejected without consuming resources")))return;Snap(R->RealmOffset(2)+FVector(0,550,92));Face(R->RealmOffset(2)+FVector(0,785,55));Interact();if(!Check(R->bEvidence,TEXT("Correct seventeenth student's water record supplies original court name")))return;break;
 case 16:R->NameUntil=0;R->Refresh();if(!Check(!R->WaterNames->IsVisible()&&R->bEvidence,TEXT("Reveal expiry preserves acquired narrative evidence")))return;Snap(R->RealmOffset(2)+FVector(0,-740,92));Face(R->RealmOffset(2)+FVector(0,-1000,170));Interact();break;
 case 17:Snap({0,1040,92});Face(R->GatePoint);Fix();if(!Check(!R->bGateFixed&&R->Symbols()==0,TEXT("Final gate requires freeing a talisman rather than granting an extra one")))return;Snap({850,-1490,92});Face(R->StairBase);Recall();Recall();if(!Check(!R->bStairFixed&&R->Symbols()==1&&R->bCut,TEXT("Stair and its seal can be reclaimed after returning to ground")))return;break;
 case 18:Interact();Fix();if(!Check(R->bStairFixed&&R->Symbols()==0,TEXT("Single recovered stair painting can be reused")))return;Face(R->MirrorPoint);Recall();Recall();if(!Check(!R->FixedView&&R->Symbols()==1,TEXT("Mirror seal is an alternate valid solution for freeing the final seal")))return;break;
 case 19:Snap({0,1040,92});Face(R->GatePoint);Fix();if(!Check(R->bGateFixed&&!R->Gate->IsCollisionEnabled()&&R->Symbols()==0,TEXT("Returning original name opens the real gate with correct resource accounting")))return;Shot(TEXT("08_RestoredGate.png"));break;
 case 20:Recall();Recall();if(!Check(!R->bGateFixed&&R->Gate->IsCollisionEnabled()&&R->Symbols()==1,TEXT("Gate restoration is reversible from the safe side")))return;Fix();break;
 case 21:Snap({0,-1000,-120});break;
 case 22:if(!Check(GetActorLocation().Z>0&&R->bEvidence&&R->bGateFixed&&R->bStairFixed,TEXT("Falling returns player safely without losing progress")))return;Snap({0,1120,92});Controller->SetControlRotation(FRotator(0,90,0));break;
 case 23:Start=GetActorLocation();break;
 case 24:break;
 case 25:if(!Check(GetActorLocation().Y>1420,TEXT("Character physically traverses restored doorway")))return;Face({0,1550,170});Interact();if(!Check(R->bComplete,TEXT("Read sealing order and complete the sequel's investigation")))return;Shot(TEXT("09_Complete.png"));break;
 case 26:GetCharacterMovement()->SetMovementMode(MOVE_Flying);Snap({1950,-2250,1900});Face({0,150,80});Cast<APlayerController>(Controller)->GetHUD()->bShowHUD=false;break;
 case 27:Shot(TEXT("10_Overview.png"));break;
 case 28:Cast<APlayerController>(Controller)->GetHUD()->bShowHUD=true;GetCharacterMovement()->SetMovementMode(MOVE_Walking);Recover();Report+=TEXT("ALL_CHECKS_PASSED\n");FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("MirrorVerification.txt")));UE_LOG(LogTemp,Display,TEXT("MIRROR_VERIFY ALL_CHECKS_PASSED"));Stage=-1;return;
 }Stage++;Time=0;
}
