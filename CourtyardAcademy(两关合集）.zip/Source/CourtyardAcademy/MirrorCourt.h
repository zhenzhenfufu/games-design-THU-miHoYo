#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "MirrorCourt.generated.h"

class UCameraComponent;
class UStaticMeshComponent;
class USceneCaptureComponent2D;
class UTextureRenderTarget2D;

UCLASS()
class COURTYARDACADEMY_API AMirrorCourt : public AActor {
 GENERATED_BODY()
public:
 AMirrorCourt();
 virtual void OnConstruction(const FTransform& T) override;
 virtual void BeginPlay() override;
 virtual void Tick(float Dt) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Root;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> PaperStairs;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> WaterNames;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> StairDrawing;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> MirrorSeal;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> StairSeal;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Mirror;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Gate;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneCaptureComponent2D> Capture;
 UPROPERTY(Transient) TObjectPtr<UTextureRenderTarget2D> MirrorTexture;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Story") FString MissingStudent=TEXT("陆衡");
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Story") FString MissingCourt=TEXT("听雨院");
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") int32 FixedView=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") int32 ActiveView=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") int32 Realm=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bRecorded=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bCut=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bStairFixed=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bEvidence=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bGateFixed=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bComplete=false;
 bool bPreview=false,bHeard=false;
 float RevealUntil=0,NameUntil=0,CaptureTime=0;
 FVector MirrorPoint=FVector(0,180,285);
 FVector StairBase=FVector(850,-1295,0);
 FVector GatePoint=FVector(0,1320,225);
 int32 Symbols()const{return 2-int32(FixedView>0)-int32(bStairFixed)-int32(bGateFixed);}
 FVector RealmOffset(int32 Index)const{return FVector(Index*12000.f,0,0);}
 int32 ViewFrom(FVector Eye)const;
 bool OnStairs(FVector P)const;
 void Refresh();
 void SetGroup(USceneComponent* G,bool Visible,bool Solid);
 FString Objective()const;
 FString ViewName()const;
private:
 UPROPERTY() TObjectPtr<UStaticMesh> Cube;
 UPROPERTY() TObjectPtr<UStaticMesh> Cylinder;
 UPROPERTY() TObjectPtr<UStaticMesh> Sphere;
 UPROPERTY() TObjectPtr<UMaterialInterface> BaseMaterial;
 USceneComponent* Group(const TCHAR* Name);
 UStaticMeshComponent* Shape(const FString& Name,FVector P,FVector Size,FLinearColor Color,USceneComponent* Parent=nullptr,bool Solid=true,int32 Form=0,float Glow=0);
 void Label(const FString& Name,const FString& Text,FVector P,float Size=24,USceneComponent* Parent=nullptr);
 void Paint();
};

UCLASS()
class COURTYARDACADEMY_API AMirrorPlayer : public ACharacter {
 GENERATED_BODY()
public:
 AMirrorPlayer();
 virtual void BeginPlay() override;
 virtual void Tick(float Dt) override;
 virtual void SetupPlayerInputComponent(UInputComponent* I) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UCameraComponent> Camera;
 UPROPERTY() TObjectPtr<AMirrorCourt> Puzzle;
 bool bJournal=false,bCutting=false;
 int32 CutProgress=0,RecallTarget=0;
 float NoticeUntil=0,RecallUntil=0,LastBell=-10;
 FString Notice;
 void Say(const FString& Text,float Duration=7);
 bool Near(FVector Point,float Distance,bool Facing=true)const;
 void Bell(); void Interact(); void Cut(); void Fix(); void Recall(); void Cancel();
 void Journal(); void Recover(); void RestartPuzzle();
 void Travel(int32 Realm);
 void CutSample(FVector2D Point,FVector2D Size,bool Held);
 FString Prompt()const;
private:
 void Forward(float V);void Right(float V);void Turn(float V);void Look(float V);void JumpStart();
 void Verify(float Dt);
};

UCLASS()
class COURTYARDACADEMY_API AMirrorHUD : public AHUD {
 GENERATED_BODY()
public:
 virtual void DrawHUD() override;
};
UCLASS()
class COURTYARDACADEMY_API AMirrorGameMode : public AGameModeBase {
 GENERATED_BODY()
public: AMirrorGameMode();
};
