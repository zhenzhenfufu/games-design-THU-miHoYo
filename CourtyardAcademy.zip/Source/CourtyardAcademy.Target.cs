using UnrealBuildTool;
public class CourtyardAcademyTarget : TargetRules {
 public CourtyardAcademyTarget(TargetInfo Target) : base(Target) {
  Type = TargetType.Game;
  DefaultBuildSettings = BuildSettingsVersion.Latest;
  IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
  ExtraModuleNames.Add("CourtyardAcademy");
 }
}

