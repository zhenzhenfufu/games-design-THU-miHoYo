#include "Academy.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Sound/SoundBase.h"
#include "Sound/SoundAttenuation.h"
#include "UObject/ConstructorHelpers.h"
#include "InputCoreTypes.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Engine/GameViewportClient.h"

namespace Ink {
 const FLinearColor Stone(.46f,.53f,.57f),Pale(.71f,.78f,.79f),Dark(.065f,.10f,.14f),Wood(.23f,.29f,.30f);
 const FLinearColor Jade(.15f,.76f,.66f),Gold(1,.57f,.19f),Paper(.88f,.81f,.61f),Blue(.10f,.29f,.40f);
}

// Shared centerline dimensions keep the visible target, projection and fit test identical.
namespace DoorFit {
 constexpr float Width=312.f, Height=500.f, CenterZ=250.f, Stroke=7.f;
 constexpr float GateWidth=93.6f, GateHeight=150.f, GateZ=150.f, GateY=350.f;
 constexpr float WallY=1045.f, Ready=.70f;
}

AAcademyCourt::AAcademyCourt() {
 PrimaryActorTick.bCanEverTick=true;
 Court=CreateDefaultSubobject<USceneComponent>(TEXT("Courtyard"));SetRootComponent(Court);
 Bridge=Group(TEXT("UniquePaintingBridge"));Reflection=Group(TEXT("RevealedReflection"));
 Lantern=Group(TEXT("MovableLantern"));DoorShadow=Group(TEXT("ProjectedDoorFrame"));
 DoorSeal=Group(TEXT("DoorTalisman"));BridgeSeal=Group(TEXT("BridgeTalisman"));
 PoolWriting=Group(TEXT("ErasedPoolRecord"));MemoryGlow=Group(TEXT("MemoryPlaques"));Ripples=Group(TEXT("BellRipples"));
 static ConstructorHelpers::FObjectFinder<UStaticMesh> M0(TEXT("/Engine/BasicShapes/Cube.Cube"));Cube=M0.Object;
 static ConstructorHelpers::FObjectFinder<UStaticMesh> M1(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));Cylinder=M1.Object;
 static ConstructorHelpers::FObjectFinder<UStaticMesh> M2(TEXT("/Engine/BasicShapes/Sphere.Sphere"));Sphere=M2.Object;
 static ConstructorHelpers::FObjectFinder<UMaterialInterface> Mat(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));Surface=Mat.Object;
 using namespace Ink;
 // The island, dry perimeter and pool bed are separate collision surfaces.
 Shape(TEXT("FloatingFoundation"),{0,0,-280},{3640,4050,250},Dark);
 Shape(TEXT("SouthCourt"),{0,-1200,-25},{3600,800,50},Stone);
 Shape(TEXT("NorthCourt"),{0,925,-25},{3600,250,50},Stone);
 Shape(TEXT("WestWalk"),{-1375,0,-25},{850,1600,50},Stone);
 Shape(TEXT("EastWalk"),{1375,0,-25},{850,1600,50},Stone);
 Shape(TEXT("PoolBed"),{0,0,-155},{1900,1600,50},Blue);
 Shape(TEXT("PoolWater"),{0,0,-37},{1900,1600,3},FLinearColor(.035f,.20f,.26f),nullptr,false);
 Shape(TEXT("PavilionIsland"),{0,100,-25},{500,500,50},Pale);
 for(int s=-1;s<=1;s+=2) {
  Shape(FString::Printf(TEXT("PondRimX%d"),s),{float(s*960),0,4},{20,1620,8},Pale);
  Shape(FString::Printf(TEXT("PondRimY%d"),s),{0,float(s*810),4},{1900,20,8},Pale);
  Shape(FString::Printf(TEXT("OuterSide%d"),s),{float(s*1810),0,115},{25,4020,230},Pale);
 }
 Shape(TEXT("SouthWallLeft"),{-1080,-1610,115},{1460,25,230},Pale);
 Shape(TEXT("SouthWallRight"),{1080,-1610,115},{1460,25,230},Pale);
 Shape(TEXT("EntryGateLeft"),{-335,-1580,250},{45,60,500},Wood);
 Shape(TEXT("EntryGateRight"),{335,-1580,250},{45,60,500},Wood);
 Shape(TEXT("EntryLintel"),{0,-1580,485},{760,110,60},Dark);
 for(int x=-3;x<=3;x++) for(int y=-2;y<=2;y++)
  Shape(FString::Printf(TEXT("EntryPaver%d%d"),x,y),{float(x*95),-1210.f+y*90,1},{90,85,2},Pale,nullptr,false);
 // Covered cloisters lead around both sides of the pool to the sealed library.
 for(int side=-1;side<=1;side+=2) {
  float x=side*1510.f;
  Shape(FString::Printf(TEXT("CorridorRoof%d"),side),{x,-20,445},{480,2540,35},Dark);
  Shape(FString::Printf(TEXT("CorridorRidge%d"),side),{x,-20,477},{90,2600,32},Wood);
  for(int j=0;j<7;j++) {
   float y=-1100+j*350.f;
   for(int k=-1;k<=1;k+=2) {
    float px=x+k*195;
    Shape(FString::Printf(TEXT("Column%d%d%d"),side,j,k),{px,y,214},{24,24,428},Wood,nullptr,true,1);
    Shape(FString::Printf(TEXT("ColumnFoot%d%d%d"),side,j,k),{px,y,17},{50,50,34},Pale);
   }
   Shape(FString::Printf(TEXT("CrossBeam%d%d"),side,j),{x,y,405},{452,34,34},Wood);
   Shape(FString::Printf(TEXT("HangingLight%d%d"),side,j),{x,y,333},{38,38,60},Paper,nullptr,false,1,.6f);
   auto* L=CreateDefaultSubobject<UPointLightComponent>(*FString::Printf(TEXT("CloisterLight%d%d"),side,j));
   L->SetupAttachment(Court);L->SetRelativeLocation({x,y,305});L->SetLightColor(FLinearColor(1,.72f,.43f));L->SetIntensity(850);L->SetAttenuationRadius(480);L->SetCastShadows(false);
  }
 }
 // Pavilion: four columns, tiered hip-like roof and a narrow ritual gate.
 for(int x=-1;x<=1;x+=2)for(int y=-1;y<=1;y+=2){
  Shape(FString::Printf(TEXT("PavilionColumn%d%d"),x,y),{float(x*217),100.f+y*212,205},{24,24,410},Wood,nullptr,true,1);
  Shape(FString::Printf(TEXT("PavilionFoot%d%d"),x,y),{float(x*217),100.f+y*212,12},{42,42,24},Pale);
 }
 for(int t=0;t<5;t++)Shape(FString::Printf(TEXT("PavilionRoofTier%d"),t),{0,100,420.f+t*24},{650.f-t*85,650.f-t*85,28},Dark);
 Shape(TEXT("RoofFinial"),{0,100,563},{28,28,75},Gold,nullptr,false,1);
 for(int s=-1;s<=1;s+=2){
  Shape(FString::Printf(TEXT("PavilionBeam%d"),s),{float(s*217),100,390},{30,462,32},Wood);
  Shape(FString::Printf(TEXT("GatePost%d"),s),{s*DoorFit::GateWidth/2,DoorFit::GateY,DoorFit::GateZ},{10,14,DoorFit::GateHeight},Wood);
 }
 Shape(TEXT("GateHead"),{0,DoorFit::GateY,DoorFit::GateZ+DoorFit::GateHeight/2},{DoorFit::GateWidth+10,14,10},Wood);
 Shape(TEXT("GateSill"),{0,DoorFit::GateY,DoorFit::GateZ-DoorFit::GateHeight/2},{DoorFit::GateWidth+10,14,10},Wood);
 // A complete frame is projected geometrically through the lamp, with real light too.
 for(int i=0;i<4;i++)Shape(FString::Printf(TEXT("ShadowEdge%d"),i),FVector::ZeroVector,FVector(1),Jade,DoorShadow,false,0,.8f);
 Shape(TEXT("LanternBody"),{0,0,0},{42,42,62},Paper,Lantern,false,1,.7f);
 Shape(TEXT("LanternTop"),{0,0,35},{54,54,9},Dark,Lantern,false);
 Shape(TEXT("LanternBottom"),{0,0,-35},{54,54,9},Dark,Lantern,false);
 Shape(TEXT("LanternTassel"),{0,0,-61},{5,5,43},Gold,Lantern,false,1);
 for(int i=0;i<4;i++){float a=i*PI/2;Shape(FString::Printf(TEXT("LanternRib%d"),i),{float(FMath::Cos(a)*21),float(FMath::Sin(a)*21),0},{4,4,66},Wood,Lantern,false);}
 LampLight=CreateDefaultSubobject<UPointLightComponent>(TEXT("WandLanternLight"));LampLight->SetupAttachment(Lantern);
 LampLight->SetIntensity(2300);LampLight->SetLightColor(FLinearColor(1,.70f,.35f));LampLight->SetAttenuationRadius(1750);LampLight->SetCastShadows(true);
 // Library facade leaves a 300 x 500 cm opening covered by a removable slab.
 Shape(TEXT("ArchiveFloor"),{0,1500,-25},{3600,900,50},Stone);
 Shape(TEXT("LibraryFacadeWest"),{-980,1070,420},{1660,40,840},Pale);
 Shape(TEXT("LibraryFacadeEast"),{980,1070,420},{1660,40,840},Pale);
 Shape(TEXT("LibraryFacadeHeader"),{0,1070,670},{300,40,340},Pale);
 SealedWall=Shape(TEXT("SealedDoorPanel"),{0,1070,250},{300,40,500},Stone);
 Shape(TEXT("LibraryBack"),{0,1950,420},{3620,40,840},Pale);
 Shape(TEXT("LibraryCeiling"),{0,1500,845},{3700,970,40},Dark);
 for(int s=-1;s<=1;s+=2){
  Shape(FString::Printf(TEXT("LibraryEnd%d"),s),{s*1800.f,1500,420},{30,900,840},Pale);
  FrameTraces.Add(Shape(FString::Printf(TEXT("OldDoorTrace%d"),s),{s*156.f,1047,250},{7,3,505},Gold,nullptr,false,0,.25f));
  Shape(FString::Printf(TEXT("FacadeColumn%d"),s),{s*400.f,1024,385},{46,70,770},Wood);
 }
 FrameTraces.Add(Shape(TEXT("OldDoorTraceTop"),{0,1047,505},{320,3,7},Gold,nullptr,false,0,.25f));
 Shape(TEXT("DoorTalismanPaper"),{178,1033,190},{25,3,74},Paper,DoorSeal,false,0,.3f);
 for(int i=0;i<4;i++)Shape(FString::Printf(TEXT("DoorRune%d"),i),{178,1029,170.f+i*13},{15,2,3},Gold,DoorSeal,false,0,1);
 Shape(TEXT("BridgeTalismanPaper"),{0,-796,10},{36,74,3},Paper,BridgeSeal,false,0,.5f);
 for(int i=0;i<4;i++)Shape(FString::Printf(TEXT("BridgeRune%d"),i),{0,-818.f+i*13,13},{24,3,2},Gold,BridgeSeal,false,0,1);
 // Archive display and the protagonist's old keepsake. Pages use modeled lines.
 Shape(TEXT("ArchiveDesk"),{0,1520,90},{330,135,18},Wood);
 for(int s=-1;s<=1;s+=2)Shape(FString::Printf(TEXT("ArchiveLeg%d"),s),{s*130.f,1520,42},{25,105,84},Dark);
 Shape(TEXT("AlteredArchivePage"),{-55,1505,102},{142,95,4},Paper);
 for(int i=0;i<6;i++)Shape(FString::Printf(TEXT("ArchiveLine%d"),i),{-55,1470.f+i*13,105},{113,3,2},i==2?Gold:Dark,nullptr,false);
 Shape(TEXT("RedactedName"),{-70,1496,107},{80,11,2},Dark,nullptr,false);
 Shape(TEXT("OldKeepsakeBox"),{101,1520,122},{72,66,49},Stone);
 Shape(TEXT("KeepsakeClasp"),{101,1486,125},{12,3,19},Gold,nullptr,false);
 for(int s=-1;s<=1;s+=2)for(int row=0;row<2;row++){
  float x=s*1000.f,y=1390+row*370.f;
  Shape(FString::Printf(TEXT("ShelfBack%d%d"),s,row),{x,y,225},{520,25,450},Wood);
  for(int z=0;z<4;z++){
   Shape(FString::Printf(TEXT("Shelf%d%d%d"),s,row,z),{x,y-50,50.f+z*112},{540,115,12},Dark);
   for(int b=0;b<9;b++)Shape(FString::Printf(TEXT("Book%d%d%d%d"),s,row,z,b),{x-220+b*52.f,y-45,98.f+z*112},{31,54,75.f+(b%3)*7},b%3==0?Paper:Stone);
  }
 }
 for(int x=-1;x<=1;x++){
  auto* L=CreateDefaultSubobject<UPointLightComponent>(*FString::Printf(TEXT("ArchiveLight%d"),x));L->SetupAttachment(Court);L->SetRelativeLocation({x*850.f,1500,480});L->SetIntensity(3500);L->SetAttenuationRadius(1100);L->SetLightColor(FLinearColor(.61f,.79f,1));L->SetCastShadows(false);
 }
 // Old tree: trunk, leaning branches, irregular crowns, roots and hanging plaques.
 Shape(TEXT("TreeTrunk"),{-1280,-280,285},{115,105,570},Wood,nullptr,true,1);
 for(int i=0;i<6;i++){
  float a=i*PI/3,dx=FMath::Cos(a),dy=FMath::Sin(a);
  auto* Branch=Shape(FString::Printf(TEXT("TreeBranch%d"),i),{-1280+dx*115,-280+dy*115,400.f+(i%2)*80},{40,40,310},Wood,nullptr,true,1);
  Branch->SetRelativeRotation(FRotator(dx*38,0,dy*38));
  Shape(FString::Printf(TEXT("TreeCrown%d"),i),{-1280+dx*187,-280+dy*175,620.f+(i%2)*60},{340,310,240},Stone,nullptr,false,2);
  auto* Root=Shape(FString::Printf(TEXT("TreeRoot%d"),i),{-1280+dx*90,-280+dy*90,12},{220,24,22},Wood);Root->SetRelativeRotation(FRotator(0,i*60,0));
  FVector Pos(-1225.f+(i%3)*55,-330.f+(i/3)*110,150.f+(i%2)*52);
  Shape(FString::Printf(TEXT("PlaqueString%d"),i),Pos+FVector(0,0,123),{2,2,200},Paper,nullptr,false);
  Shape(FString::Printf(TEXT("Plaque%d"),i),Pos,{26,12,64},Paper);
  if(i%2==0)Shape(FString::Printf(TEXT("PlaqueMemory%d"),i),Pos+FVector(0,-8,0),{17,2,43},Jade,MemoryGlow,false,0,2);
 }
 // One bridge actor changes its pose and length between two valid banks.
 Shape(TEXT("BridgeDeck"),{0,0,-3},{180,650,12},Pale,Bridge,true);
 for(int s=-1;s<=1;s+=2){
  Shape(FString::Printf(TEXT("BridgeRail%d"),s),{s*94.f,0,73},{8,650,10},Wood,Bridge,true);
  for(int i=0;i<6;i++)Shape(FString::Printf(TEXT("BridgePost%d%d"),s,i),{s*94.f,-300.f+i*120,35},{9,9,80},Wood,Bridge,true);
 }
 for(int i=0;i<14;i++)Shape(FString::Printf(TEXT("BridgeJoint%d"),i),{0,-310.f+i*47,4},{180,3,1},Dark,Bridge,false);
 for(int s=-1;s<=1;s+=2)Shape(FString::Printf(TEXT("GhostBridgeRail%d"),s),{s*90.f,-475,-22},{4,650,3},Jade,Reflection,false,0,2);
 for(int i=0;i<12;i++)Shape(FString::Printf(TEXT("GhostBridgeRung%d"),i),{0,-783.f+i*56,-22},{182,3,3},Jade,Reflection,false,0,2);
 // Pool text is genuinely on the bed, behind the only bridge's initial position.
 Shape(TEXT("PoolRecordTablet"),RecordPoint,{162,212,7},Pale,PoolWriting,false,0,.3f);
 for(int i=0;i<5;i++){
  Shape(FString::Printf(TEXT("PoolGlyphA%d"),i),RecordPoint+FVector(-32,-70.f+i*33,5),{44,4,3},Jade,PoolWriting,false,0,3);
  Shape(FString::Printf(TEXT("PoolGlyphB%d"),i),RecordPoint+FVector(34,-70.f+i*33,5),{4,23,3},Jade,PoolWriting,false,0,3);
 }
 for(int r=0;r<3;r++)for(int i=0;i<36;i++){
  float a=i*2*PI/36,rad=80.f+r*65;
  auto* R=Shape(FString::Printf(TEXT("Ripple%d_%d"),r,i),{rad*FMath::Cos(a),rad*FMath::Sin(a),0},{rad*.18f,2,1},Jade,Ripples,false,0,1.5f);R->SetRelativeRotation(FRotator(0,i*10+90,0));
 }
 // Simple floating rock silhouettes reinforce the setting without external art.
 for(int i=0;i<12;i++){
  float a=i*2*PI/12;
  auto* Rock=Shape(FString::Printf(TEXT("DistantFloatingRock%d"),i),{FMath::Cos(a)*4200,FMath::Sin(a)*4300,-250.f+(i%3)*260},{600.f+(i%4)*170,700,530},Dark,nullptr,false,2);Rock->SetRelativeRotation(FRotator(i*17,i*29,i*11));
 }
 auto* Moon=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("Moonlight"));Moon->SetupAttachment(Court);Moon->SetRelativeRotation(FRotator(-48,-32,0));Moon->SetIntensity(1.7f);Moon->SetLightColor(FLinearColor(.64f,.78f,1));Moon->SetForwardShadingPriority(1);
 auto* Fill=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("SkyFill"));Fill->SetupAttachment(Court);Fill->SetRelativeRotation(FRotator(-65,142,0));Fill->SetIntensity(.65f);Fill->SetCastShadows(false);Fill->SetLightColor(FLinearColor(.42f,.65f,.77f));
 Shape(TEXT("MoonDisc"),{3100,5700,4600},{420,420,420},Paper,nullptr,false,2,1);
 Label(TEXT("LibraryTitle"),TEXT("ARCHIVE  /  SEALED"),{0,1040,655},FRotator(0,-90,0),45,FColor(133,183,184));
 Label(TEXT("EntryTitle"),TEXT("COURTYARD OF ECHOES"),{0,-1570,402},FRotator(0,90,0),30,FColor(161,199,195));
 Label(TEXT("ArchiveRecord17"),TEXT("RECORD 17  /  REDACTED"),{0,1510,170},FRotator(0,-90,0),18,FColor(219,197,135));
 Label(TEXT("SouthDockMark"),TEXT("I"),{125,-820,8},FRotator(90,-90,0),22,FColor(91,196,185));
 Label(TEXT("WestDockMark"),TEXT("II"),{-970,220,8},FRotator(90,0,0),22,FColor(91,196,185));
}

USceneComponent* AAcademyCourt::Group(const TCHAR* Name){auto* G=CreateDefaultSubobject<USceneComponent>(Name);G->SetupAttachment(Court);return G;}
UStaticMeshComponent* AAcademyCourt::Shape(const FString& Name,FVector Pos,FVector Size,FLinearColor Color,USceneComponent* Parent,bool Collision,int32 Form,float Glow){
 auto* C=CreateDefaultSubobject<UStaticMeshComponent>(*Name);C->SetupAttachment(Parent?Parent:Court.Get());C->SetStaticMesh(Form==1?Cylinder.Get():Form==2?Sphere.Get():Cube.Get());
 C->SetRelativeLocation(Pos);C->SetRelativeScale3D(Size/100.f);C->SetMaterial(0,Surface);C->SetMobility(EComponentMobility::Movable);
 C->SetCollisionProfileName(Collision?TEXT("BlockAll"):TEXT("NoCollision"));C->ComponentTags.Add(FName(*Color.ToString()));C->ComponentTags.Add(FName(*FString::SanitizeFloat(Glow)));if(Collision)C->ComponentTags.Add(TEXT("Solid"));return C;
}
void AAcademyCourt::Label(const FString& Name,const FString& Text,FVector Pos,FRotator Rot,float Size,FColor Color){
 auto* T=CreateDefaultSubobject<UTextRenderComponent>(*Name);T->SetupAttachment(Court);T->SetText(FText::FromString(Text));T->SetRelativeLocation(Pos);T->SetRelativeRotation(Rot);T->SetWorldSize(Size);T->SetHorizontalAlignment(EHTA_Center);T->SetTextRenderColor(Color);
}
void AAcademyCourt::Paint(){
 auto* Mat=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_Court.M_Court"));if(!Mat)return;
 TArray<UStaticMeshComponent*> Parts;GetComponents(Parts);
 for(auto* Part:Parts)if(Part->ComponentTags.Num()>=2){
  FLinearColor Color;Color.InitFromString(Part->ComponentTags[0].ToString());
  auto* Chosen=Mat;if(Part->GetName()==TEXT("PoolWater")){auto* Water=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_Water.M_Water"));if(Water)Chosen=Water;}
  auto* MID=Part->CreateDynamicMaterialInstance(0,Chosen);MID->SetVectorParameterValue(TEXT("Tint"),Color);MID->SetScalarParameterValue(TEXT("Glow"),FCString::Atof(*Part->ComponentTags[1].ToString()));
 }
}
void AAcademyCourt::OnConstruction(const FTransform& T){Super::OnConstruction(T);Paint();Refresh();}
void AAcademyCourt::BeginPlay(){Super::BeginPlay();Paint();for(const TCHAR* N:{TEXT("Bell"),TEXT("TreeVoice"),TEXT("WallVoice"),TEXT("PoolVoice")}){auto* A=LoadObject<USoundBase>(nullptr,*FString::Printf(TEXT("/Game/Audio/%s.%s"),N,N));if(A)AudioAssets.Add(A);}Refresh();}
void AAcademyCourt::SetGroup(USceneComponent* G,bool Visible,bool Collision){
 G->SetVisibility(Visible,true);G->SetHiddenInGame(!Visible,true);TArray<USceneComponent*> Descendants;G->GetChildrenComponents(true,Descendants);
 for(auto* C:Descendants)if(auto* P=Cast<UStaticMeshComponent>(C))P->SetCollisionEnabled(Visible&&Collision&&P->ComponentHasTag(TEXT("Solid"))?ECollisionEnabled::QueryAndPhysics:ECollisionEnabled::NoCollision);
}
FVector AAcademyCourt::DockPose(int32 I)const{return I==0?FVector(0,-475,6):FVector(-600,100,6);}
// Forgiving tutorial placement: F snaps both position and rotation once nearby.
bool AAcademyCourt::BridgeAligned()const{return FVector::Dist2D(BridgePose,DockPose(Dock))<=300;}
bool AAcademyCourt::PoolLit()const{return FVector::Dist2D(LightPose,RecordPoint)<225&&LightPose.Z>=130&&LightPose.Z<=400;}
bool AAcademyCourt::OnBridge(FVector P)const{FVector L=FRotator(0,-BridgeYaw,0).RotateVector(P-BridgePose);return bBridgeFixed&&FMath::Abs(L.X)<130&&FMath::Abs(L.Y)<(Dock==0?360:385)&&P.Z<230;}
bool AAcademyCourt::AtBridgeAnchor(FVector P)const{return FVector::Dist2D(P,Dock==0?FVector(0,-810,0):FVector(-960,100,0))<270||FVector::Dist2D(P,Dock==0?FVector(0,-140,0):FVector(-240,100,0))<190;}
void AAcademyCourt::Refresh(){
 float Now=GetWorld()?GetWorld()->GetTimeSeconds():0;
 Bridge->SetRelativeLocation(BridgePose);Bridge->SetRelativeRotation(FRotator(0,BridgeYaw,0));Bridge->SetRelativeScale3D(FVector(1,Dock==0?1.f:700.f/650.f,bBridgeFixed?FMath::Max(.04f,SolidAmount):.04f));
 SetGroup(Bridge,bBridgeFixed||bBridgePreview,bBridgeFixed);
 SetGroup(Reflection,Now<RevealUntil&&!bRecorded);
 SetGroup(BridgeSeal,bBridgeFixed);BridgeSeal->SetRelativeLocation(Dock==0?FVector::ZeroVector:FVector(-160,100,0));BridgeSeal->SetRelativeRotation(FRotator(0,Dock==0?0.f:90.f,0));
 SetGroup(DoorSeal,bDoorFixed);SetGroup(MemoryGlow,Now<TreeUntil);
 for(int32 i=0;i<FrameTraces.Num();i++)if(auto* Trace=FrameTraces[i].Get()){
  // Apply to existing saved maps as well as newly constructed levels.
  Trace->SetRelativeLocation(i<2?FVector((i==0?-1:1)*DoorFit::Width/2,DoorFit::WallY,DoorFit::CenterZ):FVector(0,DoorFit::WallY,DoorFit::CenterZ+DoorFit::Height/2));
  Trace->SetRelativeScale3D((i<2?FVector(DoorFit::Stroke,3,DoorFit::Height):FVector(DoorFit::Width+DoorFit::Stroke,3,DoorFit::Stroke))/100);
  if(auto* M=Cast<UMaterialInstanceDynamic>(Trace->GetMaterial(0)))M->SetScalarParameterValue(TEXT("Glow"),Now<WallUntil?2.f:.25f);
 }
 SealedWall->SetVisibility(!bDoorFixed);SealedWall->SetHiddenInGame(bDoorFixed);SealedWall->SetCollisionEnabled(bDoorFixed?ECollisionEnabled::NoCollision:ECollisionEnabled::QueryAndPhysics);
 Lantern->SetRelativeLocation(LightPose);
 const float S=(DoorFit::WallY-LightPose.Y)/FMath::Max(1.,DoorFit::GateY-LightPose.Y);
 float X=(1-S)*LightPose.X,Z=LightPose.Z+S*(DoorFit::GateZ-LightPose.Z),W=DoorFit::GateWidth*S,H=DoorFit::GateHeight*S;
 // Accept 1 m of center offset and 30% size error, then visibly snap onto the target.
 const float PositionError=FMath::Max(FMath::Abs(X)/100,FMath::Abs(Z-DoorFit::CenterZ)/100);
 const float SizeError=FMath::Max(FMath::Abs(W-DoorFit::Width)/(DoorFit::Width*.30f),FMath::Abs(H-DoorFit::Height)/(DoorFit::Height*.30f));
 Alignment=FMath::Clamp(1-.30f*FMath::Max(PositionError,SizeError),0.f,1.f);
 bool Valid=LightPose.Y<320&&LightPose.Y>-120;
 if(!Valid)Alignment=0;
 const bool Ready=Valid&&Alignment>=DoorFit::Ready;
 if(Ready){X=0;Z=DoorFit::CenterZ;W=DoorFit::Width;H=DoorFit::Height;Alignment=1;}
 SetGroup(DoorShadow,Valid&&!bDoorFixed);
 TArray<USceneComponent*> Edges;DoorShadow->GetChildrenComponents(false,Edges);
 for(int i=0;i<Edges.Num();i++){
  Edges[i]->SetRelativeLocation(i<2?FVector(X+(i==0?-W/2:W/2),DoorFit::WallY-2,Z):FVector(X,DoorFit::WallY-2,Z+(i==2?-H/2:H/2)));
  Edges[i]->SetRelativeScale3D((i<2?FVector(DoorFit::Stroke,2,H):FVector(W+DoorFit::Stroke,2,DoorFit::Stroke))/100);
  if(auto* M=Cast<UStaticMeshComponent>(Edges[i]))if(auto* D=Cast<UMaterialInstanceDynamic>(M->GetMaterial(0)))D->SetVectorParameterValue(TEXT("Tint"),Ready?Ink::Gold:Ink::Jade);
 }
 bPoolVisible=bArchive&&!PoolCovered()&&PoolLit()&&Now<RevealUntil;SetGroup(PoolWriting,bPoolVisible);
 float Age=Now-RippleStart;SetGroup(Ripples,Age>=0&&Age<3);Ripples->SetRelativeLocation({0,-475,-29});Ripples->SetRelativeScale3D(FVector(1+Age*.7f,1+Age*.7f,1));
}
void AAcademyCourt::Tick(float Dt){Super::Tick(Dt);SolidAmount=FMath::FInterpConstantTo(SolidAmount,bBridgeFixed?1.f:0.f,Dt,1.5f);Refresh();}
void AAcademyCourt::SoundAt(const TCHAR* Name,FVector Point,float Volume){
 for(auto A:AudioAssets)if(A&&A->GetName()==Name){
  auto* Att=NewObject<USoundAttenuation>(this);Att->Attenuation.bAttenuate=true;Att->Attenuation.bSpatialize=true;Att->Attenuation.AttenuationShapeExtents=FVector(350);Att->Attenuation.FalloffDistance=2400;
  UGameplayStatics::PlaySoundAtLocation(this,A,Point,FRotator::ZeroRotator,Volume,1,0,Att);break;
 }
}
FString AAcademyCourt::Objective()const{
 if(bComplete)return FString::Printf(TEXT("往事已印证：庭院景物与学生档案都曾被改写。寻找被隐藏的%s。"),*MissingCourt);
 if(bArchive)return TEXT("06 / 返回池岸：移灯照向南桥下方，回收桥，再摇铃显露池底记录。");
 if(bDoorFixed)return TEXT("05 / 沿回廊进入藏书阁夹层，查看桌上的删改档案与旧物。");
 if(bPavilion)return TEXT("04 / 调整灯笼位置与高度，让青色门影与金色旧门框重合，再贴符。");
 if(bBridgeFixed)return TEXT("03 / 沿画桥到池心亭，寻找可以移动的灯笼。");
 if(bCut)return TEXT("02 / 在池岸按 E 放出桥片，再按 F 自动吸附成桥，无需精确对齐。");
 if(bRecorded)return TEXT("02 / 画卷已收录桥影。按 C 展开画卷，沿亮起的边界裁出桥片。");
 return TEXT("01 / 潜回藏书阁取回旧物。先在古树或南侧池岸摇铃，寻找回应。");
}

AAcademyPlayer::AAcademyPlayer(){
 PrimaryActorTick.bCanEverTick=true;GetCapsuleComponent()->InitCapsuleSize(32,88);
 Camera=CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));Camera->SetupAttachment(GetCapsuleComponent());Camera->SetRelativeLocation({0,0,66});Camera->bUsePawnControlRotation=true;Camera->SetFieldOfView(86);
 bUseControllerRotationYaw=true;GetCharacterMovement()->MaxWalkSpeed=390;GetCharacterMovement()->JumpZVelocity=370;GetCharacterMovement()->AirControl=.15f;GetCharacterMovement()->MaxStepHeight=28;
 static ConstructorHelpers::FObjectFinder<UStaticMesh> RodMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
 auto* Wand=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FirstPersonWand"));Wand->SetupAttachment(Camera);Wand->SetStaticMesh(RodMesh.Object);Wand->SetRelativeLocation({47,24,-32});Wand->SetRelativeScale3D({.032f,.032f,.63f});Wand->SetRelativeRotation(FRotator(-25,0,0));Wand->SetCollisionEnabled(ECollisionEnabled::NoCollision);Wand->SetCastShadow(false);
 auto* BellBody=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FirstPersonBell"));BellBody->SetupAttachment(Camera);BellBody->SetStaticMesh(RodMesh.Object);BellBody->SetRelativeLocation({45,-23,-25});BellBody->SetRelativeScale3D({.10f,.10f,.095f});BellBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);BellBody->SetCastShadow(false);
 auto* Handle=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BellHandle"));Handle->SetupAttachment(Camera);Handle->SetStaticMesh(RodMesh.Object);Handle->SetRelativeLocation({45,-23,-17});Handle->SetRelativeScale3D({.022f,.022f,.10f});Handle->SetCollisionEnabled(ECollisionEnabled::NoCollision);Handle->SetCastShadow(false);
}
AAcademyGameMode::AAcademyGameMode(){DefaultPawnClass=AAcademyPlayer::StaticClass();HUDClass=AAcademyHUD::StaticClass();}
void AAcademyPlayer::BeginPlay(){Super::BeginPlay();for(TActorIterator<AAcademyCourt> It(GetWorld());It;++It){WorldPuzzle=*It;break;}if(!WorldPuzzle)WorldPuzzle=GetWorld()->SpawnActor<AAcademyCourt>();Say(TEXT("深夜，你潜回书院取回旧物。藏书阁已被封墙，水面却似乎留着另一座桥。"),9);}
void AAcademyPlayer::SetupPlayerInputComponent(UInputComponent* I){
 Super::SetupPlayerInputComponent(I);I->BindAxis(TEXT("Forward"),this,&AAcademyPlayer::Forward);I->BindAxis(TEXT("Right"),this,&AAcademyPlayer::Right);I->BindAxis(TEXT("Turn"),this,&AAcademyPlayer::Turn);I->BindAxis(TEXT("Look"),this,&AAcademyPlayer::Look);
 I->BindKey(EKeys::SpaceBar,IE_Pressed,this,&AAcademyPlayer::JumpStart);I->BindKey(EKeys::SpaceBar,IE_Released,this,&ACharacter::StopJumping);
 I->BindKey(EKeys::B,IE_Pressed,this,&AAcademyPlayer::Bell);I->BindKey(EKeys::E,IE_Pressed,this,&AAcademyPlayer::Interact);I->BindKey(EKeys::C,IE_Pressed,this,&AAcademyPlayer::Cut);
 I->BindKey(EKeys::F,IE_Pressed,this,&AAcademyPlayer::Fix);I->BindKey(EKeys::G,IE_Pressed,this,&AAcademyPlayer::Recall);I->BindKey(EKeys::Tab,IE_Pressed,this,&AAcademyPlayer::Cancel);
 I->BindKey(EKeys::J,IE_Pressed,this,&AAcademyPlayer::Journal);I->BindKey(EKeys::T,IE_Pressed,this,&AAcademyPlayer::SwitchDock);I->BindKey(EKeys::Home,IE_Pressed,this,&AAcademyPlayer::ResetSafe);I->BindKey(EKeys::F5,IE_Pressed,this,&AAcademyPlayer::RestartPuzzle);
}
void AAcademyPlayer::Forward(float V){if(!bCutting&&!bJournal&&Editing==0)AddMovementInput(FRotator(0,Controller->GetControlRotation().Yaw,0).Vector(),V);}
void AAcademyPlayer::Right(float V){if(!bCutting&&!bJournal&&Editing==0)AddMovementInput(FRotationMatrix(FRotator(0,Controller->GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::Y),V);}
void AAcademyPlayer::Turn(float V){if(!bCutting&&!bJournal)AddControllerYawInput(V);}
void AAcademyPlayer::Look(float V){if(!bCutting&&!bJournal)AddControllerPitchInput(V);}
void AAcademyPlayer::JumpStart(){if(!bCutting&&!bJournal&&Editing==0)Jump();}
void AAcademyPlayer::Say(const FString& T,float Seconds){Notice=T;NoticeUntil=GetWorld()->GetTimeSeconds()+Seconds;}
bool AAcademyPlayer::Near(FVector P,float D,bool Facing)const{
 if(FVector::Dist(Camera->GetComponentLocation(),P)>D)return false;
 return !Facing||FVector::DotProduct(GetViewRotation().Vector(),(P-Camera->GetComponentLocation()).GetSafeNormal())>.50f;
}
void AAcademyPlayer::Bell(){
 auto* R=WorldPuzzle.Get();if(!R||bCutting||bJournal)return;float Now=GetWorld()->GetTimeSeconds();if(Now-LastBell<1.1f)return;LastBell=Now;
 R->SoundAt(TEXT("Bell"),Camera->GetComponentLocation(),.65f);
 bool Responded=false;
 if(FVector::Dist2D(GetActorLocation(),R->TreePoint)<420){R->bTreeHeard=true;R->TreeUntil=Now+9;R->SoundAt(TEXT("TreeVoice"),R->TreePoint);Say(TEXT("木牌传来残声：“第十七名……听雨院……不要把我们擦掉……”"),7);Responded=true;}
 if(FVector::Dist2D(GetActorLocation(),FVector(0,-700,0))<690||FVector::Dist2D(GetActorLocation(),R->RecordPoint)<550){
  R->RevealUntil=Now+12;R->RippleStart=Now;R->Refresh();Responded=true;
  if(R->bPoolVisible){Say(TEXT("池底显出完整记录。靠近南岸，低头对准亮起的石牌，按 E 辨认。"),7);R->SoundAt(TEXT("PoolVoice"),R->RecordPoint);}
  else if(!R->bRecorded)Say(TEXT("铃声激起波纹，倒影中出现一座不存在的桥。对准青色桥影，按 E 收录。"),7);
  else if(R->bArchive)Say(R->PoolCovered()?TEXT("桥挡住了原来的池面。先站回岸边回收桥，再观察水下。 "):TEXT("水下有残痕，但光照不足。把灯笼移到南桥原来覆盖的池面上方。"),7);
 }
 if(FVector::Dist2D(GetActorLocation(),R->DoorPoint)<460){R->bWallHeard=true;R->WallUntil=Now+9;R->SoundAt(TEXT("WallVoice"),{0,1300,200});Say(TEXT("墙内传来回应：“门还在……只是被改成了一面墙。”旧门框沿着铃声亮起。"),7);Responded=true;}
 if(!Responded)Say(TEXT("铃声消散。到池水、古树木牌或藏书阁封墙附近，再听一次。"));R->Refresh();
}
void AAcademyPlayer::Interact(){
 auto* R=WorldPuzzle.Get();if(!R||bCutting||bJournal)return;
 if(Editing){Editing=0;R->bBridgePreview=false;R->Refresh();Say(TEXT("已放下仙杖。未贴符的画片留在画卷中；灯笼保留当前位置。"));return;}
 if(R->bPoolVisible&&Near(R->RecordPoint,620)){
  R->bComplete=true;bEndDismissed=false;R->SoundAt(TEXT("PoolVoice"),R->RecordPoint);Say(FString::Printf(TEXT("第十七名：%s，%s。姓名与夹层档案的空白编号一致，旧景和记录都被改写过。"),*R->MissingStudent,*R->MissingCourt),12);return;
 }
 if(Near(R->TreePoint,350)){R->bTreeHeard=true;R->TreeUntil=GetWorld()->GetTimeSeconds()+8;R->SoundAt(TEXT("TreeVoice"),R->TreePoint);Say(TEXT("木牌背面刻着“十七”。树上少了一块名牌，池中却映着完整的名字。试着摇铃。"),7);return;}
 if(!R->bRecorded&&GetWorld()->GetTimeSeconds()<R->RevealUntil&&Near({0,-475,-22},690)){
  R->bRecorded=true;R->Refresh();Say(TEXT("桥影已收进画卷。按 C 打开卷轴，按住鼠标左键沿边界顺时针描画。"),7);return;
 }
 if(R->bDoorFixed&&Near(R->ArchivePoint,320)){
  R->bArchive=true;Say(TEXT("你取回旧物。档案第十七条被墨涂掉，院落名也被划去；水底也许保留了未改写的版本。"),10);return;
 }
 if(R->bPavilion&&Near(R->LightPose,1500)&&FVector::CrossProduct(GetViewRotation().Vector(),R->LightPose-Camera->GetComponentLocation()).Size()<75){
  Editing=2;Say(R->bDoorFixed?TEXT("入口已有符维持。可将灯笼移到南桥下方照出第二条线索。 "):TEXT("左右调位置，上下调大小，PageUp / PageDown 调高度。靠近金框后会自动贴合。"),8);return;
 }
 if(R->bCut&&!R->bBridgeFixed&&(FVector::Dist2D(GetActorLocation(),{0,-810,0})<420||FVector::Dist2D(GetActorLocation(),{-960,100,0})<420||FVector::Dist2D(GetActorLocation(),{0,100,0})<300)){
  Editing=1;R->bBridgePreview=true;R->Refresh();Say(TEXT("桥片靠近连接处即可按 F 自动吸附成桥。默认位置就能通过，T 可换连接岸。"),8);return;
 }
 if(Near(R->DoorPoint,400))Say(R->bDoorFixed?TEXT("入口已经固定。可以穿过门，前往夹层的档案桌。 "):TEXT("这道封墙没有门锁。池心亭的灯和门影，也许能改变它。"));
 else Say(TEXT("将准星对准亮起的桥影、木牌、灯笼或档案。池岸可取出画片拼桥。"));
}
TArray<FVector2D> AAcademyPlayer::CutPoints(FVector2D V){
 TArray<FVector2D> P;for(int i=0;i<6;i++)P.Add({V.X*(.25f+i*.10f),V.Y*.34f});
 for(int i=1;i<4;i++)P.Add({V.X*.75f,V.Y*(.34f+i*.106667f)});
 for(int i=1;i<6;i++)P.Add({V.X*(.75f-i*.10f),V.Y*.66f});
 for(int i=1;i<=3;i++)P.Add({V.X*.25f,V.Y*(.66f-i*.106667f)});return P;
}
void AAcademyPlayer::Cut(){
 if(!WorldPuzzle||bJournal)return;if(bCutting){CloseCut();return;}
 if(!WorldPuzzle->bRecorded){Say(TEXT("画卷还是空的。先摇铃显露桥影，再按 E 收录。"));return;}
 if(WorldPuzzle->bCut){Say(TEXT("桥片已裁好，只有这一份。到池岸按 E 用仙杖放置。"));return;}
 bCutting=true;CutProgress=0;Editing=0;GetCharacterMovement()->StopMovementImmediately();
 if(auto* PC=Cast<APlayerController>(Controller)){PC->bShowMouseCursor=true;FInputModeGameAndUI Mode;Mode.SetHideCursorDuringCapture(false);Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);PC->SetInputMode(Mode);}
}
void AAcademyPlayer::CloseCut(){
 bCutting=false;if(auto* PC=Cast<APlayerController>(Controller)){PC->bShowMouseCursor=false;PC->SetInputMode(FInputModeGameOnly());}
}
void AAcademyPlayer::CutSample(FVector2D Pos,FVector2D V,bool Held){
 if(!bCutting||!Held)return;auto Points=CutPoints(V);float Radius=FMath::Max(27.f,float(V.X)*.023f);
 if(Points.IsValidIndex(CutProgress)&&FVector2D::Distance(Pos,Points[CutProgress])<Radius){
  CutProgress++;if(CutProgress==Points.Num()){WorldPuzzle->bCut=true;CloseCut();Say(TEXT("桥的画片已裁出。走到池岸按 E 放出画片，再按 F 自动吸附成桥。"),8);}
 }
}
void AAcademyPlayer::Fix(){
 auto* R=WorldPuzzle.Get();if(!R||bCutting||bJournal)return;
 if(Editing==1){
  if(!R->BridgeAligned()){Say(TEXT("桥片离连接处较远。稍微移近后按 F，位置和角度都会自动校正。"));return;}
  if(R->Symbols()<1){Say(TEXT("没有空闲符纸。先回收另一处的符。"));return;}
  R->BridgePose=R->DockPose(R->Dock);R->BridgeYaw=R->Dock==0?0:90;R->bBridgeFixed=true;R->bBridgePreview=false;Editing=0;R->Refresh();R->SoundAt(TEXT("Bell"),R->BridgePose,.4f);Say(TEXT("符纸固定了墨线，画桥成为实体。现在可以走上桥前往池心亭。"),7);return;
 }
 if(R->bDoorFixed){Say(TEXT("门影已经由符纸固定，灯笼可以自由移走。"));return;}
 if(!R->bPavilion||(Editing!=2&&!Near(R->DoorPoint,410))){Say(TEXT("到池心亭调整灯笼，或对准一处已经对齐的变化再贴符。"));return;}
 R->Refresh();
 if(R->Alignment<DoorFit::Ready||R->LightPose.Y>=320||R->LightPose.Y<=-120){Say(TEXT("再把门影移近金色门框。接近后会自动贴合，亮金色时按 F 即可。"));return;}
 if(R->Symbols()<1){Say(TEXT("没有空闲符纸。先回收另一处的符。"));return;}
 R->bDoorFixed=true;Editing=0;R->Refresh();R->SoundAt(TEXT("WallVoice"),{0,1250,180});Say(TEXT("第二张符让门影成为真实入口。沿桥返回池岸，再绕回廊进入藏书阁。"),8);
}
void AAcademyPlayer::Recall(){
 auto* R=WorldPuzzle.Get();if(!R||bCutting||bJournal)return;float Now=GetWorld()->GetTimeSeconds();int Target=0;
 if(R->bBridgeFixed&&R->AtBridgeAnchor(GetActorLocation()))Target=1;
 else if(R->bDoorFixed&&FVector::Dist2D(GetActorLocation(),R->DoorPoint)<380)Target=2;
 if(Target==0){Say(TEXT("到桥头或入口旁按 G 揭符。符纸和画片可以反复回收。"));return;}
 if(Target==1&&R->OnBridge(GetActorLocation())){Say(TEXT("你还站在桥上。先退到石岸或亭基，才可安全回收。"));return;}
 if(Target==2&&GetActorLocation().Y>940){Say(TEXT("先站回庭院一侧，再收回门符，避免把自己封在夹层里。"));return;}
 if(RecallTarget!=Target||Now>RecallUntil){RecallTarget=Target;RecallUntil=Now+4;Say(Target==1?TEXT("再次按 G：整座画桥会消失，符纸与画片返回手中。金色预告标出将消失的路线。 "):TEXT("再次按 G：入口会恢复为封墙，符纸返回手中。先确认已回到庭院。"),4);return;}
 RecallTarget=0;
 if(Target==1){R->bBridgeFixed=false;R->bBridgePreview=false;Say(TEXT("桥与符纸已回收。原来被桥遮挡的池面重新露出；也可以换一个岸边拼桥。"),7);}
 else {R->bDoorFixed=false;Say(TEXT("门符已揭下。影子重新依赖灯光，可以调整灯笼再次打开入口。"));}
 R->Refresh();
}
void AAcademyPlayer::Cancel(){if(bCutting)CloseCut();bJournal=false;bEndDismissed=true;Editing=0;RecallTarget=0;if(WorldPuzzle){WorldPuzzle->bBridgePreview=false;WorldPuzzle->Refresh();}}
void AAcademyPlayer::Journal(){if(bCutting)return;bJournal=!bJournal;Editing=0;if(WorldPuzzle)WorldPuzzle->bBridgePreview=false;}
void AAcademyPlayer::ResetSafe(){Cancel();GetCharacterMovement()->StopMovementImmediately();SetActorLocation({0,-1270,92},false,nullptr,ETeleportType::TeleportPhysics);Controller->SetControlRotation(FRotator(0,90,0));Say(TEXT("已返回庭院入口，保留所有线索与法术状态。"));}
void AAcademyPlayer::RestartPuzzle(){UGameplayStatics::OpenLevel(this,TEXT("/Game/Maps/MoonlitCourtyard"));}
void AAcademyPlayer::SwitchDock(){if(Editing!=1)return;auto* R=WorldPuzzle.Get();R->Dock=1-R->Dock;R->BridgePose=R->DockPose(R->Dock)+FVector(80,0,0);R->BridgeYaw=(R->Dock==0?0:90)+15;R->Refresh();Say(R->Dock==0?TEXT("连接南岸：按 F 即可自动放正并成桥。"):TEXT("连接西岸：按 F 即可自动放正并成桥。"));}
void AAcademyPlayer::Tick(float Dt){
 Super::Tick(Dt);auto* R=WorldPuzzle.Get();auto* PC=Cast<APlayerController>(Controller);if(!R||!PC)return;
 if(GetActorLocation().Z<-65){ResetSafe();Say(TEXT("你落入池水，已回到入口。画片、符纸与调查进度均已保留。"),6);}
 FVector Pos=GetActorLocation();if(FMath::Abs(Pos.X)<250&&Pos.Y>-150&&Pos.Y<350&&R->bBridgeFixed)R->bPavilion=true;
 if(bCutting){int32 W,H;PC->GetViewportSize(W,H);float X,Y;if(PC->GetMousePosition(X,Y))CutSample({X,Y},{float(W),float(H)},PC->IsInputKeyDown(EKeys::LeftMouseButton));}
 if(Editing){
  float Speed=PC->IsInputKeyDown(EKeys::LeftShift)?25.f:115.f;
  float X=float(PC->IsInputKeyDown(EKeys::Right))-float(PC->IsInputKeyDown(EKeys::Left));
  float Y=float(PC->IsInputKeyDown(EKeys::Up))-float(PC->IsInputKeyDown(EKeys::Down));
  float Z=float(PC->IsInputKeyDown(EKeys::PageUp))-float(PC->IsInputKeyDown(EKeys::PageDown));
  if(Editing==1){R->BridgePose+=FVector(X,Y,0)*Speed*Dt;R->BridgePose.X=FMath::Clamp(R->BridgePose.X,-1000.,850.);R->BridgePose.Y=FMath::Clamp(R->BridgePose.Y,-800.,700.);R->BridgeYaw+=(float(PC->IsInputKeyDown(EKeys::R))-float(PC->IsInputKeyDown(EKeys::Q)))*(Speed*.3f)*Dt;}
  else {R->LightPose+=FVector(X,Y,Z)*Speed*Dt;R->LightPose.X=FMath::Clamp(R->LightPose.X,-750.,750.);R->LightPose.Y=FMath::Clamp(R->LightPose.Y,R->bDoorFixed?-720.:-100.,R->bDoorFixed?280.:150.);R->LightPose.Z=FMath::Clamp(R->LightPose.Z,85.,440.);}
  R->Refresh();
 }
 if(FParse::Param(FCommandLine::Get(),TEXT("CourtVerify")))Verify(Dt);
}
FString AAcademyPlayer::Prompt()const{
 auto* R=WorldPuzzle.Get();if(!R||bCutting||bJournal)return TEXT("");
 if(Editing==1)return R->BridgeAligned()?TEXT("已进入吸附范围  ·  F 自动放正并成桥"):TEXT("方向键 移近连接处   F 自动吸附   T 换岸   Tab 收起");
 if(Editing==2)return R->bDoorFixed?TEXT("入口保持开启  ·  移灯照向原南桥下的池水  ·  E 放下"):R->Alignment>=DoorFit::Ready?TEXT("门影已自动贴合  ·  F 贴符开门"):TEXT("左右 移动门影   上下 调整大小   PgUp/PgDn 调整高度   靠近后自动贴合");
 if(R->bPoolVisible&&Near(R->RecordPoint,620))return TEXT("E  辨认池底姓名，与档案印证");
 if(R->bDoorFixed&&Near(R->ArchivePoint,320))return TEXT("E  取回旧物 / 阅读删改档案");
 if(R->bPavilion&&Near(R->LightPose,1500)&&FVector::CrossProduct(GetViewRotation().Vector(),R->LightPose-Camera->GetComponentLocation()).Size()<75)return TEXT("E  用仙杖选中灯笼");
 if(Near(R->TreePoint,350))return TEXT("E  触碰木牌    B  摇铃听取记忆");
 if(!R->bRecorded&&GetWorld()->GetTimeSeconds()<R->RevealUntil&&Near({0,-475,-22},690))return TEXT("E  用画卷收录桥影");
 if(R->bBridgeFixed&&R->AtBridgeAnchor(GetActorLocation()))return TEXT("G  预览回收画桥 / 再按确认");
 if(R->bCut&&!R->bBridgeFixed&&(Near({0,-800,0},530,false)||Near({-950,100,0},530,false)))return TEXT("E  取出桥片并调整位置");
 if(Near(R->DoorPoint,420,false))return R->bDoorFixed?TEXT("穿过入口阅读档案    G 揭符"):TEXT("B  摇铃，聆听墙后回应");
 if(Near({0,-750,0},550,false))return TEXT("B  摇铃，观察池水");
 return TEXT("");
}

void AAcademyHUD::DrawHUD(){
 Super::DrawHUD();auto* P=Cast<AAcademyPlayer>(GetOwningPawn());if(!Canvas||!P||!P->WorldPuzzle)return;auto* R=P->WorldPuzzle.Get();
 const float W=Canvas->SizeX,H=Canvas->SizeY,S=FMath::Min(W/1440.f,H/900.f);
 UFont* Font=LoadObject<UFont>(nullptr,TEXT("/Engine/EngineFonts/Roboto.Roboto"));if(!Font)Font=GEngine->GetMediumFont();
 auto Text=[&](const FString& T,float X,float Y,float Size=1.f,FLinearColor Color=FLinearColor::White){DrawText(T,Color,X,Y,Font,Size*S*1.4f,false);};
 auto Panel=[&](float X,float Y,float Width,float Height){DrawRect(FLinearColor(.018f,.035f,.048f,.94f),X,Y,Width,Height);};
 const FLinearColor Jade(.40f,.92f,.79f),Gold(1,.74f,.35f),Muted(.66f,.74f,.76f);
 Panel(24*S,20*S,W-48*S,108*S);DrawRect(Jade,24*S,20*S,4*S,108*S);
 Text(TEXT("浮空书院  /  藏书阁庭院"),44*S,30*S,1.35f,Jade);
 Text(R->Objective(),44*S,80*S,.86f);
 Text(FString::Printf(TEXT("符纸  %d / 2"),R->Symbols()),W-180*S,34*S,.95f,Gold);
 Panel(24*S,H-96*S,W-48*S,73*S);
 Text(TEXT("WASD 移动   鼠标 观察   Space 跳跃   B 摇铃   E 交互   C 裁画   F 贴符   G 揭符"),44*S,H-85*S,.82f,Muted);
 Text(TEXT("J 调查手记   Tab 收起 / 取消   Home 回到入口（保留进度）   F5 重玩"),44*S,H-53*S,.76f,Muted);
 if(!P->bCutting&&!P->bJournal){
  DrawLine(W/2-5,H/2,W/2+5,H/2,Jade,1);DrawLine(W/2,H/2-5,W/2,H/2+5,Jade,1);
  FString Prompt=P->Prompt();if(!Prompt.IsEmpty()){Panel(W*.14f,H*.73f,W*.72f,44*S);Text(Prompt,W*.16f,H*.73f+10*S,.88f,Jade);}
  if(P->NoticeUntil>GetWorld()->GetTimeSeconds()){Panel(24*S,H-156*S,W-48*S,49*S);Text(P->Notice,42*S,H-144*S,.80f);}
  if(P->Editing){
   Panel(24*S,145*S,402*S,116*S);
   Text(P->Editing==1?TEXT("仙杖 / 画片拼接"):TEXT("仙杖 / 灯影投射"),42*S,157*S,1,Gold);
   if(P->Editing==1){
    Text(R->Dock==0?TEXT("南岸 → 池心亭"):TEXT("古树西岸 → 池心亭"),42*S,191*S,.82f);
    Text(R->BridgeAligned()?TEXT("按 F 自动吸附，无需调整角度"):TEXT("把画片移近连接处即可，无需精确对齐"),42*S,222*S,.76f,Jade);
   }else{
    Text(R->bDoorFixed?TEXT("门符已固定，可移动灯笼照亮池底"):R->Alignment>=DoorFit::Ready?TEXT("已自动贴合，按 F 开门"):TEXT("上下调大小，靠近金框后自动贴合"),42*S,191*S,.78f);
    DrawRect(FLinearColor(.12f,.21f,.24f),42*S,230*S,340*S,9*S);
    DrawRect(R->Alignment>=DoorFit::Ready?Gold:Jade,42*S,230*S,340*S*R->Alignment,9*S);
   }
  }
  if(P->RecallTarget&&P->RecallUntil>GetWorld()->GetTimeSeconds()){
   Panel(W*.25f,H*.25f,W*.5f,75*S);Text(P->RecallTarget==1?TEXT("即将消失：整座画桥"):TEXT("即将消失：藏书阁入口"),W*.28f,H*.25f+10*S,1.05f,Gold);
   Text(TEXT("再次按 G 回收；Tab 取消。"),W*.28f,H*.25f+44*S,.8f);
   FVector A=P->RecallTarget==1?R->BridgePose:R->DoorPoint;FVector Screen=Project(A);if(Screen.Z>0){DrawLine(W/2,H*.25f+75*S,Screen.X,Screen.Y,Gold,2);DrawRect(FLinearColor(1,.55f,.1f,.3f),Screen.X-28*S,Screen.Y-28*S,56*S,56*S);}
  }
  if(!R->bRecorded&&GetWorld()->GetTimeSeconds()<R->RevealUntil)Text(FString::Printf(TEXT("桥影将于 %.0f 秒后消散 · 可再次摇铃"),R->RevealUntil-GetWorld()->GetTimeSeconds()),40*S,147*S,.78f,Jade);
  if(R->bComplete&&!P->bEndDismissed){Panel(W*.19f,H*.23f,W*.62f,138*S);Text(TEXT("庭院之谜 / 记忆得以复原"),W*.22f,H*.23f+18*S,1.5f,Gold);Text(FString::Printf(TEXT("第十七名：%s    原属：%s"),*R->MissingStudent,*R->MissingCourt),W*.22f,H*.23f+65*S,1);Text(TEXT("档案与池底记录相互印证。J 查看手记；Tab 收起后继续探索。"),W*.22f,H*.23f+103*S,.78f,Jade);}
 }
 if(P->bCutting){
  Panel(W*.14f,H*.20f,W*.72f,H*.57f);Text(TEXT("徒手裁画 / 从金点起，顺时针描过边界"),W*.21f,H*.23f,1.15f,Gold);
  DrawRect(FLinearColor(.68f,.68f,.55f,1),W*.24f,H*.32f,W*.52f,H*.36f);
  DrawRect(Ink::Dark,W*.23f,H*.30f,14*S,H*.40f);DrawRect(Ink::Dark,W*.76f,H*.30f,14*S,H*.40f);
  auto Points=AAcademyPlayer::CutPoints({W,H});
  for(int i=0;i<Points.Num()-1;i++)DrawLine(Points[i].X,Points[i].Y,Points[i+1].X,Points[i+1].Y,i<P->CutProgress?Jade:Ink::Dark,3*S);
  // Schematic bridge inside the paper: rails and planks are separate from the cut border.
  for(int i=0;i<2;i++)DrawLine(W*.32f,H*(.43f+i*.14f),W*.68f,H*(.43f+i*.14f),Ink::Dark,6*S);
  for(int i=0;i<9;i++)DrawLine(W*(.32f+i*.045f),H*.43f,W*(.32f+i*.045f),H*.57f,Ink::Dark,3*S);
  if(Points.IsValidIndex(P->CutProgress)){auto C=Points[P->CutProgress];DrawRect(Gold,C.X-10*S,C.Y-10*S,20*S,20*S);}
  Text(TEXT("按住鼠标左键，依次描过亮点。可松开续画；Tab 收起。"),W*.21f,H*.71f,.86f,Jade);
 }
 if(P->bJournal){
  Panel(W*.14f,H*.18f,W*.72f,H*.64f);Text(TEXT("调查手记 / 景物与记录"),W*.18f,H*.21f,1.4f,Gold);
  TArray<FString> Lines={
   TEXT("最初的目的：取回藏书阁里的旧物。"),
   R->bTreeHeard?TEXT("木牌：第十七块名牌缺失，残声提到被擦除的院落。"):TEXT("木牌：尚未听取记忆。古树在水池西侧。"),
   R->bRecorded?TEXT("画卷：已收录不存在于现实中的桥；画片只有一份。"):TEXT("倒影：到南侧池岸摇铃，观察水中异常。"),
   R->bPavilion?TEXT("亭中灯：门影随灯的位置与高度变化。贴符可使变化持续。"):TEXT("池心亭：需要将画桥拼进现实，才能抵达。"),
   R->bArchive?TEXT("夹层档案：第十七条姓名与院落被涂改，旧物已经取回。"):TEXT("夹层档案：藏在封墙之后，尚未查看。"),
   R->bComplete?FString::Printf(TEXT("池底原文：%s，%s。与被删去的档案编号相符。"),*R->MissingStudent,*R->MissingCourt):TEXT("池底记录：读过档案后，移灯照向南桥下方，收桥，再摇铃。"),
   TEXT("两张符可回收：桥头 / 入口旁 G 预览，再按 G 确认。"),
   TEXT("桥有两个位置：选中画片时 T 换岸，F 自动吸附固定。"),
   TEXT("灯的位置：方向键平移，PageUp / PageDown 升降，Shift 微调。")};
  for(int i=0;i<Lines.Num();i++)Text(Lines[i],W*.18f,H*.28f+i*40*S,.87f,i==5&&R->bComplete?Jade:FLinearColor::White);
  Text(TEXT("J / Tab 返回庭院。隐藏记忆的原因仍待后续调查。"),W*.18f,H*.76f,.8f,Muted);
 }
}

// Runs only with -CourtVerify. It exercises the same interaction functions as input,
// including rejected placements, reversible changes, collision traversal and clue gates.
void AAcademyPlayer::Verify(float Dt){
 static int Stage=0;static float Time=0;static FString Report;static FVector Start;
 if(Stage<0)return;Time+=Dt;auto* R=WorldPuzzle.Get();
 auto Check=[&](bool Good,const TCHAR* Name){Report+=FString::Printf(TEXT("%s: %s\n"),Good?TEXT("PASS"):TEXT("FAIL"),Name);UE_LOG(LogTemp,Display,TEXT("COURT_VERIFY %s: %s"),Good?TEXT("PASS"):TEXT("FAIL"),Name);FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("CourtyardVerification.txt")));if(!Good)Stage=-1;return Good;};
 auto Snap=[&](FVector V){SetActorLocation(V,false,nullptr,ETeleportType::TeleportPhysics);GetCharacterMovement()->StopMovementImmediately();};
 auto Face=[&](FVector V){Controller->SetControlRotation((V-Camera->GetComponentLocation()).Rotation());};
 auto Shot=[&](const TCHAR* N){FScreenshotRequest::RequestScreenshot(FPaths::ProjectSavedDir()/TEXT("Screenshots")/N,true,false);};
 if(Stage==1&&FVector::Dist2D(Start,GetActorLocation())<220&&Time<3.f){Forward(1);return;}
 if(Stage==8&&GetActorLocation().Y<50&&Time<4.f){Forward(1);return;}
 if(Stage==15&&GetActorLocation().Y<1330&&Time<3.f){Forward(1);return;}
 if(Time<(Stage==2?.20f:Stage==0?3.f:.85f))return;
 switch(Stage){
 case 0:UE_LOG(LogTemp,Display,TEXT("COURT_DIAGNOSTIC Pawn=%s Court=%s Scale=%s"),*GetActorLocation().ToString(),*R->GetActorLocation().ToString(),*R->GetActorScale3D().ToString());{TArray<UStaticMeshComponent*> Parts;R->GetComponents(Parts);for(auto* C:Parts)if(C->GetName()==TEXT("SouthCourt"))UE_LOG(LogTemp,Display,TEXT("COURT_FLOOR Pos=%s Scale=%s Visible=%d Collision=%d Mesh=%s"),*C->GetComponentLocation().ToString(),*C->GetComponentScale().ToString(),C->IsVisible(),C->IsCollisionEnabled(),*GetNameSafe(C->GetStaticMesh()));}if(!Check(R&&Camera->bUsePawnControlRotation&&R->Symbols()==2,TEXT("First-person spawn, two free talismans")))return;Face({0,200,175});Shot(TEXT("01_Courtyard.png"));Start=GetActorLocation();break;
 case 1:UE_LOG(LogTemp,Display,TEXT("COURT_WALK Start=%s End=%s Speed=%s"),*Start.ToString(),*GetActorLocation().ToString(),*GetVelocity().ToString());if(!Check(FVector::Dist2D(Start,GetActorLocation())>180,TEXT("Walking movement works")))return;Start=GetActorLocation();Jump();break;
 case 2:if(!Check(GetActorLocation().Z>Start.Z+10,TEXT("Space-style jumping lifts character")))return;StopJumping();Snap({-1100,-450,90});Face(R->TreePoint);Bell();if(!Check(R->bTreeHeard,TEXT("Tree bell reveals memory and plaques")))return;break;
 case 3:Snap({0,-970,90});Face({0,-475,-22});LastBell=-10;Bell();if(!Check(R->RevealUntil>GetWorld()->GetTimeSeconds(),TEXT("Pool bell reveals temporary bridge reflection")))return;Shot(TEXT("02_Reflection.png"));break;
 case 4:Interact();if(!Check(R->bRecorded&&!R->bCut,TEXT("Scroll records single revealed painting")))return;Cut();Shot(TEXT("03_CutPainting.png"));break;
 case 5:{if(!Check(bCutting,TEXT("Cutting opens actual mouse tracing interaction")))return;CutSample({0,0},{1440,900},true);if(!Check(CutProgress==0,TEXT("Tracing outside boundary does not cut")))return;for(auto V:CutPoints({1440,900}))CutSample(V,{1440,900},true);if(!Check(R->bCut&&!bCutting,TEXT("Tracing complete boundary produces bridge piece")))return;Interact();if(!Check(R->BridgeAligned(),TEXT("Default bridge placement immediately qualifies for snapping")))return;R->BridgePose=R->DockPose(0)+FVector(450,0,0);Fix();if(!Check(!R->bBridgeFixed&&Editing==1,TEXT("Bridge far outside snap range does not consume a talisman")))return;break;}
 case 6:R->BridgePose=R->DockPose(0)+FVector(180,100,0);R->BridgeYaw=75;Fix();if(!Check(R->bBridgeFixed&&R->Symbols()==1&&R->BridgePose.Equals(R->DockPose(0))&&FMath::IsNearlyZero(R->BridgeYaw),TEXT("Roughly placed rotated bridge snaps into a safe walkable pose")))return;Face({0,280,175});Shot(TEXT("04_SolidBridge.png"));break;
 case 7:Snap({0,-895,90});Face({0,400,154});Start=GetActorLocation();break;
 case 8:if(!Check(GetActorLocation().Y>0&&R->bPavilion,TEXT("Character physically walks across bridge to isolated pavilion")))return;Snap({110,130,90});Face(R->LightPose);Interact();if(!Check(Editing==2,TEXT("Wand selects pavilion lantern")))return;Fix();if(!Check(!R->bDoorFixed,TEXT("Incorrect projection cannot open wall")))return;break;
 case 9:R->LightPose={0,50,107.142857};R->Refresh();if(!Check(R->Alignment>.99f,TEXT("Perspective projection aligns by lamp position and height")))return;R->LightPose={20,100,105};R->Refresh();if(!Check(R->Alignment>=DoorFit::Ready,TEXT("Moderate position and size errors snap visibly onto doorway")))return;{TArray<USceneComponent*> Edges;R->DoorShadow->GetChildrenComponents(false,Edges);bool Match=Edges.Num()==4&&R->FrameTraces.Num()==3;for(int i=0;i<2&&Match;i++){Match=FMath::IsNearlyEqual(Edges[i]->GetRelativeLocation().X,R->FrameTraces[i]->GetRelativeLocation().X)&&FMath::IsNearlyEqual(Edges[i]->GetRelativeLocation().Z,R->FrameTraces[i]->GetRelativeLocation().Z)&&FMath::IsNearlyEqual(Edges[i]->GetRelativeScale3D().Z,R->FrameTraces[i]->GetRelativeScale3D().Z);}if(Match)Match=FMath::IsNearlyEqual(Edges[3]->GetRelativeLocation().Z,R->FrameTraces[2]->GetRelativeLocation().Z)&&FMath::IsNearlyEqual(Edges[3]->GetRelativeScale3D().X,R->FrameTraces[2]->GetRelativeScale3D().X);if(!Check(Match,TEXT("Projected frame matches actual gold frame width height and center")))return;}NoticeUntil=0;Face({0,1050,270});Shot(TEXT("05_DoorProjection.png"));break;
 case 10:Fix();if(!Check(R->bDoorFixed&&R->Symbols()==0,TEXT("Second talisman materializes a real door")))return;R->LightPose={160,-150,290};R->Refresh();if(!Check(R->bDoorFixed&&!R->SealedWall->IsCollisionEnabled(),TEXT("Fixed doorway persists after lantern moves")))return;break;
 case 11:Snap({0,905,90});Face(R->DoorPoint);Recall();Recall();if(!Check(!R->bDoorFixed&&R->Symbols()==1,TEXT("Removing door talisman restores blocking wall and returns resource")))return;R->LightPose={0,50,107.142857};R->Refresh();Fix();if(!Check(R->bDoorFixed,TEXT("Door can be recreated after recall")))return;break;
 case 12:Snap({0,1180,90});Recall();if(!Check(R->bDoorFixed,TEXT("Cannot close doorway while player is inside")))return;Snap({0,940,90});Face({0,1500,154});break;
 case 13:Snap({0,940,90});Face({0,1500,154});Start=GetActorLocation();break;
 case 14:break;
 case 15:if(!Check(GetActorLocation().Y>1250,TEXT("Character physically traverses opened wall")))return;Face(R->ArchivePoint);Interact();if(!Check(R->bArchive,TEXT("Read redacted archive and recover keepsake")))return;Shot(TEXT("06_Archive.png"));break;
 case 16:Snap({0,-940,90});R->LightPose={0,-475,260};Face(R->RecordPoint);LastBell=-10;Bell();R->Refresh();if(!Check(!R->bPoolVisible,TEXT("Bridge blocks record despite correct light and bell")))return;Snap({0,-450,94});Recall();if(!Check(R->bBridgeFixed,TEXT("Cannot remove bridge under player's feet")))return;Snap({0,-940,90});RecallTarget=0;Recall();Shot(TEXT("07_RecallPreview.png"));break;
 case 17:Recall();if(!Check(!R->bBridgeFixed&&R->Symbols()==1,TEXT("Bridge and talisman are recoverable")))return;R->LightPose={600,100,200};LastBell=-10;Bell();R->Refresh();if(!Check(!R->bPoolVisible,TEXT("Pool record requires illumination as well as reveal")))return;R->LightPose={0,-475,260};LastBell=-10;Bell();R->Refresh();if(!Check(R->bPoolVisible,TEXT("Archive, uncovered pool, light and bell reveal original record")))return;Face(R->RecordPoint);Shot(TEXT("08_PoolRecord.png"));break;
 case 18:Interact();if(!Check(R->bComplete,TEXT("Read pool name to corroborate erased archive")))return;Shot(TEXT("09_Complete.png"));break;
 case 19:Snap({-1060,100,90});Face({-600,100,6});Interact();if(Editing!=1){Cancel();R->LightPose={700,-650,260};Interact();}SwitchDock();if(!Check(R->BridgeAligned(),TEXT("Default west-bank placement also qualifies without adjustment")))return;Fix();if(!Check(R->bBridgeFixed&&R->Dock==1&&R->Symbols()==0,TEXT("Same unique bridge can reconnect west bank without duplication")))return;R->LightPose={0,-475,260};R->RevealUntil=GetWorld()->GetTimeSeconds()+10;R->Refresh();if(!Check(!R->PoolCovered()&&R->bPoolVisible,TEXT("West bridge leaves southern pool record uncovered")))return;break;
 case 20:Recall();Recall();if(!Check(!R->bBridgeFixed&&R->Symbols()==1,TEXT("Alternate bridge placement is reversible")))return;R->RevealUntil=GetWorld()->GetTimeSeconds()-1;R->Refresh();if(!Check(!R->bPoolVisible&&R->bComplete,TEXT("Reveal expires while acquired narrative evidence persists")))return;Snap({0,-1000,-100});break;
 case 21:if(!Check(GetActorLocation().Z>0&&R->bArchive&&R->bComplete,TEXT("Water recovery preserves all investigation progress")))return;GetCharacterMovement()->SetMovementMode(MOVE_Flying);Snap({1850,-2300,1600});Face({-150,150,100});if(auto* H=Cast<APlayerController>(Controller)->GetHUD())H->bShowHUD=false;{TArray<UStaticMeshComponent*> Parts;GetComponents(Parts);for(auto* C:Parts)C->SetVisibility(false);}break;
 case 22:Shot(TEXT("10_CourtyardOverview.png"));break;
 case 23:if(auto* H=Cast<APlayerController>(Controller)->GetHUD())H->bShowHUD=true;{TArray<UStaticMeshComponent*> Parts;GetComponents(Parts);for(auto* C:Parts)C->SetVisibility(true);}GetCharacterMovement()->SetMovementMode(MOVE_Walking);ResetSafe();Report+=TEXT("ALL_CHECKS_PASSED\n");FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("CourtyardVerification.txt")));Stage=-1;return;
 }
 Stage++;Time=0;
}





