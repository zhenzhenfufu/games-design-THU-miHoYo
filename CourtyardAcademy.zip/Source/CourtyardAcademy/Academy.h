#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "Academy.generated.h"

class UCameraComponent;
class UStaticMeshComponent;
class UPointLightComponent;
class USoundBase;

UCLASS()
class COURTYARDACADEMY_API AAcademyCourt : public AActor {
 GENERATED_BODY()
public:
 AAcademyCourt();
 virtual void OnConstruction(const FTransform& Transform) override;
 virtual void BeginPlay() override;
 virtual void Tick(float Dt) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Court;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Bridge;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Reflection;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Lantern;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> DoorShadow;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> DoorSeal;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> BridgeSeal;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> PoolWriting;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> MemoryGlow;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Ripples;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> SealedWall;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UPointLightComponent> LampLight;
 UPROPERTY() TArray<TObjectPtr<UStaticMeshComponent>> FrameTraces;
 UPROPERTY(EditAnywhere, Category="Narrative") FString MissingStudent=TEXT("陆衡");
 UPROPERTY(EditAnywhere, Category="Narrative") FString MissingCourt=TEXT("听雨院");
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bRecorded=false;
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bCut=false;
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bBridgeFixed=false;
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bDoorFixed=false;
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bArchive=false;
 UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Puzzle") bool bComplete=false;
 bool bTreeHeard=false,bWallHeard=false,bPavilion=false,bBridgePreview=false,bPoolVisible=false;
 int32 Dock=0;
 float RevealUntil=0,TreeUntil=0,WallUntil=0,RippleStart=-100;
 FVector BridgePose=FVector(95,-475,6);
 float BridgeYaw=17;
 FVector LightPose=FVector(-95,100,145);
 FVector TreePoint=FVector(-1260,-270,135);
 FVector ArchivePoint=FVector(0,1520,110);
 FVector DoorPoint=FVector(0,1045,215);
 FVector RecordPoint=FVector(0,-475,-118);
 float Alignment=0;
 float SolidAmount=0;
 int32 Symbols() const {return 2-int32(bBridgeFixed)-int32(bDoorFixed);}
 bool BridgeAligned() const;
 bool PoolLit() const;
 bool PoolCovered() const {return bBridgeFixed&&Dock==0;}
 bool OnBridge(FVector Point) const;
 bool AtBridgeAnchor(FVector Point) const;
 FVector DockPose(int32 Index) const;
 void Refresh();
 void SetGroup(USceneComponent* Group,bool Visible,bool Collision=false);
 void SoundAt(const TCHAR* Asset,FVector Point,float Volume=1);
 FString Objective() const;
private:
 UPROPERTY() TObjectPtr<UStaticMesh> Cube;
 UPROPERTY() TObjectPtr<UStaticMesh> Cylinder;
 UPROPERTY() TObjectPtr<UStaticMesh> Sphere;
 UPROPERTY() TObjectPtr<UMaterialInterface> Surface;
 UPROPERTY() TArray<TObjectPtr<USoundBase>> AudioAssets;
 USceneComponent* Group(const TCHAR* Name);
 UStaticMeshComponent* Shape(const FString& Name,FVector Position,FVector Size,FLinearColor Color,USceneComponent* Parent=nullptr,bool Collision=true,int32 Form=0,float Glow=0);
 void Label(const FString& Name,const FString& Text,FVector Position,FRotator Rotation,float Size,FColor Color);
 void Paint();
};

UCLASS()
class COURTYARDACADEMY_API AAcademyPlayer : public ACharacter {
 GENERATED_BODY()
public:
 AAcademyPlayer();
 virtual void BeginPlay() override;
 virtual void Tick(float Dt) override;
 virtual void SetupPlayerInputComponent(UInputComponent* Input) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UCameraComponent> Camera;
 UPROPERTY() TObjectPtr<AAcademyCourt> WorldPuzzle;
 int32 Editing=0; // 0 walking, 1 bridge, 2 lantern
 bool bCutting=false,bJournal=false,bEndDismissed=false;
 int32 CutProgress=0,RecallTarget=0;
 float NoticeUntil=0,RecallUntil=0,LastBell=-10;
 FString Notice;
 FVector LastSafe=FVector(0,-1350,92);
 void Say(const FString& Text,float Seconds=5);
 bool Near(FVector Point,float Distance,bool Facing=true) const;
 void Bell(); void Interact(); void Cut(); void Fix(); void Recall(); void Cancel();
 void Journal(); void ResetSafe(); void RestartPuzzle(); void SwitchDock();
 void CutSample(FVector2D Position,FVector2D ViewSize,bool Held);
 static TArray<FVector2D> CutPoints(FVector2D ViewSize);
 FString Prompt() const;
private:
 void Forward(float V);void Right(float V);void Turn(float V);void Look(float V);void JumpStart();
 void CloseCut();
 void Verify(float Dt);
};

UCLASS()
class COURTYARDACADEMY_API AAcademyHUD : public AHUD {
 GENERATED_BODY()
public:
 virtual void DrawHUD() override;
};

UCLASS()
class COURTYARDACADEMY_API AAcademyGameMode : public AGameModeBase {
 GENERATED_BODY()
public:
 AAcademyGameMode();
};

