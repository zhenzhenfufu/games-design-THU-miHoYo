using UnrealBuildTool;
public class CourtyardAcademyEditorTarget : TargetRules {
 public CourtyardAcademyEditorTarget(TargetInfo Target) : base(Target) {
  Type = TargetType.Editor;
  DefaultBuildSettings = BuildSettingsVersion.Latest;
  IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
  ExtraModuleNames.Add("CourtyardAcademy");
 }
}

