"""Build the library sequel only; the original courtyard is left intact."""
import unreal

assets = unreal.AssetToolsHelpers.get_asset_tools()
materials = unreal.MaterialEditingLibrary
books_material = unreal.load_asset('/Game/Materials/M_Court')
assert books_material
books_material.set_editor_property('used_with_instanced_static_meshes', True)
materials.recompile_material(books_material)
assert unreal.EditorAssetLibrary.save_loaded_asset(books_material)
lens_material = unreal.load_asset('/Game/Materials/M_LibraryLens')
if not lens_material:
    lens_material = assets.create_asset(
        'M_LibraryLens', '/Game/Materials', unreal.Material, unreal.MaterialFactoryNew())
    lens_material.set_editor_property('shading_model', unreal.MaterialShadingModel.MSM_UNLIT)
    lens_material.set_editor_property('two_sided', True)
    scene_texture = materials.create_material_expression(
        lens_material, unreal.MaterialExpressionTextureSampleParameter2D, -260, 0)
    scene_texture.set_editor_property('parameter_name', 'MirrorView')
    scene_texture.set_editor_property(
        'texture', unreal.load_asset('/Engine/EngineResources/WhiteSquareTexture'))
    materials.connect_material_property(
        scene_texture, 'RGB', unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    materials.recompile_material(lens_material)
    assert unreal.EditorAssetLibrary.save_loaded_asset(lens_material)

levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
map_path = '/Game/Maps/LibraryMaze'
if unreal.EditorAssetLibrary.does_asset_exist(map_path):
    assert levels.load_level(map_path)
    for actor in actors.get_all_level_actors():
        if actor.get_class().get_name() in (
                'LibraryWorld', 'BP_LibraryMaze_C', 'PlayerStart', 'StaticMeshActor'):
            actors.destroy_actor(actor)
else:
    assert levels.new_level(map_path)

factory = unreal.BlueprintFactory()
parent_class = unreal.load_class(None, '/Script/CourtyardAcademy.LibraryWorld')
assert parent_class, 'Compile the LibraryWorld C++ class before building the map.'
factory.set_editor_property('parent_class', parent_class)
blueprint = unreal.load_asset('/Game/Blueprints/BP_LibraryMaze')
if not blueprint:
    blueprint = assets.create_asset('BP_LibraryMaze', '/Game/Blueprints', unreal.Blueprint, factory)
    assert unreal.EditorAssetLibrary.save_loaded_asset(blueprint)
library = actors.spawn_actor_from_class(blueprint.generated_class(), unreal.Vector())
library.set_actor_label('01 - Library Maze - Garden Fountain and Water Lens')
for light in library.get_components_by_class(unreal.DirectionalLightComponent):
    light.set_editor_property('forward_shading_priority', 1 if light.get_name() == 'Moon' else 0)
start = actors.spawn_actor_from_class(
    unreal.PlayerStart, unreal.Vector(0, -2500, 92), unreal.Rotator(pitch=0, yaw=90, roll=0))
start.set_actor_label('02 - Entrance from Moonlit Courtyard')
sky = actors.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(12000, 0, 0))
sky.set_actor_label('03 - Shared Academy Night Sky')
sky.static_mesh_component.set_static_mesh(unreal.load_asset('/Engine/BasicShapes/Sphere'))
sky.static_mesh_component.set_material(0, unreal.load_asset('/Game/Materials/M_Sky'))
sky.static_mesh_component.set_editor_property('cast_shadow', False)
sky.static_mesh_component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
sky.set_actor_enable_collision(False)
sky.set_actor_scale3d(unreal.Vector(1500, 1500, 1500))
world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
world.get_world_settings().set_editor_property(
    'default_game_mode', unreal.load_class(None, '/Script/CourtyardAcademy.LibraryGameMode'))
levels.set_level_viewport_camera_info(
    unreal.Vector(2200, -3000, 2400), unreal.Rotator(pitch=-32, yaw=128, roll=0), 'None')
assert levels.save_current_level()
unreal.log('LIBRARY_MAZE_MAP_BUILD_SUCCESS')
