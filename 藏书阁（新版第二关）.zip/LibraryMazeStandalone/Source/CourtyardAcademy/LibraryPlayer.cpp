#include "LibraryPlayer.h"
#include "LibraryWorld.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Engine/GameViewportClient.h"
#include "EngineUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

ALibraryPlayer::ALibraryPlayer(){
 PrimaryActorTick.bCanEverTick=true;
 GetCapsuleComponent()->InitCapsuleSize(32,88);
 Camera=CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));Camera->SetupAttachment(GetCapsuleComponent());Camera->SetRelativeLocation({0,0,66});Camera->bUsePawnControlRotation=true;Camera->FieldOfView=86;
 Camera->bOverrideAspectRatioAxisConstraint=true;Camera->AspectRatioAxisConstraint=EAspectRatioAxisConstraint::AspectRatio_MaintainXFOV;
 GetCharacterMovement()->MaxWalkSpeed=420;GetCharacterMovement()->MaxStepHeight=30;GetCharacterMovement()->JumpZVelocity=370;GetCharacterMovement()->AirControl=.15f;
 WaterCapture=CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("WorldInsideWater"));WaterCapture->SetupAttachment(GetCapsuleComponent());WaterCapture->bCaptureEveryFrame=false;WaterCapture->bCaptureOnMovement=false;WaterCapture->CaptureSource=ESceneCaptureSource::SCS_FinalColorLDR;WaterCapture->FOVAngle=70;
 WaterCapture->bAlwaysPersistRenderingState=true;
 WaterCapture->PostProcessSettings.bOverride_AutoExposureMethod=true;WaterCapture->PostProcessSettings.AutoExposureMethod=EAutoExposureMethod::AEM_Manual;
 WaterCapture->PostProcessSettings.bOverride_AutoExposureBias=true;WaterCapture->PostProcessSettings.AutoExposureBias=8;
 WaterCapture->PostProcessBlendWeight=0;
}
ALibraryGameMode::ALibraryGameMode(){DefaultPawnClass=ALibraryPlayer::StaticClass();HUDClass=ALibraryHUD::StaticClass();}
void ALibraryPlayer::BeginPlay(){
 Super::BeginPlay();for(TActorIterator<ALibraryWorld> It(GetWorld());It;++It){Puzzle=*It;break;}
 WaterTexture=NewObject<UTextureRenderTarget2D>(this);WaterTexture->RenderTargetFormat=RTF_RGBA8;WaterTexture->InitAutoFormat(1280,720);WaterTexture->UpdateResourceImmediate();WaterCapture->TextureTarget=WaterTexture;
 SyncCup();UE_LOG(LogTemp,Display,TEXT("LIBRARY_LEVEL_READY: %s / %s"),*GetNameSafe(this),*GetNameSafe(Puzzle));
}
void ALibraryPlayer::SetupPlayerInputComponent(UInputComponent* I){
 Super::SetupPlayerInputComponent(I);I->BindAxis(TEXT("Forward"),this,&ALibraryPlayer::Forward);I->BindAxis(TEXT("Right"),this,&ALibraryPlayer::Right);I->BindAxis(TEXT("Turn"),this,&ALibraryPlayer::Turn);I->BindAxis(TEXT("Look"),this,&ALibraryPlayer::Look);
 I->BindKey(EKeys::SpaceBar,IE_Pressed,this,&ALibraryPlayer::JumpStart);I->BindKey(EKeys::SpaceBar,IE_Released,this,&ACharacter::StopJumping);
 I->BindKey(EKeys::E,IE_Pressed,this,&ALibraryPlayer::Interact);I->BindKey(EKeys::F,IE_Pressed,this,&ALibraryPlayer::Observe);I->BindKey(EKeys::R,IE_Pressed,this,&ALibraryPlayer::TakeBack);I->BindKey(EKeys::Tab,IE_Pressed,this,&ALibraryPlayer::Cancel);I->BindKey(EKeys::B,IE_Pressed,this,&ALibraryPlayer::Bell);I->BindKey(EKeys::Left,IE_Pressed,this,&ALibraryPlayer::ViewLeft);I->BindKey(EKeys::Right,IE_Pressed,this,&ALibraryPlayer::ViewRight);I->BindKey(EKeys::Home,IE_Pressed,this,&ALibraryPlayer::Recover);I->BindKey(EKeys::F5,IE_Pressed,this,&ALibraryPlayer::RestartPuzzle);
}
void ALibraryPlayer::Forward(float V){if(!bObserving&&!bTransition&&!bReading&&!bComplete)AddMovementInput(FRotator(0,GetControlRotation().Yaw,0).Vector(),V);}
void ALibraryPlayer::Right(float V){if(!bObserving&&!bTransition&&!bReading&&!bComplete)AddMovementInput(FRotationMatrix(FRotator(0,GetControlRotation().Yaw,0)).GetUnitAxis(EAxis::Y),V);}
void ALibraryPlayer::Turn(float V){if(bReading||bTransition)return;if(bObserving)ObserveYaw=FRotator::NormalizeAxis(ObserveYaw+V*2.5f);else AddControllerYawInput(V);}
void ALibraryPlayer::Look(float V){if(bReading||bTransition)return;if(bObserving)ObservePitch=FMath::Clamp(ObservePitch+V*2.5f,-32.f,32.f);else AddControllerPitchInput(V);}
void ALibraryPlayer::JumpStart(){if(!bReading&&!bObserving&&!bTransition)Jump();}
void ALibraryPlayer::ViewLeft(){if(bObserving&&!bTransition)ObserveYaw=FRotator::NormalizeAxis(ObserveYaw-5);}
void ALibraryPlayer::ViewRight(){if(bObserving&&!bTransition)ObserveYaw=FRotator::NormalizeAxis(ObserveYaw+5);}
void ALibraryPlayer::Say(const FString& T,float D){Notice=T;NoticeUntil=GetWorld()->GetTimeSeconds()+D;}
void ALibraryPlayer::Bell(){if(auto* Sound=LoadObject<USoundBase>(nullptr,TEXT("/Game/Audio/Bell.Bell")))UGameplayStatics::PlaySound2D(this,Sound,.35f);}
int32 ALibraryPlayer::Target()const{
 if(!Puzzle||bObserving||bTransition||bReading)return -1;
 TArray<FVector> P{Puzzle->CupPoint,Puzzle->FountainPoint,Puzzle->BookPoint,Puzzle->PedestalPoints[0],Puzzle->PedestalPoints[1],Puzzle->PedestalPoints[2],Puzzle->LeverPoints[0],Puzzle->LeverPoints[1],Puzzle->LeverPoints[2]};
 float Best=.83f;int32 Result=-1;FVector Eye=Camera->GetComponentLocation(),Dir=Camera->GetForwardVector();
 for(int32 I=0;I<P.Num();I++){
  if(I==0&&bTaken)continue;FVector Delta=P[I]-Eye;float D=Delta.Size();if(D>(I==1?340:250))continue;
  float Dot=FVector::DotProduct(Dir,Delta.GetSafeNormal());if(Dot<=Best)continue;
  FHitResult Hit;FCollisionQueryParams Q(SCENE_QUERY_STAT(LibraryInteract),false,this);
  if(GetWorld()->LineTraceSingleByChannel(Hit,Eye,P[I],ECC_Visibility,Q)&&Hit.Distance<D-(I==1?230:105))continue;
  Best=Dot;Result=I;
 }return Result;
}
FString ALibraryPlayer::Prompt()const{
 if(bReading)return TEXT("E / Tab  合上书页");
 if(bTransition)return TEXT("");
 if(bObserving)return TEXT("鼠标  环视上下四周  ·  ← →  细调  ·  F / Tab  返回");
 int32 T=Target();
 if(T==0)return TEXT("E  拿起玻璃杯");
 if(T==1&&bTaken&&CupPlace<0)return bFilled?TEXT("E  掬水"):TEXT("E  盛水");
 if(T==2)return TEXT("E  翻阅微光中的书");
 if(T>=3&&T<=5){if(CupPlace==T-3)return bFilled?TEXT("F  观察水杯  ·  R  拿回杯子"):TEXT("R  拿回杯子");if(bTaken&&CupPlace<0)return TEXT("E  放下玻璃杯");}
 if(T>=6)return FString::Printf(TEXT("E  转动机关  ·  当前刻度 %d"),Puzzle->GetDial(T-6));
 return TEXT("");
}
void ALibraryPlayer::SyncCup(){if(Puzzle)Puzzle->UpdateCup(CupPlace,bFilled,bTaken&&CupPlace<0);}
void ALibraryPlayer::Interact(){
 if(!Puzzle||bTransition||bObserving)return;if(bReading){bReading=false;return;}
 const int32 T=Target();
 if(T==0){bTaken=true;SyncCup();}
 else if(T==1&&bTaken&&CupPlace<0){bFilled=true;SyncCup();Bell();}
 else if(T==2){bReading=true;GetCharacterMovement()->StopMovementImmediately();}
 else if(T>=3&&T<=5&&bTaken&&CupPlace<0){CupPlace=T-3;SyncCup();}
 else if(T>=6){Puzzle->SetDial(T-6,(Puzzle->GetDial(T-6)+1)%4);}
}
void ALibraryPlayer::TakeBack(){if(bReading||bObserving||bTransition)return;if(CupPlace>=0&&Target()==CupPlace+3){CupPlace=-1;SyncCup();}}
void ALibraryPlayer::Observe(){
 if(bReading||bTransition)return;if(bObserving){StartObservation(false);return;}
 if(CupPlace>=0&&bFilled&&Target()==CupPlace+3)StartObservation(true);
}
void ALibraryPlayer::StartObservation(bool Enter){
 bTransition=true;AnimTime=0;GetCharacterMovement()->StopMovementImmediately();
 if(Enter){WalkEye=Camera->GetComponentLocation();WalkRotation=Camera->GetComponentRotation();ObserveYaw=WalkRotation.Yaw;ObservePitch=0;Camera->bUsePawnControlRotation=false;bObserving=true;AlignedHold=0;bChimed=false;}
 else bObserving=false;
}
void ALibraryPlayer::Cancel(){if(bTransition)return;if(bReading)bReading=false;else if(bObserving)StartObservation(false);}
bool ALibraryPlayer::IsAligned()const{return CupPlace==2&&FMath::Abs(FMath::FindDeltaAngleDegrees(ObserveYaw,90))<4&&FMath::Abs(ObservePitch)<2.5f&&bObserving&&!bTransition;}
void ALibraryPlayer::Recover(){
 if(bTransition)return;bReading=false;bObserving=false;ObserveBlend=0;Camera->bUsePawnControlRotation=true;Camera->SetRelativeLocation({0,0,66});Camera->SetRelativeRotation(FRotator::ZeroRotator);Camera->SetFieldOfView(86);
 SetActorLocation({0,-2500,92},false,nullptr,ETeleportType::TeleportPhysics);Controller->SetControlRotation({0,90,0});GetCharacterMovement()->StopMovementImmediately();SyncCup();Say(TEXT("已返回入口，保留器皿和机关状态。"));
}
void ALibraryPlayer::RestartPuzzle(){UGameplayStatics::OpenLevel(this,TEXT("/Game/Maps/LibraryMaze"));}
void ALibraryPlayer::Tick(float Dt){
 Super::Tick(Dt);if(!Puzzle)return;
 if(bTransition){AnimTime+=Dt;float T=FMath::Clamp(AnimTime/.7f,0.f,1.f);float Ease=T*T*(3-2*T);ObserveBlend=bObserving?Ease:1-Ease;if(T>=1){bTransition=false;ObserveBlend=bObserving?1:0;if(!bObserving){Camera->bUsePawnControlRotation=true;Camera->SetRelativeLocation({0,0,66});Camera->SetRelativeRotation(FRotator::ZeroRotator);Camera->SetFieldOfView(86);Controller->SetControlRotation(WalkRotation);SyncCup();}}}
 if(bObserving||bTransition){
  FVector Focus=Puzzle->PedestalPoints[FMath::Clamp(CupPlace,0,2)]+FVector(0,0,25);
  FRotator View(ObservePitch,ObserveYaw,0);FVector Eye=Focus-FRotator(0,ObserveYaw,0).Vector()*95;
  Camera->SetWorldLocation(FMath::Lerp(WalkEye,Eye,ObserveBlend));Camera->SetWorldRotation(FQuat::Slerp(WalkRotation.Quaternion(),View.Quaternion(),ObserveBlend));Camera->SetFieldOfView(FMath::Lerp(86.f,70.f,ObserveBlend));
  if(Puzzle->CupAssembly)Puzzle->CupAssembly->SetVisibility(ObserveBlend<.3f,true);
  if(Puzzle->WaterLens)Puzzle->WaterLens->SetVisibility(false);
  CaptureClock+=Dt;if(CaptureClock>=1.f/30){CaptureClock=0;
   int32 VX=1280,VY=720;if(auto* PC=Cast<APlayerController>(Controller))PC->GetViewportSize(VX,VY);
   int32 H=FMath::Clamp(FMath::RoundToInt(1280.f*VY/FMath::Max(VX,1)),480,1280);if(WaterTexture->SizeY!=H)WaterTexture->ResizeTarget(1280,H);
   WaterCapture->SetWorldLocation(Camera->GetComponentLocation()+Puzzle->EchoOffset(FMath::Clamp(CupPlace,0,2)));WaterCapture->SetWorldRotation(Camera->GetComponentRotation());WaterCapture->FOVAngle=Camera->FieldOfView;WaterCapture->CaptureScene();
  }
  if(IsAligned()){AlignedHold+=Dt;if(AlignedHold>.75f&&!bChimed){bChimed=true;bAlignedOnce=true;ChimeGlow=2.0f;Bell();}}else {AlignedHold=0;bChimed=false;}
 }
 ChimeGlow=FMath::Max(0.f,ChimeGlow-Dt);
 if(!bComplete&&Puzzle->bGatePath&&GetActorLocation().Y>3600&&FMath::Abs(GetActorLocation().X)<210){bComplete=true;GetCharacterMovement()->StopMovementImmediately();Bell();}
 if(GetActorLocation().Z< -250)Recover();
 if(FParse::Param(FCommandLine::Get(),TEXT("LibraryVerify")))Verify(Dt);
 if(FParse::Param(FCommandLine::Get(),TEXT("LibraryAccessVerify")))VerifyAccess(Dt);
}

void ALibraryHUD::DrawHUD(){
 Super::DrawHUD();auto* P=Cast<ALibraryPlayer>(GetOwningPawn());if(!P||!Canvas)return;
 const float W=Canvas->SizeX,H=Canvas->SizeY,S=FMath::Clamp(W/1440.f,.72f,1.5f);
 UFont* Font=LoadObject<UFont>(nullptr,TEXT("/Engine/EngineFonts/Roboto.Roboto"));if(!Font)Font=GEngine->GetMediumFont();
 auto Text=[&](const FString& T,float X,float Y,float Scale,FLinearColor C=FLinearColor(.84f,.9f,.88f)){DrawText(T,C,X,Y,Font,Scale*S*1.6f,false);};
 if(P->ObserveBlend>0.001f&&P->WaterTexture){
  // Screen-space UVs match the main camera exactly: the water replaces only the lower bowl.
  const float B=P->ObserveBlend,RX=W*.365f*B,RY=H*.405f*B,CX=W*.5f,CY=H*.5f;
  for(float DY=0;DY<RY;DY+=3){float T=DY/RY;float Half=RX*FMath::Sqrt(FMath::Max(0.f,1-T*T));float X=CX-Half,Y=CY+DY;
   DrawTexture(P->WaterTexture,X,Y,Half*2,FMath::Min(3.f,RY-DY),X/W,Y/H,Half*2/W,FMath::Min(3.f,RY-DY)/H,FLinearColor(1,1,1,B),BLEND_Translucent);
  }
  FLinearColor Glass(.38f,.82f,.77f,.65f*B);if(P->ChimeGlow>0)Glass=FLinearColor(.9f,.8f,.45f,B);
  for(int I=0;I<80;I++){float A=PI*I/80,A2=PI*(I+1)/80;DrawLine(CX+RX*FMath::Cos(A),CY+RY*FMath::Sin(A),CX+RX*FMath::Cos(A2),CY+RY*FMath::Sin(A2),Glass,2*S);}
  DrawLine(CX-RX,CY,CX+RX,CY,Glass,1.5f*S);
  DrawLine(CX-RX*.40f,CY+RY+9*S,CX+RX*.40f,CY+RY+9*S,Glass,3*S);
  Text(TEXT("杯 中 旧 影"),W*.05f,H*.06f,1.0f);
 }
 else if(!P->bReading&&!P->bComplete){DrawLine(W*.5f-4,H*.5f,W*.5f+4,H*.5f,FLinearColor(.8f,.9f,.85f,.7f));DrawLine(W*.5f,H*.5f-4,W*.5f,H*.5f+4,FLinearColor(.8f,.9f,.85f,.7f));}
 if(!P->bReading&&!P->bComplete){
  Text(TEXT("藏 书 阁"),35*S,25*S,1.1f);
  if(P->bTaken&&!P->bObserving&&!P->bTransition)Text(P->CupPlace<0?(P->bFilled?TEXT("随身：盛水的玻璃杯"):TEXT("随身：空玻璃杯")):TEXT("玻璃杯已放置"),35*S,57*S,.83f);
  FString Hint=P->Prompt();if(!Hint.IsEmpty()){float TW,TH;GetTextSize(Hint,TW,TH,Font,.95f*S*1.6f);DrawRect(FLinearColor(.025f,.045f,.06f,.86f),W/2-TW/2-18*S,H-96*S,TW+36*S,40*S);Text(Hint,W/2-TW/2,H-89*S,.95f);}
  if(!P->bObserving&&!P->bTransition)Text(TEXT("WASD 移动   Space 跳跃   E 交互   F 观察   R 取回   Tab 返回"),35*S,H-36*S,.72f);
  if(P->NoticeUntil>P->GetWorld()->GetTimeSeconds())Text(P->Notice,35*S,H-135*S,.85f);
 }
 if(P->bReading){
  DrawRect(FLinearColor(.005f,.012f,.02f,.82f),0,0,W,H);float X=W*.17f,Y=H*.16f,BW=W*.66f,BH=H*.67f;
  DrawRect(FLinearColor(.73f,.67f,.48f,1),X-8*S,Y-8*S,BW+16*S,BH+16*S);DrawRect(FLinearColor(.91f,.86f,.69f,1),X,Y,BW,BH);
  FLinearColor Ink(.10f,.14f,.14f);Text(TEXT("《旧阁值夜札》"),X+45*S,Y+32*S,1.5f,Ink);
  TArray<FString> Lines{
   TEXT("也许应该去花园，借一杯不肯忘记的水。"),
   TEXT("旧阁的三处承杯石，都曾照见不同的藏书。"),
   TEXT("我托着杯，慢慢转身；眼前的半截木纹，"),
   TEXT("与水下的半截木纹，偶然接成了完整书脊。"),
   TEXT("三格之中，只数那些上下相续的书脊。"),
   TEXT("石轮上的刻痕，也许还认得这样的数目。"),
   TEXT("散开的纹路并非谎言，只是站错了往事的位置。")};
  for(int I=0;I<Lines.Num();I++)Text(Lines[I],X+45*S,Y+(103+I*43)*S,1.03f,Ink);
  Text(TEXT("E / Tab  合上书页"),X+45*S,Y+BH-47*S,.9f,Ink);
 }
 if(P->bComplete){DrawRect(FLinearColor(.015f,.04f,.05f,.84f),0,H*.30f,W,H*.35f);Text(TEXT("藏书阁的回廊终于接通了。"),W*.25f,H*.38f,1.65f);Text(TEXT("流水记住了被改写的书架。你循着新开的路，走向书院深处。"),W*.17f,H*.47f,1.03f);Text(TEXT("F5  重新探索"),W*.42f,H*.57f,.85f);}
}

void ALibraryPlayer::Verify(float Dt){
 // The staged end-to-end route below uses the same interactions as the player.
 static int32 Stage=0;static float Wait=0;static FString Report;static int32 Failures=0;
 static bool Walking=false,WalkDone=false;static int32 Waypoint=0;static float WalkTime=0;
 const TArray<FVector> Route{{-1500,1900,92},{1500,1900,92},{1500,2550,92},{0,2550,92},{0,3670,92}};
 if(Walking){
  WalkTime+=Dt;FVector Delta=Route[Waypoint]-GetActorLocation();Delta.Z=0;
  if(Delta.Size2D()<60||(Waypoint==Route.Num()-1&&bComplete)){Waypoint++;if(Waypoint>=Route.Num()){Walking=false;WalkDone=true;GetCharacterMovement()->StopMovementImmediately();}}
  else {Controller->SetControlRotation(Delta.Rotation());AddMovementInput(Delta.GetSafeNormal(),1);}
  if(WalkTime>42){Walking=false;UE_LOG(LogTemp,Error,TEXT("LIBRARY_WALK_STUCK waypoint=%d location=%s"),Waypoint,*GetActorLocation().ToString());}
 }
 Wait+=Dt;if(Wait<(Stage==0?4.f:1.f))return;Wait=0;
 auto Check=[&](bool Good,const TCHAR* Name){Report+=FString::Printf(TEXT("%s: %s\n"),Good?TEXT("PASS"):TEXT("FAIL"),Name);if(!Good)Failures++;UE_LOG(LogTemp,Display,TEXT("LIBRARY_VERIFY %s: %s"),Good?TEXT("PASS"):TEXT("FAIL"),Name);FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("LibraryVerification.txt")));};
 auto Snap=[&](FVector V){GetCharacterMovement()->StopMovementImmediately();SetActorLocation(V,false,nullptr,ETeleportType::TeleportPhysics);};
 auto Face=[&](FVector V){Controller->SetControlRotation((V-Camera->GetComponentLocation()).Rotation());Camera->SetWorldRotation((V-Camera->GetComponentLocation()).Rotation());};
 auto At=[&](FVector V){Snap(V+FVector(0,-175,-33));Face(V);};
 auto Shot=[&](const TCHAR* N){FScreenshotRequest::RequestScreenshot(FPaths::ProjectSavedDir()/TEXT("Screenshots")/N,true,false);};
 if(Stage<0)return;
 switch(Stage){
 case 0:{Check(Puzzle&&WaterTexture&&WaterCapture->TextureTarget==WaterTexture,TEXT("First-person library and live water render target load"));Check(!Puzzle->bGatePath&&!bTaken&&!bFilled,TEXT("Initial maze sealed; cup is empty and uncollected"));
  for(FVector G:{FVector(-1500,1700,92),FVector(1500,2300,92),FVector(0,2900,92)}){FHitResult Hit;FCollisionQueryParams Q(SCENE_QUERY_STAT(LibrarySealedPassage),false,this);bool Blocked=GetWorld()->SweepSingleByChannel(Hit,G-FVector(0,250,0),G+FVector(0,250,0),FQuat::Identity,ECC_Pawn,FCollisionShape::MakeCapsule(32,88),Q);Check(Blocked,TEXT("Closed shelf physically blocks a player-sized capsule"));}Shot(TEXT("01_LibraryEntrance.png"));break;}
 case 1:At(Puzzle->BookPoint);Interact();Check(bReading,TEXT("Distant glowing book opens through normal interaction"));Shot(TEXT("02_OptionalBook.png"));break;
 case 2:Interact();At(Puzzle->CupPoint);Interact();Check(bTaken&&!bFilled&&CupPlace<0,TEXT("Collect empty glass cup"));break;
 case 3:At(Puzzle->PedestalPoints[0]);Interact();Observe();Check(CupPlace==0&&!bObserving,TEXT("Empty cup can be placed but cannot reveal water"));TakeBack();Check(CupPlace<0,TEXT("Empty placed cup can be recovered without deadlock"));break;
 case 4:At(Puzzle->FountainPoint);Interact();Check(bFilled,TEXT("Fill cup at garden fountain"));Shot(TEXT("03_CentralGarden.png"));break;
 case 5:At(Puzzle->PedestalPoints[0]);Interact();Observe();Check(bObserving&&bTransition,TEXT("First decoy starts animated water observation"));ObserveYaw=90;ObservePitch=0;break;
 case 6:Check(!bTransition&&ObserveBlend==1&&!bAlignedOnce,TEXT("First decoy reveals alternate world without solution feedback"));Check(FVector::Dist(WaterCapture->GetComponentLocation(),Camera->GetComponentLocation()+Puzzle->EchoOffset(0))<1,TEXT("Decoy one captures separate physical shelves with matched viewpoint"));Shot(TEXT("04_WaterWrongWest.png"));break;
 case 7:{float Before=ObserveYaw;Turn(144);Check(FMath::Abs(FMath::FindDeltaAngleDegrees(Before,ObserveYaw))<.1,TEXT("Observation wraps through a full 360 degrees"));Cancel();Check(bTransition&&!bObserving,TEXT("Leaving water observation plays return animation"));break;}
 case 8:Check(!bTransition&&ObserveBlend==0&&Camera->bUsePawnControlRotation,TEXT("Exit restores first-person camera and controls"));At(Puzzle->PedestalPoints[0]);TakeBack();At(Puzzle->PedestalPoints[1]);Interact();Observe();ObserveYaw=90;break;
 case 9:Check(CupPlace==1&&bObserving&&!bAlignedOnce,TEXT("Second decoy also has an alternate world and no wrong-position label"));Check(FVector::Dist(WaterCapture->GetComponentLocation(),Camera->GetComponentLocation()+Puzzle->EchoOffset(1))<1,TEXT("Decoy two captures its own different physical library"));Shot(TEXT("05_WaterWrongEast.png"));break;
 case 10:Cancel();break;
 case 11:At(Puzzle->PedestalPoints[1]);TakeBack();At(Puzzle->PedestalPoints[2]);Interact();Observe();ObserveYaw=-90;break;
 case 12:Check(CupPlace==2&&!bAlignedOnce,TEXT("Correct stone with wrong angle does not confirm alignment"));Shot(TEXT("06_CorrectStoneWrongAngle.png"));ObserveYaw=90;ObservePitch=0;break;
 case 13:Check(IsAligned()&&bAlignedOnce,TEXT("Correct stone and angle hold triggers chime on composite shelf clue"));Shot(TEXT("07_JoinedWaterClue.png"));break;
 case 14:ObserveYaw=45;ObservePitch=20;break;
 case 15:Check(!IsAligned()&&bAlignedOnce,TEXT("Looking away breaks geometric alignment but retains discovery"));Cancel();break;
 case 16:At(Puzzle->PedestalPoints[2]);TakeBack();Check(CupPlace<0&&bFilled,TEXT("Water remains filled and reusable after observing all three stones"));At(Puzzle->LeverPoints[0]);Interact();Check(Puzzle->GetDial(0)==1&&!Puzzle->bGatePath,TEXT("Incorrect first dial does not open complete maze"));break;
 case 17:Interact();At(Puzzle->LeverPoints[1]);Interact();At(Puzzle->LeverPoints[2]);Interact();Interact();Check(Puzzle->GetDial(0)==2&&Puzzle->GetDial(1)==1&&Puzzle->GetDial(2)==2&&!Puzzle->bGatePath,TEXT("Partial solution still leaves exit blocked"));break;
 case 18:Interact();Check(Puzzle->GetDial(2)==3,TEXT("Third mechanism reaches discovered final mark"));break;
 case 19:{static int32 Retries=0;if(!Puzzle->ShelvesSettled()&&Retries++<8)return;Check(Puzzle->bGatePath&&Puzzle->ShelvesSettled(),TEXT("All three shelf passages open after animated movement"));Snap({-1500,1420,92});Face({-1500,2100,154});Shot(TEXT("08_MovingShelfPassage.png"));break;}
 case 20:Walking=true;Waypoint=0;WalkTime=0;break;
 case 21:if(Walking)return;Check(WalkDone,TEXT("Character physically walks all three alternating shelf passages to the exit"));Check(bComplete,TEXT("Real walking across final threshold completes maze"));Shot(TEXT("10_LibraryExit.png"));break;
 case 22:break;
 case 23:break;
 case 24:Snap({900,-1450,860});GetCharacterMovement()->SetMovementMode(MOVE_Flying);Controller->SetControlRotation({-26,110,0});Camera->SetWorldRotation({-26,110,0});Cast<APlayerController>(Controller)->GetHUD()->bShowHUD=false;Shot(TEXT("09_LibraryOverview.png"));break;
 case 25:Cast<APlayerController>(Controller)->GetHUD()->bShowHUD=true;GetCharacterMovement()->SetMovementMode(MOVE_Walking);Snap({0,3150,92});Controller->SetControlRotation({0,90,0});break;
 case 26:break;
 case 27:Check(bComplete,TEXT("Completion persists after traversing opened library"));break;
 case 28:Report+=Failures==0?TEXT("ALL_CHECKS_PASSED\n"):FString::Printf(TEXT("FAILED_CHECKS=%d\n"),Failures);FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("LibraryVerification.txt")));UE_LOG(LogTemp,Display,TEXT("LIBRARY_VERIFY FINISHED failures=%d"),Failures);Stage=-1;return;
 }Stage++;
}

void ALibraryPlayer::VerifyAccess(float Dt){
 static int32 Step=0;static float Time=0,StuckTime=0;static FString Report;
 if(Step<0)return;Time+=Dt;if(Time<4)return;
 const TArray<FVector> Route{{0,-650,92},{-750,-650,92},{-750,-100,92},{-1400,-100,92},{-1400,-1975,92},{-1550,-1975,92},{-1400,-1975,92},{-1400,-675,92},{-1550,-675,92},{-1400,-675,92},{-1400,-120,92},{-750,-120,92},{-750,-650,92},{0,-650,92},{0,-300,92},{0,-650,92},{750,-650,92},{750,-25,92},{1550,-25,92},{1550,-2325,92},{1800,-2325,92},{1550,-2325,92},{1550,620,92},{0,620,92},{0,725,92},{-1250,675,92},{1250,675,92},{700,1175,92}};
 FVector Delta=Route[Step]-GetActorLocation();Delta.Z=0;StuckTime+=Dt;
 auto Save=[&](){FFileHelper::SaveStringToFile(Report,*(FPaths::ProjectSavedDir()/TEXT("LibraryAccessVerification.txt")));};
 if(StuckTime>25){Report+=FString::Printf(TEXT("FAIL: route step %d, pawn %s\n"),Step,*GetActorLocation().ToString());Save();Step=-1;return;}
 if(Delta.Size2D()>22){Controller->SetControlRotation(Delta.Rotation());AddMovementInput(Delta.GetSafeNormal(),1);return;}
 GetCharacterMovement()->StopMovementImmediately();Report+=FString::Printf(TEXT("PASS: physical walking waypoint %d\n"),Step);StuckTime=0;
 int32 Expected=-1;
 if(Step==5)Expected=0;else if(Step==8)Expected=3;else if(Step==14)Expected=1;else if(Step==18)Expected=4;else if(Step==20)Expected=2;else if(Step==24)Expected=5;else if(Step>=25)Expected=Step-19;
 if(Expected>=0){FVector P=Expected==0?Puzzle->CupPoint:Expected==1?Puzzle->FountainPoint:Expected==2?Puzzle->BookPoint:Expected<6?Puzzle->PedestalPoints[Expected-3]:Puzzle->LeverPoints[Expected-6];FRotator R=(P-Camera->GetComponentLocation()).Rotation();Controller->SetControlRotation(R);Camera->SetWorldRotation(R);
  bool Good=Target()==Expected;Report+=FString::Printf(TEXT("%s: interaction target %d reachable from walkable floor\n"),Good?TEXT("PASS"):TEXT("FAIL"),Expected);if(!Good){Save();Step=-1;return;}
  if(Expected==0||Expected==1)Interact();
 }
 Step++;if(Step==Route.Num()){Report+=TEXT("ALL_ACCESS_CHECKS_PASSED\n");Step=-1;UE_LOG(LogTemp,Display,TEXT("LIBRARY_ACCESS ALL_ACCESS_CHECKS_PASSED"));}Save();
}
