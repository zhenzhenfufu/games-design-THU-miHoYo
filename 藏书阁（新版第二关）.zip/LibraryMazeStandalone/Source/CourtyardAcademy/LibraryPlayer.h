#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "LibraryPlayer.generated.h"

class UCameraComponent;
class USceneCaptureComponent2D;
class UTextureRenderTarget2D;
class ALibraryWorld;

UCLASS()
class COURTYARDACADEMY_API ALibraryPlayer : public ACharacter {
 GENERATED_BODY()
public:
 ALibraryPlayer();
 virtual void BeginPlay() override;
 virtual void Tick(float Dt) override;
 virtual void SetupPlayerInputComponent(UInputComponent* I) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UCameraComponent> Camera;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneCaptureComponent2D> WaterCapture;
 UPROPERTY(Transient) TObjectPtr<UTextureRenderTarget2D> WaterTexture;
 UPROPERTY() TObjectPtr<ALibraryWorld> Puzzle;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bTaken=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bFilled=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") int32 CupPlace=-1;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bAlignedOnce=false;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Puzzle") bool bComplete=false;
 bool bReading=false,bObserving=false,bTransition=false;
 float ObserveBlend=0,ObserveYaw=90,ObservePitch=0,AlignedHold=0,ChimeGlow=0;
 FString Notice;
 float NoticeUntil=0;
 int32 Target()const;
 FString Prompt()const;
 void Interact();void Observe();void TakeBack();void Cancel();void Recover();void RestartPuzzle();
 void SyncCup();
 bool IsAligned()const;
private:
 FVector WalkEye;
 FRotator WalkRotation;
 float CaptureClock=0,AnimTime=0;
 bool bChimed=false;
 void Forward(float V);void Right(float V);void Turn(float V);void Look(float V);void JumpStart();
 void ViewLeft();void ViewRight();void Bell();
 void Say(const FString& T,float Duration=3);
 void StartObservation(bool Enter);
 void Verify(float Dt);
 void VerifyAccess(float Dt);
};

UCLASS()
class COURTYARDACADEMY_API ALibraryHUD : public AHUD {
 GENERATED_BODY()
public: virtual void DrawHUD() override;
};
UCLASS()
class COURTYARDACADEMY_API ALibraryGameMode : public AGameModeBase {
 GENERATED_BODY()
public: ALibraryGameMode();
};
