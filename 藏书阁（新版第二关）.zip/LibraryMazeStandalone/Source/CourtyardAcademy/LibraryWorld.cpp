#include "LibraryWorld.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/TextRenderComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Pawn.h"
#include "UObject/ConstructorHelpers.h"

namespace Archive {
 const FLinearColor Stone(.35f,.43f,.46f),Pale(.68f,.76f,.73f),Dark(.025f,.045f,.065f),Wood(.26f,.14f,.075f),WoodLight(.43f,.27f,.13f),Jade(.13f,.65f,.57f),Gold(.93f,.61f,.24f),Paper(.79f,.73f,.54f),Leaf(.13f,.34f,.24f);
}

ALibraryWorld::ALibraryWorld(){
 PrimaryActorTick.bCanEverTick=true;
 Root=CreateDefaultSubobject<USceneComponent>(TEXT("LibraryOfErasedPaths"));SetRootComponent(Root);
 static ConstructorHelpers::FObjectFinder<UStaticMesh> C(TEXT("/Engine/BasicShapes/Cube.Cube")),Y(TEXT("/Engine/BasicShapes/Cylinder.Cylinder")),S(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
 static ConstructorHelpers::FObjectFinder<UMaterialInterface> M(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
 Cube=C.Object;Cylinder=Y.Object;Sphere=S.Object;BaseMaterial=M.Object;
 using namespace Archive;
 Shape(TEXT("FloatingArchiveFoundation"),{0,350,-180},{5400,6500,300},Dark);
 Shape(TEXT("ArchiveFloor"),{0,350,-25},{5200,6300,50},Stone);
 for(int x=-2;x<=2;x++)Shape(FString::Printf(TEXT("StoneFloorSeam%d"),x),{x*950.f,350,1},{3,6200,2},Pale,nullptr,false);
 for(int y=0;y<7;y++)Shape(FString::Printf(TEXT("CrossFloorSeam%d"),y),{0,-2350.f+y*900,1},{5100,3,2},Pale,nullptr,false);
 Shape(TEXT("SouthWall"),{0,-2800,500},{5200,40,1000},Dark);
 Shape(TEXT("SouthEntryRecess"),{0,-2772,210},{420,25,420},Wood);
 Shape(TEXT("EntryLintel"),{0,-2735,425},{500,65,55},Gold);
 for(int s:{-1,1}){
  Shape(FString::Printf(TEXT("OutsideWall%d"),s),{s*2600.f,350,500},{45,6300,1000},Dark);
  Shape(FString::Printf(TEXT("SideHighGallery%d"),s),{s*2290.f,350,540},{560,6150,35},Wood);
  Shape(FString::Printf(TEXT("GalleryRailTop%d"),s),{s*1985.f,350,650},{22,6150,24},WoodLight);
  Shape(FString::Printf(TEXT("GalleryRailFoot%d"),s),{s*1985.f,350,573},{22,6150,20},WoodLight);
  for(int i=0;i<13;i++)Shape(FString::Printf(TEXT("GalleryBaluster%d_%d"),s,i),{s*1985.f,-2600+i*490.f,610},{15,15,95},Gold);
  for(int i=0;i<8;i++){
   const float py=-2450+i*810.f;
   Shape(FString::Printf(TEXT("LibraryColumn%d_%d"),s,i),{s*2050.f,py,450},{65,65,900},Wood);
   Shape(FString::Printf(TEXT("ColumnStoneFoot%d_%d"),s,i),{s*2050.f,py,40},{120,120,80},Pale);
   Shape(FString::Printf(TEXT("ColumnCapital%d_%d"),s,i),{s*2050.f,py,835},{165,100,80},WoodLight);
   Shape(FString::Printf(TEXT("VaultSlopingBeam%d_%d"),s,i),{s*1040.f,py,985},{2150,45,60},Wood)->SetRelativeRotation(FRotator(0,0,s*9.f));
   Shape(FString::Printf(TEXT("WallLantern%d_%d"),s,i),{s*2500.f,py,350},{38,38,90},Gold,nullptr,false,1,1.6f);
   Shape(FString::Printf(TEXT("UpperGalleryBooks%d_%d"),s,i),{s*2535.f,py,720},{100,500,330},WoodLight);
   for(int b=0;b<5;b++)Shape(FString::Printf(TEXT("UpperBookSpine%d_%d_%d"),s,i,b),{s*2478.f,py-190+b*92.f,720},{14,75,265},b%2?Paper:Jade,nullptr,false);
  }
  Shape(FString::Printf(TEXT("NorthWall%d"),s),{s*1400.f,3490,500},{2400,45,1000},Dark);
  Shape(FString::Printf(TEXT("NorthDoorPillar%d"),s),{s*217.f,3480,235},{55,95,470},WoodLight);
 }
 Shape(TEXT("NorthDoorLintel"),{0,3480,460},{490,95,55},Gold);
 Shape(TEXT("MoonlitExitFloor"),{0,3730,-25},{470,510,50},Pale);
 Shape(TEXT("ExitEndWall"),{0,3970,260},{470,30,520},Dark);
 Shape(TEXT("ExitBeyondGlow"),{0,3952,230},{340,5,390},Jade,nullptr,false,0,.6f);
 Shape(TEXT("RoofRidge"),{0,350,1160},{90,6250,80},Wood);
 // The roof is open over the planted court, recalling the previous floating courtyard.
 for(int s:{-1,1})Shape(FString::Printf(TEXT("OuterRoof%d"),s),{s*2170.f,350,1020},{850,6250,40},Dark);
 for(int i=0;i<4;i++){
  const float py=-1900+i*1450.f;
  Shape(FString::Printf(TEXT("HangingLanternCord%d"),i),{0,py,790},{3,3,260},Wood);
  Shape(FString::Printf(TEXT("HangingLantern%d"),i),{0,py,660},{95,95,150},Paper,nullptr,false,1,1.4f);
  Shape(FString::Printf(TEXT("LanternCap%d"),i),{0,py,740},{120,120,20},Wood);
  auto* L=CreateDefaultSubobject<UPointLightComponent>(*FString::Printf(TEXT("LanternLight%d"),i));L->SetupAttachment(Root);L->SetRelativeLocation({0,py,590});L->SetIntensity(7500);L->SetAttenuationRadius(1700);L->SetLightColor(FLinearColor(1,.78f,.48f));L->SetCastShadows(false);
 }
 // Southern stacks create discoverable alcoves without isolating any puzzle station.
 for(int s:{-1,1}){
  for(int i=0;i<4;i++){
   const float py=-2190+i*510.f;
   Shelf(FString::Printf(TEXT("ReadingStack%d_%d"),s,i),{s*1180.f,py,0},900,480,nullptr,true,90);
  }
  for(int i=0;i<3;i++)Shelf(FString::Printf(TEXT("OuterReadingStack%d_%d"),s,i),{s*2390.f,-1660+i*800.f,0},600,500,nullptr,true,90);
  Shape(FString::Printf(TEXT("ReadingTable%d"),s),{s*1780.f,-1200,74},{350,130,28},WoodLight);
  for(int i:{-1,1})Shape(FString::Printf(TEXT("ReadingTableFoot%d_%d"),s,i),{s*1780.f+i*140,-1200,34},{30,90,68},Wood);
 }
 Shelf(TEXT("CupAlcoveShelf"),{-1740,-1800,0},410,440,nullptr,true,90);
 Shape(TEXT("CupAlcoveStand"),CupPoint-FVector(0,0,69),{125,130,112},WoodLight);
 Shape(TEXT("CupAlcovePaper"),CupPoint-FVector(0,0,10),{95,105,3},Paper,nullptr,false);
 Shelf(TEXT("BookAlcoveShelf"),{2040,-2150,0},450,470,nullptr,true,90);
 Shape(TEXT("HintBookReadingShelf"),BookPoint-FVector(0,0,28),{150,100,20},WoodLight);
 HintBook=Shape(TEXT("DistantLuminousBook"),BookPoint,{76,48,14},Gold,nullptr,false,0,1.5f);
 Shape(TEXT("LuminousBookPages"),BookPoint+FVector(0,0,8),{69,43,6},Paper,nullptr,false,0,.35f);
 auto* BL=CreateDefaultSubobject<UPointLightComponent>(TEXT("OnlyBookInvitingLight"));BL->SetupAttachment(Root);BL->SetRelativeLocation(BookPoint+FVector(0,-30,90));BL->SetIntensity(650);BL->SetAttenuationRadius(300);BL->SetLightColor(Gold);BL->SetCastShadows(false);
 // Four planted beds leave a broad cross-shaped path into the fountain.
 Shape(TEXT("GardenCourtInlay"),{0,0,2},{1360,1240,4},Pale,nullptr,false);
 for(int sx:{-1,1})for(int sy:{-1,1}){
  const FVector P(sx*455.f,sy*385.f,0);
  const FString N=FString::Printf(TEXT("Garden%d_%d"),sx,sy);
  Shape(N+TEXT("StonePlanter"),P+FVector(0,0,28),{340,290,56},Pale);
  Shape(N+TEXT("Earth"),P+FVector(0,0,57),{306,255,5},Wood);
  for(int k=0;k<5;k++){
   FVector B=P+FVector(-110+k*54.f,(k%2?55:-45),90+k%3*13.f);
   Shape(N+FString::Printf(TEXT("Leaves%d"),k),B,{100,85,95},Leaf,nullptr,false,2);
   Shape(N+FString::Printf(TEXT("Flower%d"),k),B+FVector(0,0,47),{22,22,18},k%2?Jade:Paper,nullptr,false,2,.25f);
  }
 }
 Shape(TEXT("FountainOctagonalFoot"),{0,0,14},{450,450,28},Stone,nullptr,true,1);
 Shape(TEXT("FountainBasin"),{0,0,39},{385,385,50},Pale,nullptr,true,1);
 Shape(TEXT("Water_FountainSurface"),{0,0,66},{335,335,8},Jade,nullptr,false,1,.4f);
 Shape(TEXT("FountainStem"),{0,0,118},{55,55,105},Pale,nullptr,true,1);
 Shape(TEXT("FountainUpperBowl"),{0,0,174},{160,160,30},Pale,nullptr,false,1);
 Shape(TEXT("FountainUpperWater"),{0,0,191},{132,132,4},Jade,nullptr,false,1,.65f);
 Shape(TEXT("FountainJet"),{0,0,230},{9,9,80},Jade,nullptr,false,1,1.1f);
 for(int i=0;i<8;i++){
  const float a=i*PI*.25f;
  Shape(FString::Printf(TEXT("FallingWater%d"),i),{FMath::Cos(a)*64,FMath::Sin(a)*64,133},{5,5,100},Jade,nullptr,false,1,.65f);
 }
 for(int s:{-1,1}){
  const FVector P(s*470.f,450,0);
  Shape(FString::Printf(TEXT("GardenTreeTrunk%d"),s),P+FVector(0,0,210),{26,26,320},Wood,nullptr,true,1);
  Shape(FString::Printf(TEXT("GardenTreeCrown%d"),s),P+FVector(0,0,360),{240,220,170},Leaf,nullptr,false,2);
  Shape(FString::Printf(TEXT("GardenTreeCrownHigh%d"),s),P+FVector(s*40.f,0,445),{165,175,145},Jade*.50f,nullptr,false,2);
 }
 // The three cups stands deliberately share the same design and affordance.
 for(int i=0;i<3;i++){
  const FString N=FString::Printf(TEXT("VesselStand%d"),i);const FVector P=PedestalPoints[i];
  Shape(N+TEXT("Foot"),P-FVector(0,0,112),{150,150,26},Stone,nullptr,true,1);
  Shape(N+TEXT("Stem"),P-FVector(0,0,60),{65,65,96},WoodLight,nullptr,true,1);
  Shape(N+TEXT("Tray"),P-FVector(0,0,10),{140,140,20},Pale,nullptr,true,1);
  Shape(N+TEXT("WaterStain"),P+FVector(0,0,1),{72,72,2},Jade,nullptr,false,1,.1f);
  Shape(N+TEXT("ReadingLamp"),P+FVector(85,30,65),{28,28,62},Paper,nullptr,false,1,.75f);
 }
 CupAssembly=Group(TEXT("PortableGlassVessel"));CupAssembly->SetRelativeLocation(CupPoint);
 WorldCup=CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WholeVesselVisibilityRoot"));WorldCup->SetupAttachment(CupAssembly);WorldCup->SetMobility(EComponentMobility::Movable);WorldCup->SetCollisionEnabled(ECollisionEnabled::NoCollision);
 CupGlass=Shape(TEXT("ClearGlassCupBody"),{0,0,31},{60,60,62},Pale,WorldCup,false,1,.05f);
 for(int i=0;i<12;i++){
  const float a=i*PI/6;
  auto* Rim=Shape(FString::Printf(TEXT("GlassRim%d"),i),{FMath::Cos(a)*30,FMath::Sin(a)*30,62},{17,3,3},Pale,WorldCup,false,0,.45f);Rim->SetRelativeRotation(FRotator(0,i*30+90,0));
 }
 Shape(TEXT("CupGlassFoot"),{0,0,2},{63,63,4},Pale,WorldCup,false,1,.2f);
 CupWater=Shape(TEXT("Water_CupContents"),{0,0,27},{53,53,48},Jade,WorldCup,false,1,.15f);
 WaterLens=Shape(TEXT("DifferentWorldInsideWater"),{0,0,35},{70,70,70},Jade,WorldCup,false,2);
 WaterLens->SetCastShadow(false);WaterLens->SetVisibility(false);WaterLens->SetHiddenInGame(true);CupWater->SetVisibility(false);CupWater->SetHiddenInGame(true);
 // A/B/C devices have tactile four-detent handles; no combination is labelled.
 LeverIndicators.SetNum(3);
 for(int i=0;i<3;i++){
  const FString N=FString::Printf(TEXT("ShelfControl%d"),i);const FVector P=LeverPoints[i];
  Shape(N+TEXT("Base"),P-FVector(0,0,67),{100,100,106},Wood);
  Shape(N+TEXT("Face"),P,{116,100,22},WoodLight);
  Shape(N+TEXT("Dial"),P+FVector(0,0,16),{76,76,13},Pale,nullptr,false,1);
  for(int d=0;d<4;d++){
   const float a=d*PI*.5f;
   Shape(N+FString::Printf(TEXT("Detent%d"),d),P+FVector(FMath::Cos(a)*35,FMath::Sin(a)*35,26),{7,7,4},Gold,nullptr,false,1,.3f);
  }
  LeverIndicators[i]=Group(N+TEXT("RotatingHandle"));LeverIndicators[i]->SetRelativeLocation(P+FVector(0,0,34));
  Shape(N+TEXT("Handle"),{17,0,0},{55,15,15},Gold,LeverIndicators[i],false);
  Shape(N+TEXT("Grip"),{36,0,17},{15,15,48},WoodLight,LeverIndicators[i],false,1);
  Label(N+TEXT("Identity"),FString::FromInt(i+1),P+FVector(0,-56,10),29);
  // Four pips are local dial settings, not the solution.
  for(int d=0;d<4;d++)Label(N+FString::Printf(TEXT("Setting%d"),d),FString::FromInt(d),P+FVector(-42+d*28.f,-58,-24),15);
 }
 // Three complete cross-walls force actual movement through the shifted stacks.
 SlidingShelves.SetNum(3);
 for(int i=0;i<3;i++){
  const FVector P=ClosedShelfPositions[i];const float HalfGap=200;
  const float LeftEnd=P.X-HalfGap,RightStart=P.X+HalfGap;
  const FString N=FString::Printf(TEXT("MazeBarrier%d"),i);
  const float LeftWidth=LeftEnd+2600,RightWidth=2600-RightStart;
  Shelf(N+TEXT("WestWing"),{(-2600+LeftEnd)*.5f,P.Y,0},LeftWidth,660,nullptr,false);
  Shelf(N+TEXT("EastWing"),{(RightStart+2600)*.5f,P.Y,0},RightWidth,660,nullptr,false);
  // A wider lintel does not block a normal-height first-person character.
  Shape(N+TEXT("Header"),{P.X,P.Y,693},{580,175,65},WoodLight);
  SlidingShelves[i]=Group(N+TEXT("SlidingShelf"));SlidingShelves[i]->SetRelativeLocation(P);
  Shelf(N+TEXT("MovingStack"),FVector::ZeroVector,475,640,SlidingShelves[i],true);
  Shape(N+TEXT("FloorTrack"),{P.X+300,P.Y,2},{1110,240,4},Dark,nullptr,false);
  for(int s:{-1,1})Shape(N+FString::Printf(TEXT("MetalRail%d"),s),{P.X+300,P.Y+s*87.f,5},{1100,6,5},Gold,nullptr,false,0,.1f);
 }
 // Extra tall spines prevent the end corridors from feeling like an empty room.
 for(int i=0;i<2;i++)for(int s:{-1,1})Shelf(FString::Printf(TEXT("MazeSideStack%d_%d"),i,s),{s*2450.f,1990+i*600.f,0},330,620,nullptr,true,90);
 // A bookshelf frieze provides only broken upper marks in reality.
 Shape(TEXT("ClueFriezeBacking"),{0,1493,200},{570,25,335},Wood);
 Shape(TEXT("ClueFriezeTop"),{0,1460,294},{570,35,26},WoodLight);
 Shape(TEXT("ClueFriezeSill"),{0,1460,17},{570,35,26},WoodLight);
 for(int split=0;split<4;split++)Shape(FString::Printf(TEXT("RealityClueDivider%d"),split),{-225+split*150.f,1445,157},{8,24,280},Pale,nullptr,false);
 for(int group=0;group<3;group++){
  const float cx=-150+group*150.f;
  for(int mark=0;mark<3;mark++){
   const float x=cx+(mark-1)*34;
   // Every upper cluster has three stems; the water decides which are continuous.
   Shape(FString::Printf(TEXT("RealityUpperClue%d_%d"),group,mark),{x,1445,211},{14,20,122},Gold,nullptr,false,0,.12f);
   Shape(FString::Printf(TEXT("RealityLowerDistractor%d_%d"),group,mark),{x+13,1445,72+mark*11.f},{14,20,53},WoodLight,nullptr,false);
  }
  Shape(FString::Printf(TEXT("RealityUpperCap%d"),group),{cx,1444,273},{110,22,12},Gold,nullptr,false,0,.12f);
  Label(FString::Printf(TEXT("ClueMechanismIdentity%d"),group),FString::FromInt(group+1),{cx,1430,337},23);
 }
 // Three built alternate libraries, including the two apparently plausible decoys.
 for(int echo=0;echo<3;echo++){
  const FVector O=EchoOffset(echo);const FString N=FString::Printf(TEXT("WaterLibrary%d"),echo);
  Shape(N+TEXT("Floor"),O+FVector(0,350,-25),{5200,6300,50},Stone);
  Shape(N+TEXT("BackWall"),O+FVector(0,3490,500),{5200,45,1000},Dark);
  Shape(N+TEXT("SouthWall"),O+FVector(0,-2800,500),{5200,45,1000},Dark);
  for(int s:{-1,1}){
   Shape(N+FString::Printf(TEXT("SideWall%d"),s),O+FVector(s*2600.f,350,500),{45,6300,1000},Dark);
   for(int j=0;j<5;j++){
    const float py=-2200+j*1100.f;
    Shape(N+FString::Printf(TEXT("Column%d_%d"),s,j),O+FVector(s*2050.f,py,450),{65,65,900},Wood);
    Shape(N+FString::Printf(TEXT("Lantern%d_%d"),s,j),O+FVector(s*1960.f,py,400),{50,50,100},Paper,nullptr,false,1,1.5f);
    const float shift=(echo==0?190:echo==1?-230:120);
    Shelf(N+FString::Printf(TEXT("DisplacedShelf%d_%d"),s,j),O+FVector(s*(1370+shift),py+shift,0),700,430+((j+echo)%3)*80,nullptr,false,j%2?90:0);
   }
  }
  // Missing fountain and inverted hanging garden reinforce the alternate world at all headings.
  Shape(N+TEXT("EmptyFountainFootprint"),O+FVector(0,0,8),{440,440,16},Dark,nullptr,false,1);
  for(int k=0;k<4;k++){
   const float a=k*PI*.5f+echo*.4f;
   FVector T=O+FVector(FMath::Cos(a)*450,FMath::Sin(a)*450,620);
   Shape(N+FString::Printf(TEXT("SuspendedPlanter%d"),k),T,{210,140,55},Pale,nullptr,false);
   Shape(N+FString::Printf(TEXT("HangingGarden%d"),k),T-FVector(0,0,82),{160,130,180},Leaf,nullptr,false,2);
  }
  Shape(N+TEXT("AlteredReadingIsland"),O+FVector(echo==0?-300:400,650,90),{360,180,180},Wood);
  // Only from the intended orbit angle do these deeper, larger lower fragments
  // project onto the real upper frieze. The two worlds have genuinely different depth.
  const float OpticalScale=echo==2?840.f/640.f:1.f;
  const FVector SymbolOrigin=echo==2?FVector(0,1650,0):PedestalPoints[echo]+FVector(echo==0?380:-440,570,-125);
  auto SymbolPosition=[&](FVector V){return O+SymbolOrigin+FVector(V.X*OpticalScale,V.Y,150+(V.Z-150)*OpticalScale);};
  auto SymbolSize=[&](FVector V){return FVector(V.X*OpticalScale,V.Y,V.Z*OpticalScale);};
  Shape(N+TEXT("SymbolBacking"),SymbolPosition({0,43,190}),SymbolSize({570,25,300}),Wood);
  for(int split=0;split<4;split++)Shape(N+FString::Printf(TEXT("ClueDivider%d"),split),SymbolPosition({-225+split*150.f,-5,95}),SymbolSize({8,24,110}),Pale,nullptr,false);
  for(int group=0;group<3;group++){
   const float cx=-150+group*150.f;
   const int count=3;
   for(int mark=0;mark<count;mark++){
    float dx=echo==2?(group==0?(mark==0?-34.f:mark==1?34.f:65.f):group==1?(mark-1)*63.f:(mark-1)*34.f):(mark-1)*39.f+17;
    Shape(N+FString::Printf(TEXT("WaterLowerClue%d_%d"),group,mark),SymbolPosition({cx+dx,-5,95}),SymbolSize({14,20,110}),Gold,nullptr,false,0,.12f);
   }
   // Offset upper fragments ensure even wrong worlds never simply copy reality.
   for(int mark=0;mark<3;mark++)Shape(N+FString::Printf(TEXT("AlteredUpperFragment%d_%d"),group,mark),SymbolPosition({cx+(mark-1)*42+15,-5,220.f-mark*17}),SymbolSize({14,20,60}),WoodLight,nullptr,false);
   Shape(N+FString::Printf(TEXT("WaterLowerCap%d"),group),SymbolPosition({cx,-6,44}),SymbolSize({110,22,12}),Gold,nullptr,false,0,.12f);
  }
  auto* EL=CreateDefaultSubobject<UPointLightComponent>(*(N+TEXT("SoftLight")));EL->SetupAttachment(Root);EL->SetRelativeLocation(O+FVector(0,500,650));EL->SetIntensity(12000);EL->SetAttenuationRadius(4200);EL->SetLightColor(FLinearColor(.65f,.9f,.83f));EL->SetCastShadows(false);
 }
 auto* Moon=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("LibraryMoon"));Moon->SetupAttachment(Root);Moon->SetRelativeRotation(FRotator(-52,-28,0));Moon->SetIntensity(2.5f);Moon->SetForwardShadingPriority(1);Moon->SetLightColor(FLinearColor(.72f,.86f,1));
 auto* Fill=CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("LibraryFill"));Fill->SetupAttachment(Root);Fill->SetRelativeRotation(FRotator(-38,140,0));Fill->SetIntensity(1.15f);Fill->SetForwardShadingPriority(0);Fill->SetCastShadows(false);Fill->SetLightColor(FLinearColor(.72f,.79f,.77f));
}

USceneComponent* ALibraryWorld::Group(const FString& Name,USceneComponent* Parent){auto* G=CreateDefaultSubobject<USceneComponent>(*Name);G->SetupAttachment(Parent?Parent:Root.Get());G->SetMobility(EComponentMobility::Movable);return G;}
UStaticMeshComponent* ALibraryWorld::Shape(const FString& Name,FVector P,FVector Size,FLinearColor Color,USceneComponent* Parent,bool Solid,int32 Form,float Glow){
 auto* C=CreateDefaultSubobject<UStaticMeshComponent>(*Name);C->SetupAttachment(Parent?Parent:Root.Get());C->SetStaticMesh(Form==1?Cylinder.Get():Form==2?Sphere.Get():Cube.Get());C->SetRelativeLocation(P);C->SetRelativeScale3D(Size/100);C->SetMaterial(0,BaseMaterial);C->SetMobility(EComponentMobility::Movable);C->SetCollisionProfileName(Solid?TEXT("BlockAll"):TEXT("NoCollision"));C->ComponentTags.Add(FName(*Color.ToString()));C->ComponentTags.Add(FName(*FString::SanitizeFloat(Glow)));if(Solid)C->ComponentTags.Add(TEXT("Solid"));return C;
}
void ALibraryWorld::Shelf(const FString& Name,FVector P,float Width,float Height,USceneComponent* Parent,bool Detailed,float Yaw){
 using namespace Archive;auto* G=Group(Name+TEXT("Assembly"),Parent);G->SetRelativeLocation(P);G->SetRelativeRotation(FRotator(0,Yaw,0));
 Shape(Name+TEXT("Body"),{0,30,Height*.5f},{Width,155,Height},Wood,G);
 Shape(Name+TEXT("Top"),{0,0,Height},{Width+25,200,30},WoodLight,G);
 Shape(Name+TEXT("Foot"),{0,0,18},{Width+12,190,36},WoodLight,G);
 for(int s:{-1,1})Shape(Name+FString::Printf(TEXT("Upright%d"),s),{s*(Width*.5f-14),-58,Height*.5f},{25,26,Height},WoodLight,G);
 // Keep every structural collision plank at its original size and position.
 // Smaller reading shelves and thousands of individual spines are visual only.
 for(int bay=0;bay<3;bay++)Shape(Name+FString::Printf(TEXT("ShelfPlank%d"),bay),{0,-71,65+bay*(Height-100)/3},{Width-18,45,16},WoodLight,G);
 UInstancedStaticMeshComponent* BookRuns[4];const FLinearColor Inks[4]={Jade,Paper,WoodLight,Stone};
 for(int color=0;color<4;color++){
  auto* Run=CreateDefaultSubobject<UInstancedStaticMeshComponent>(*(Name+FString::Printf(TEXT("IndividualBookSpines%d"),color)));
  Run->SetupAttachment(G);Run->SetStaticMesh(Cube);Run->SetMaterial(0,BaseMaterial);Run->SetMobility(EComponentMobility::Movable);Run->SetCollisionProfileName(TEXT("NoCollision"));Run->SetCollisionEnabled(ECollisionEnabled::NoCollision);Run->SetCastShadow(false);
  Run->ComponentTags.Add(FName(*Inks[color].ToString()));Run->ComponentTags.Add(TEXT("0"));BookRuns[color]=Run;
 }
 const int Levels=FMath::Clamp(int(Height/62),6,10),Books=FMath::Clamp(int(Width/30),8,160);const float Section=(Width-80)/Books;
 int Layer=0;for(int bay=0;bay<3;bay++){
  const int Rows=Levels/3+(bay<Levels%3?1:0);const float BaseZ=65+bay*(Height-100)/3;
  const float Ceiling=bay==2?Height-18:65+(bay+1)*(Height-100)/3-8;const float Pitch=(Ceiling-BaseZ)/Rows;
  for(int row=0;row<Rows;row++,Layer++){
   const float Z=BaseZ+row*Pitch;
   if(row>0)Shape(Name+FString::Printf(TEXT("ReadingShelf%d"),Layer),{0,-71,Z},{Width-30,43,8},WoodLight,G,false);
   for(int b=0;b<Books;b++){
    const int Variant=(b*13+Layer*7)%7;
    const float BookH=FMath::Min(30.f+(Variant%6)*3.f,Pitch-13.f),BookW=FMath::Min(20.f+Variant,Section-1.5f);
    const FVector Location(-Width*.5f+40+Section*(b+.5f),-73,Z+10+BookH*.5f);
    BookRuns[(b+Layer*3)%4]->AddInstance(FTransform(FRotator::ZeroRotator,Location,FVector(BookW,25,BookH)/100));
   }
  }
 }
}
void ALibraryWorld::Label(const FString& Name,const FString& Text,FVector P,float Size,USceneComponent* Parent){auto* T=CreateDefaultSubobject<UTextRenderComponent>(*Name);T->SetupAttachment(Parent?Parent:Root.Get());T->SetRelativeLocation(P);T->SetRelativeRotation(FRotator(0,-90,0));T->SetText(FText::FromString(Text));T->SetWorldSize(Size);T->SetHorizontalAlignment(EHTA_Center);T->SetTextRenderColor(FColor(216,207,163));}
void ALibraryWorld::Paint(){
 auto* Mat=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_Court.M_Court"));if(!Mat)return;
 TArray<UStaticMeshComponent*> Parts;GetComponents(Parts);for(auto* Part:Parts)if(Part->ComponentTags.Num()>=2){FLinearColor Col;Col.InitFromString(Part->ComponentTags[0].ToString());auto* MID=Part->CreateDynamicMaterialInstance(0,Mat);MID->SetVectorParameterValue(TEXT("Tint"),Col);MID->SetScalarParameterValue(TEXT("Glow"),FCString::Atof(*Part->ComponentTags[1].ToString()));}
 if(auto* Glass=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/Materials/M_Water.M_Water"))){auto* MID=CupGlass->CreateDynamicMaterialInstance(0,Glass);MID->SetVectorParameterValue(TEXT("Tint"),FLinearColor(.4f,.62f,.65f));}
}
void ALibraryWorld::OnConstruction(const FTransform& T){Super::OnConstruction(T);Paint();TArray<UDirectionalLightComponent*> Lights;GetComponents(Lights);for(auto* Light:Lights)Light->SetForwardShadingPriority(Light->GetName().Contains(TEXT("Moon"))?1:0);}
void ALibraryWorld::BeginPlay(){Super::BeginPlay();Paint();UpdateCup(-1,false,false);}
int32 ALibraryWorld::GetDial(int32 Index)const{return Index==0?DialA:Index==1?DialB:DialC;}
void ALibraryWorld::SetDial(int32 Index,int32 Value){Value=(Value%4+4)%4;if(Index==0)DialA=Value;else if(Index==1)DialB=Value;else if(Index==2)DialC=Value;bGatePath=false;}
FVector ALibraryWorld::ShelfTarget(int32 Index)const{
 // Interlocked gears: a new turn can reopen or close earlier passages.
 // This invertible combination has a unique solution, without requiring a discovery flag.
 const int32 Value=Index==0?(DialA+DialB)%4:Index==1?(DialB+2*DialC)%4:(DialA+DialB+DialC)%4;
 const int32 Answer=Index==2?2:3;
 return ClosedShelfPositions[Index]+(Value==Answer?FVector(610,0,0):FVector((Value-1)*18.f,Value==0?0.f:22.f,0));
}
bool ALibraryWorld::ShelvesSettled()const{for(int i=0;i<3;i++)if(!SlidingShelves.IsValidIndex(i)||FVector::Dist(SlidingShelves[i]->GetRelativeLocation(),ShelfTarget(i))>2)return false;return true;}
void ALibraryWorld::UpdateCup(int32 Place,bool Filled,bool Carried){
 CupAssembly->SetRelativeLocation(Place>=0&&Place<3?PedestalPoints[Place]:CupPoint);CupAssembly->SetVisibility(!Carried,true);CupAssembly->SetHiddenInGame(Carried,true);CupWater->SetVisibility(Filled&&!Carried);CupWater->SetHiddenInGame(!Filled||Carried);WaterLens->SetVisibility(false);WaterLens->SetHiddenInGame(true);
}
void ALibraryWorld::Tick(float Dt){
 Super::Tick(Dt);const APawn* Pawn=UGameplayStatics::GetPlayerPawn(this,0);for(int i=0;i<3;i++){
  const FVector Current=SlidingShelves[i]->GetRelativeLocation(),Target=ShelfTarget(i);
  const bool Closing=Target.X<Current.X-2;
  const bool Occupied=Pawn&&FMath::Abs(Pawn->GetActorLocation().X-ClosedShelfPositions[i].X)<240&&FMath::Abs(Pawn->GetActorLocation().Y-ClosedShelfPositions[i].Y)<230;
  if(!Closing||!Occupied)SlidingShelves[i]->SetRelativeLocation(FMath::VInterpConstantTo(Current,Target,Dt,200));
  LeverIndicators[i]->SetRelativeRotation(FMath::RInterpTo(LeverIndicators[i]->GetRelativeRotation(),FRotator(0,GetDial(i)*90.f,0),Dt,5));
 }bGatePath=DialA==2&&DialB==1&&DialC==3&&ShelvesSettled();
}
