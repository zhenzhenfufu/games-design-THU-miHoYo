#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LibraryWorld.generated.h"

class UStaticMeshComponent;

UCLASS()
class COURTYARDACADEMY_API ALibraryWorld : public AActor {
 GENERATED_BODY()
public:
 ALibraryWorld();
 virtual void OnConstruction(const FTransform& Transform) override;
 virtual void BeginPlay() override;
 virtual void Tick(float DeltaSeconds) override;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> Root;
 UPROPERTY(VisibleAnywhere) TObjectPtr<USceneComponent> CupAssembly;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> WorldCup;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> WaterLens;
 UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> HintBook;
 UPROPERTY(VisibleAnywhere) TArray<TObjectPtr<USceneComponent>> SlidingShelves;
 UPROPERTY(VisibleAnywhere) TArray<TObjectPtr<USceneComponent>> LeverIndicators;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Mechanisms") int32 DialA=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Mechanisms") int32 DialB=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Mechanisms") int32 DialC=0;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Mechanisms") bool bGatePath=false;
 FVector CupPoint=FVector(-1550,-1800,125);
 FVector FountainPoint=FVector(0,0,110);
 FVector BookPoint=FVector(1800,-2150,150);
 FVector PedestalPoints[3]={FVector(-1550,-500,125),FVector(1550,150,125),FVector(0,900,125)};
 FVector LeverPoints[3]={FVector(-1250,850,120),FVector(1250,850,120),FVector(700,1350,120)};
 FVector ExitPoint=FVector(0,3300,100);
 UFUNCTION(BlueprintCallable,Category="Mechanisms") void SetDial(int32 Index,int32 Value);
 UFUNCTION(BlueprintPure,Category="Mechanisms") int32 GetDial(int32 Index)const;
 UFUNCTION(BlueprintPure,Category="Mechanisms") bool ShelvesSettled()const;
 UFUNCTION(BlueprintCallable,Category="Vessel") void UpdateCup(int32 Place,bool Filled,bool Carried);
 FVector EchoOffset(int32 Index)const{return FVector(18000+FMath::Clamp(Index,0,2)*11000.f,0,0);}
private:
 UPROPERTY() TObjectPtr<UStaticMesh> Cube;
 UPROPERTY() TObjectPtr<UStaticMesh> Cylinder;
 UPROPERTY() TObjectPtr<UStaticMesh> Sphere;
 UPROPERTY() TObjectPtr<UMaterialInterface> BaseMaterial;
 UPROPERTY() TObjectPtr<UStaticMeshComponent> CupWater;
 UPROPERTY() TObjectPtr<UStaticMeshComponent> CupGlass;
 FVector ClosedShelfPositions[3]={FVector(-1500,1700,0),FVector(1500,2300,0),FVector(0,2900,0)};
 FVector ShelfTarget(int32 Index)const;
 USceneComponent* Group(const FString& Name,USceneComponent* Parent=nullptr);
 UStaticMeshComponent* Shape(const FString& Name,FVector Position,FVector Size,FLinearColor Color,USceneComponent* Parent=nullptr,bool Solid=true,int32 Form=0,float Glow=0);
 void Shelf(const FString& Name,FVector Position,float Width,float Height,USceneComponent* Parent=nullptr,bool Detailed=true,float Yaw=0);
 void Label(const FString& Name,const FString& Text,FVector Position,float Size=24,USceneComponent* Parent=nullptr);
 void Paint();
};
