@echo off
setlocal
set "UE_EDITOR=%ProgramFiles%\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe"
if defined UE58_ROOT set "UE_EDITOR=%UE58_ROOT%\Engine\Binaries\Win64\UnrealEditor.exe"
if not exist "%UE_EDITOR%" (
 echo Unreal Engine 5.8.2 was not found at the standard location.
 echo Set UE58_ROOT to your UE_5.8 installation folder, or open CourtyardAcademy.uproject with UE 5.8.2.
 pause
 exit /b 1
)
start "" "%UE_EDITOR%" "%~dp0CourtyardAcademy.uproject" /Game/Maps/LibraryMaze  -nosplash -DDC=InstalledNoZenLocalFallback -LocalDataCachePath="%~dp0DerivedDataCache" -ShaderWorkingDir="%~dp0Intermediate\Shaders" -notraceserver -traceautostart=0 -multiprocess %*
exit /b 0